# WooCommerce QA Checklist (Blocks only)

Cart and checkout use **WooCommerce Blocks** only. Classic shortcode pages are unsupported by theme styles; migrate via admin notice or [WooCommerce guide](https://woocommerce.com/document/cart-checkout-blocks-status/).

Test at **375px**, **768px**, **1280px**, and **1440px**. Hard refresh after `npm run build`.

## Required body classes

| Page | Expected class |
|------|----------------|
| Cart | `whoop-cart-block` |
| Checkout | `whoop-checkout-block` |

If these classes are missing, the page content is not using blocks.

## Per-page checks

| Page | Wrapper | Typography | Layout | Overflow | Customizer |
|------|---------|------------|--------|----------|------------|
| Shop / category | | | | | `whoop_shop_subtitle` |
| Single product | | | | | Trust row, ACF steps |
| Cart (block) | | | | | Sticky bar, shipping bar |
| Checkout (block) | | | | | Trust strip |
| My Account | | | | | — |
| Order received | | | | | Thank-you CTA |
| Emails | | | | | `whoop_email_footer_text` |

## PASS criteria

- No horizontal page scrollbar.
- Order summary readable on light panel (sidebar).
- Desktop: 2-column cart/checkout (`sidebar-layout` grid).
- Mobile checkout: order summary above form (`order: -1`).
- Payment fields and iframes stay within viewport.
- Sticky cart bar does not cover CTAs.

## Content management

- **Cart / Checkout blocks:** Pages → edit block content in Gutenberg.
- **Theme strings:** Appearance → Customize → WHOOP — WooCommerce.
- **WooCommerce core:** Settings, translations (Loco/WPML).
- **Payments:** Gateways must support block checkout.

## Build

```bash
npm run build
```

Dist CSS: `assets/dist/assets/style-*.css` + `assets/css/woocommerce-custom.css`.
