<?php
/**
 * Search form.
 *
 * @package whoop-clone
 */

defined( 'ABSPATH' ) || exit;

$whoop_search_field_id = 'search-field-' . wp_unique_id();
?>
<form role="search" method="get" class="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
	<label for="<?php echo esc_attr( $whoop_search_field_id ); ?>" class="screen-reader-text"><?php esc_html_e( 'Search', 'whoop-clone' ); ?></label>
	<input type="search" id="<?php echo esc_attr( $whoop_search_field_id ); ?>" class="search-field" placeholder="<?php esc_attr_e( 'Search…', 'whoop-clone' ); ?>" value="<?php echo esc_attr( get_search_query() ); ?>" name="s" />
	<button type="submit" class="search-submit"><?php esc_html_e( 'Search', 'whoop-clone' ); ?></button>
</form>
