<?php
/**
 * WHOOP Clone — theme bootstrap.
 *
 * @package whoop-clone
 */

defined( 'ABSPATH' ) || exit;

/**
 * Theme version (also used to bust asset caches).
 */
if ( ! defined( 'WHOOP_THEME_VERSION' ) ) {
	define( 'WHOOP_THEME_VERSION', '1.2.12' );
}
if ( ! defined( 'WHOOP_THEME_DIR' ) ) {
	define( 'WHOOP_THEME_DIR', get_stylesheet_directory() );
}
if ( ! defined( 'WHOOP_THEME_URI' ) ) {
	define( 'WHOOP_THEME_URI', get_stylesheet_directory_uri() );
}

require_once WHOOP_THEME_DIR . '/inc/theme-setup.php';
require_once WHOOP_THEME_DIR . '/inc/seo.php';
require_once WHOOP_THEME_DIR . '/inc/accessibility.php';
require_once WHOOP_THEME_DIR . '/inc/woocommerce-customizer.php';
require_once WHOOP_THEME_DIR . '/inc/woocommerce-blocks.php';
require_once WHOOP_THEME_DIR . '/inc/woocommerce-setup.php';
require_once WHOOP_THEME_DIR . '/inc/menu-item-fields.php';
require_once WHOOP_THEME_DIR . '/inc/enqueue.php';
require_once WHOOP_THEME_DIR . '/inc/blocks.php';
require_once WHOOP_THEME_DIR . '/inc/acf-fields.php';
require_once WHOOP_THEME_DIR . '/inc/woocommerce-product-details.php';
