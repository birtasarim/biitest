# WHOOP Clone — Kurulum Rehberi (Türkçe)

Bu rehber temayı sıfırdan kurma + içerik girme adımlarını anlatır.

## 1. Ön gereksinimler

- WordPress 6.0+ kurulu bir site
- PHP 7.4 veya üstü
- WP admin paneline erişimin var

## 2. ACF Pro kurulumu (zorunlu)

Tema, içerik girişi için **Advanced Custom Fields Pro**'ya bağlı.

1. https://www.advancedcustomfields.com/pro/ adresinden lisans satın al ($49/yıl)
2. Aldığın email'deki linkten **ACF Pro plugin .zip dosyasını** indir
3. WP admin → **Eklentiler → Yeni Ekle → Eklenti Yükle** → indirdiğin zip'i seç → **Şimdi Kur** → **Etkinleştir**
4. WP admin → **ACF → Updates** → email'deki **lisans anahtarını** gir → **Activate License**

> ACF Pro lisansın yoksa tema yine yüklenir ama içerik girişi yapamazsın. Yüklü blokları sadece görüntülenir.

## 3. Temayı yükle

### Seçenek A — Hazır build dahil (önerilen — son kullanıcı için)

1. **`whoop-theme.zip`** dosyasını al
2. WP admin → **Görünüm → Temalar → Yeni Ekle → Tema Yükle**
3. zip'i seç → **Şimdi Kur** → **Etkinleştir**

Tema aktif olunca üstte "Etkinleştirildi" mesajı görünür.

### Seçenek B — Geliştirici kurulumu (lokal'de geliştirme yapacaksan)

Tema artık **Vite + SCSS** ile derleniyor. Lokalinde geliştirme yapacaksan:

```bash
# Tema klasörüne gir
cd wp-content/themes/whoop-theme

# Bağımlılıkları kur (Node.js 18+ gerekli)
npm install

# Geliştirme — hot reload, http://localhost:5173 ayağa kalkar
npm run dev

# Production build — assets/dist/ üretir
npm run build
```

**Önemli**: WP'nin Vite dev server'ından asset çekmesi için `wp-config.php` dosyana şunu ekle:

```php
define( 'WHOOP_VITE_DEV', true );
```

Veya tema klasöründe `.dev` adında boş bir dosya oluştur (`.dev` flag dosyası).

Production'a deploy ederken `npm run build` çalıştır, **`.dev` dosyasını/define'i kaldır**, `assets/dist/` klasörünü içeren versiyon yüklensin.

> İlk yükleme sonrası "No compiled assets found" admin uyarısı görürsen `npm run build` çalıştırmamışsın demek. Veya hazır build içeren zip'i kullanmamışsın.

## 4. WooCommerce (opsiyonel — e-ticaret için)

1. **Eklentiler → Yeni Ekle** → arama kutusuna "WooCommerce" yaz
2. **Şimdi Kur** → **Etkinleştir**
3. Açılan kurulum sihirbazını tamamla (mağaza adresi, para birimi, ürün tipleri)

WooCommerce, tema sayfaları ile otomatik uyumludur — ek ayar gerekmez.

## 5. Ana sayfayı ayarla

WordPress varsayılan olarak ana sayfada blog gösterir. Bizim landing page yerine geçmesi için:

1. **Sayfalar → Yeni Ekle**
2. Başlık: **"Ana Sayfa"** (veya istediğin isim)
3. **Yayınla**
4. **Ayarlar → Okuma**
5. "Ana sayfanız görünsün" kısmında **"Statik bir sayfa"** seçeneğini işaretle
6. **Anasayfa** açılır listesinden "Ana Sayfa"yı seç
7. **Değişiklikleri kaydet**

Aynı şekilde **"Yazılar"** dropdown'ı için "Blog" adında ayrı bir sayfa oluşturup atayabilirsin (boş kalabilir, WP otomatik blog yazılarını listeler).

## 6. Bloklarla landing page'i kur

1. **Sayfalar → Tüm sayfalar** → "Ana Sayfa"yı düzenle
2. Editörde sol üstteki **+** ikonuna tıkla
3. Sol menüde **"WHOOP"** kategorisini bul (kalp ikonu)
4. Şu blokları sırayla ekle:

| Sıra | Blok | Notlar |
|------|------|--------|
| 1 | Hero | Video URL'si .mp4 uzantılı olmalı (örnek: Pexels). Poster görseli zorunlu. |
| 2 | Daily | İki kısım — üstte küçük kart, altta büyük başlık+geniş görsel |
| 3 | Features Slider | "Add Feature" ile en az 4 kart ekle (önerilen: 6) |
| 4 | Memberships | "Add Tier" ile 3 tier ekle. **tier_slug** alanına `one`, `peak`, `life` yaz |
| 5 | Gift Banner | Kompakt karanlık kart |
| 6 | Social Proof Mosaic | "Add Item" → her item için **Item Type** seç (image / quote) |
| 7 | Principles Accordion | "Add Principle" — başlık + açıklama + görsel |
| 8 | Showcase | "Add Tab" — her tab için label + image + title + description |
| 9 | Trial | Karanlık kart + JOIN NOW butonu |
| 10 | Advanced Labs | Madde listesi + 3 floating badge |

5. **Güncelle** veya **Yayınla**

## 7. Üst banner ve menü

### Promo bar (üstteki mor şerit)
**Görünüm → Özelleştir → WHOOP — Global Text** → "Promo Bar Text" alanı

### Ana menü
1. **Görünüm → Menüler**
2. **Yeni menü oluştur** → ad ver (örneğin "Ana Menü")
3. Sol panelden sayfaları seç → **Menüye Ekle**
4. Alt kısımda **"Konum"** seçeneklerinden **"Primary Navigation"** kutusunu işaretle
5. **Menüyü Kaydet**

### Footer menüleri
Aynı şekilde 4 ayrı menü oluştur ve şu konumlara ata:
- **Footer — Shop**
- **Footer — Company**
- **Footer — Support**
- **Footer — Legal**

## 8. Logo ve site bilgileri

**Görünüm → Özelleştir → Site Kimliği**
- Logo (PNG/SVG) — header'da görünür
- Site Başlığı — footer'da görünür
- Site Etiketi — şu an kullanılmıyor

## 9. Resim boyutları

Tema 5 özel resim boyutu tanımlar (otomatik üretilir):

| Ad | Boyut | Kullanım |
|----|-------|----------|
| Card 3:4 | 800×1067 | Feature kartı |
| Wide strip | 1920×820 | Wear daily geniş görsel |
| Portrait | 900×1200 | Athlete kartı |
| Square | 1200×1200 | Showcase, Principles |
| Modal full | 1600 (auto) | Modal içeriği |

Mevcut resimler için boyutları yeniden üretmek istersen "Regenerate Thumbnails" eklentisini kullan.

## 10. Sorun giderme

### Bloklar görünmüyor
- ACF Pro etkin mi? Eklentiler sayfasından kontrol et
- WP admin üst kısmında sarı uyarı varsa oradaki yönergeyi izle

### Tema yüklendi ama hata mesajı
- PHP hata günlüğüne (`wp-content/debug.log`) bak
- `wp-config.php` dosyasında `define('WP_DEBUG', true);` ekle ve sayfayı yeniden yükle

### CSS/JS güncellenmiyor
- Tarayıcı önbelleği — Ctrl+Shift+R (hard refresh)
- Veya `functions.php` içindeki `WHOOP_THEME_VERSION` değerini değiştir

### Hero video oynatmıyor
- Tarayıcı bazen otomatik oynatmayı engelliyor — `muted` attribute zorunlu (zaten ekli)
- Mobilde video boyutu büyükse yavaş yüklenir — 5MB altı .mp4 öneririz

## 11. Yedekleme

Site oluşturulduktan sonra mutlaka yedek al:
- **All-in-One WP Migration** veya **UpdraftPlus** eklentilerinden biri yeterli
- Veya hosting paneli üzerinden tam site yedeği

## Destek

Tema, ACF Pro field tanımları **`inc/acf-fields.php`** içinde sürüm kontrolüne uygun şekilde PHP olarak tutuluyor. Yeni bir alan eklemek istediğinde bu dosyayı düzenle, ACF admin UI'ında "Sync available" ile senkronize et.
