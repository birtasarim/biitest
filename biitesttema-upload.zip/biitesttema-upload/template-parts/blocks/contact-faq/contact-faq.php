<?php
/**
 * Contact + FAQ CTA block.
 *
 * @package whoop-clone
 */

defined( 'ABSPATH' ) || exit;

$left_title        = whoop_field( 'left_title' );
$left_subtitle     = whoop_field( 'left_subtitle' );
$left_cta_text     = whoop_field( 'left_cta_text' );
$left_cta_url      = whoop_field( 'left_cta_url' ) ?: '#';
$form_title        = whoop_field( 'form_title' );
$form_subtitle     = whoop_field( 'form_subtitle' );
$name_label        = whoop_field( 'name_label' ) ?: __( 'Name Surname', 'whoop-clone' );
$name_placeholder  = whoop_field( 'name_placeholder' ) ?: __( 'Your name and surname', 'whoop-clone' );
$phone_label       = whoop_field( 'phone_label' ) ?: __( 'Phone Number', 'whoop-clone' );
$phone_placeholder = whoop_field( 'phone_placeholder' ) ?: __( '5xx xxx xx xx', 'whoop-clone' );
$consent_prefix    = whoop_field( 'consent_prefix' );
$consent_link_text = whoop_field( 'consent_link_text' ) ?: __( "KVKK Metni'ni", 'whoop-clone' );
$consent_link_url  = whoop_field( 'consent_link_url' ) ?: '#';
$consent_suffix    = whoop_field( 'consent_suffix' ) ?: __( 'okudum ve kabul ediyorum.', 'whoop-clone' );
$submit_text       = whoop_field( 'submit_text' ) ?: __( 'Submit', 'whoop-clone' );
?>
<section class="contact-faq"<?php echo whoop_section_spacing_style(); ?>>
	<div class="container">
		<div class="contact-faq-grid">
			<div class="contact-faq-panel contact-faq-panel-left reveal">
				<?php if ( $left_title ) : ?>
					<h2><?php echo esc_html( $left_title ); ?></h2>
				<?php endif; ?>
				<?php if ( $left_subtitle ) : ?>
					<p><?php echo esc_html( $left_subtitle ); ?></p>
				<?php endif; ?>
				<?php if ( $left_cta_text ) : ?>
					<a href="<?php echo esc_url( $left_cta_url ); ?>" class="btn btn-secondary contact-faq-cta"><?php echo esc_html( $left_cta_text ); ?></a>
				<?php endif; ?>
			</div>

			<div class="contact-faq-panel contact-faq-panel-form reveal reveal-delay-1">
				<?php if ( $form_title ) : ?>
					<h3><?php echo esc_html( $form_title ); ?></h3>
				<?php endif; ?>
				<?php if ( $form_subtitle ) : ?>
					<p class="contact-faq-form-subtitle"><?php echo esc_html( $form_subtitle ); ?></p>
				<?php endif; ?>

				<form class="contact-faq-form" action="#" method="post" onsubmit="return false">
					<label class="contact-faq-field">
						<span><?php echo esc_html( $name_label ); ?></span>
						<input type="text" name="contact_name" placeholder="<?php echo esc_attr( $name_placeholder ); ?>" required />
					</label>

					<label class="contact-faq-field">
						<span><?php echo esc_html( $phone_label ); ?></span>
						<input type="tel" name="contact_phone" placeholder="<?php echo esc_attr( $phone_placeholder ); ?>" required />
					</label>

					<label class="contact-faq-consent">
						<input type="checkbox" name="contact_consent" required />
						<span>
							<?php if ( $consent_prefix ) : ?>
								<?php echo esc_html( $consent_prefix ); ?>
							<?php endif; ?>
							<a href="<?php echo esc_url( $consent_link_url ); ?>"><?php echo esc_html( $consent_link_text ); ?></a>
							<?php if ( $consent_suffix ) : ?>
								<?php echo ' ' . esc_html( $consent_suffix ); ?>
							<?php endif; ?>
						</span>
					</label>

					<button type="submit" class="btn btn-primary contact-faq-submit"><?php echo esc_html( $submit_text ); ?></button>
				</form>
			</div>
		</div>
	</div>
</section>
