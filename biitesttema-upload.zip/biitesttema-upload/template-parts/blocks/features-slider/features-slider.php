<?php
/**
 * Features Slider block.
 *
 * ACF fields:
 *   headline (textarea)
 *   subline (textarea)
 *   features (repeater)
 *     - card_image (image)
 *     - card_title (text)
 *     - tiers (text)               — e.g. "PEAK | LIFE"
 *     - modal_title (text)
 *     - modal_description (textarea)
 *     - modal_image (image)
 *     - quote (textarea)
 *
 * @package whoop-clone
 */

defined( 'ABSPATH' ) || exit;

$headline = whoop_field( 'headline' );
$subline  = whoop_field( 'subline' );
$features = whoop_field( 'features' );

if ( empty( $features ) || ! is_array( $features ) ) {
	$features = array();
}

// Unique IDs because more than one features block can exist.
$block_uid = 'feat-' . substr( md5( $block['id'] ?? wp_unique_id() ), 0, 8 );
?>
<section class="features" id="<?php echo esc_attr( $block_uid ); ?>"<?php echo whoop_section_spacing_style(); ?>>
	<?php if ( $headline || $subline ) : ?>
		<div class="features-intro">
			<?php if ( $headline ) : ?><h2 class="reveal reveal-delay-1"><?php echo wp_kses_post( $headline ); ?></h2><?php endif; ?>
			<?php if ( $subline ) : ?><p class="reveal reveal-delay-2"><?php echo wp_kses_post( $subline ); ?></p><?php endif; ?>
		</div>
	<?php endif; ?>

	<div class="feature-slider">
		<div class="feature-track" id="<?php echo esc_attr( $block_uid ); ?>-track">
			<?php foreach ( $features as $i => $feat ) :
				$card_img    = $feat['card_image'] ?? null;
				$card_title  = $feat['card_title'] ?? '';
				?>
				<div class="feature-card">
					<?php if ( $card_img ) : ?>
						<img src="<?php echo esc_url( whoop_image_src( $card_img, 'whoop-card' ) ); ?>" alt="<?php echo esc_attr( whoop_image_alt( $card_img, $card_title ) ); ?>" />
					<?php endif; ?>
					<?php if ( $card_title ) : ?>
						<div class="feature-card-content"><h3><?php echo esc_html( $card_title ); ?></h3></div>
					<?php endif; ?>
				</div>
			<?php endforeach; ?>
		</div>

		<div class="slider-arrows">
			<button class="slider-arrow" data-arrow="prev" data-track="<?php echo esc_attr( $block_uid ); ?>-track" aria-label="<?php esc_attr_e( 'Previous', 'whoop-clone' ); ?>" disabled>
				<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M15 18l-6-6 6-6" stroke-linecap="round" stroke-linejoin="round"/></svg>
			</button>
			<button class="slider-arrow" data-arrow="next" data-track="<?php echo esc_attr( $block_uid ); ?>-track" aria-label="<?php esc_attr_e( 'Next', 'whoop-clone' ); ?>">
				<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M9 18l6-6-6-6" stroke-linecap="round" stroke-linejoin="round"/></svg>
			</button>
		</div>
	</div>
</section>
