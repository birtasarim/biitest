<?php
/**
 * Hero block — sticky video hero with scroll-driven overlay.
 *
 * ACF fields:
 *   - headline (textarea)
 *   - subline (textarea)
 *   - video_file (file)          — uploaded mp4/webm/mov
 *   - video_url (url)            — direct .mp4 or YouTube url
 *   - poster_image (image)       — fallback / poster
 *   - cta_primary_text (text)
 *   - cta_primary_url (url)
 *   - cta_secondary_text (text)
 *   - cta_secondary_url (url)
 *
 * @package whoop-clone
 */

defined( 'ABSPATH' ) || exit;

$headline     = whoop_field( 'headline' ) ?: '';
$subline      = whoop_field( 'subline' ) ?: '';
$video_file        = whoop_field( 'video_file' );
$video_file_mobile = whoop_field( 'video_file_mobile' );
$video_url         = whoop_field( 'video_url' ) ?: '';
$poster_image      = whoop_field( 'poster_image' );
$poster_url   = whoop_image_src( $poster_image, 'full' );
$cta1_text    = whoop_field( 'cta_primary_text' ) ?: '';
$cta1_url     = whoop_field( 'cta_primary_url' ) ?: '#';
$cta2_text    = whoop_field( 'cta_secondary_text' ) ?: '';
$cta2_url     = whoop_field( 'cta_secondary_url' ) ?: '#';

$anchor = ! empty( $block['anchor'] ) ? sanitize_html_class( $block['anchor'] ) : 'heroPin';

$youtube_id = '';
$embed_url  = '';
$video_src  = '';

if ( is_array( $video_file ) && ! empty( $video_file['url'] ) ) {
	$video_src = (string) $video_file['url'];
} elseif ( is_string( $video_file ) && '' !== trim( $video_file ) ) {
	$video_src = trim( $video_file );
}

$video_src_mobile = '';
if ( is_array( $video_file_mobile ) && ! empty( $video_file_mobile['url'] ) ) {
	$video_src_mobile = (string) $video_file_mobile['url'];
} elseif ( is_string( $video_file_mobile ) && '' !== trim( $video_file_mobile ) ) {
	$video_src_mobile = trim( $video_file_mobile );
}

if ( '' === $video_src && $video_url ) {
	$parts = wp_parse_url( $video_url );
	$host  = isset( $parts['host'] ) ? strtolower( $parts['host'] ) : '';
	$path  = isset( $parts['path'] ) ? trim( $parts['path'], '/' ) : '';

	if ( false !== strpos( $host, 'youtu.be' ) && '' !== $path ) {
		$youtube_id = strtok( $path, '/' );
	} elseif ( false !== strpos( $host, 'youtube.com' ) ) {
		if ( ! empty( $parts['query'] ) ) {
			parse_str( $parts['query'], $query_args );
			if ( ! empty( $query_args['v'] ) ) {
				$youtube_id = (string) $query_args['v'];
			}
		}

		if ( '' === $youtube_id && '' !== $path ) {
			$path_parts = explode( '/', $path );
			$key_index  = array_search( 'embed', $path_parts, true );
			if ( false === $key_index ) {
				$key_index = array_search( 'shorts', $path_parts, true );
			}
			if ( false !== $key_index && ! empty( $path_parts[ $key_index + 1 ] ) ) {
				$youtube_id = (string) $path_parts[ $key_index + 1 ];
			}
		}
	}

	if ( '' !== $youtube_id ) {
		$youtube_id = preg_replace( '/[^A-Za-z0-9_-]/', '', $youtube_id );
		$embed_url  = sprintf(
			'https://www.youtube-nocookie.com/embed/%1$s?autoplay=1&mute=1&controls=0&loop=1&playlist=%1$s&playsinline=1&rel=0&modestbranding=1&iv_load_policy=3&disablekb=1&fs=0&cc_load_policy=0&autohide=1&showinfo=0&start=1',
			rawurlencode( $youtube_id )
		);
	}
}
?>
<div class="hero-pin" id="<?php echo esc_attr( $anchor ); ?>">
	<section class="hero">
		<?php if ( $embed_url ) : ?>
			<div class="hero-video hero-video-embed" aria-hidden="true">
				<iframe
					class="hero-video-frame"
					src="<?php echo esc_url( $embed_url ); ?>"
					title="<?php esc_attr_e( 'Hero background video', 'whoop-clone' ); ?>"
					allow="autoplay; encrypted-media; picture-in-picture"
					referrerpolicy="strict-origin-when-cross-origin"
					tabindex="-1"
				></iframe>
			</div>
		<?php elseif ( $video_src || $video_url ) :
			$desktop_src = esc_url( $video_src ?: $video_url );
			$mobile_src  = $video_src_mobile ? esc_url( $video_src_mobile ) : '';
			$final_src   = $desktop_src;
			?>
			<?php if ( $mobile_src ) : ?>
			<video class="hero-video" id="heroVideo" autoplay muted loop playsinline preload="auto"
				<?php echo $poster_url ? 'poster="' . esc_url( $poster_url ) . '"' : ''; ?>
				data-src-desktop="<?php echo $desktop_src; ?>" data-src-mobile="<?php echo $mobile_src; ?>">
			</video>
			<script>
			(function(){
				var v = document.getElementById('heroVideo');
				if (!v) return;
				var d = v.dataset.srcDesktop, m = v.dataset.srcMobile;
				if (!d || !m) return;
				v.src = window.innerWidth <= 880 ? m : d;
				v.load();
				v.play().catch(function(){});
			})();
			</script>
			<?php else : ?>
			<video class="hero-video" id="heroVideo" autoplay muted loop playsinline preload="auto"
				<?php echo $poster_url ? 'poster="' . esc_url( $poster_url ) . '"' : ''; ?>
				src="<?php echo $desktop_src; ?>">
			</video>
			<?php endif; ?>
		<?php elseif ( $poster_url ) : ?>
			<img class="hero-poster" src="<?php echo esc_url( $poster_url ); ?>" alt="<?php echo esc_attr( whoop_image_alt( $poster_image, '' ) ); ?>" />
		<?php endif; ?>

		<div class="hero-overlay" id="heroOverlay" aria-hidden="true"></div>

		<div class="hero-content container">
			<?php if ( $headline ) : ?>
				<h1 class="hero-title"><?php echo wp_kses_post( $headline ); ?></h1>
			<?php endif; ?>

			<?php if ( $subline ) : ?>
				<p class="hero-sub"><?php echo wp_kses_post( $subline ); ?></p>
			<?php endif; ?>

			<?php if ( $cta1_text || $cta2_text ) : ?>
				<div class="hero-actions">
					<?php if ( $cta1_text ) : ?>
						<a href="<?php echo esc_url( $cta1_url ); ?>" class="btn btn-on-dark hero-cta-primary">
							<span><?php echo esc_html( $cta1_text ); ?></span>
							<span class="arrow" aria-hidden="true">
								<svg viewBox="0 0 20 20" width="16" height="16" fill="none">
									<path d="M4 10h10" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>
									<path d="M10 5l5 5-5 5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
								</svg>
							</span>
						</a>
					<?php endif; ?>
					<?php if ( $cta2_text ) : ?>
						<a href="<?php echo esc_url( $cta2_url ); ?>" class="btn btn-secondary-on-dark"><?php echo esc_html( $cta2_text ); ?></a>
					<?php endif; ?>
				</div>
			<?php endif; ?>
		</div>

	</section>
</div>
