<?php
/**
 * FAQs block.
 *
 * @package whoop-clone
 */

defined( 'ABSPATH' ) || exit;

$hero_image = whoop_field( 'hero_image' );
$headline   = whoop_field( 'headline' );
$subline    = whoop_field( 'subline' );
$intro_copy = whoop_field( 'intro_copy' );
$items      = whoop_field( 'items' );

if ( ! is_array( $items ) ) {
	$items = array();
}

$items = array_values(
	array_filter(
		$items,
		static function ( $item ) {
			return is_array( $item ) && ( ! empty( $item['question'] ) || ! empty( $item['answer'] ) );
		}
	)
);

$hero_style = '';

if ( $hero_image ) {
	$hero_style = sprintf( " style=\"background-image:url('%s');\"", esc_url( whoop_image_src( $hero_image, 'full' ) ) );
}
?>
<section class="faqs-block"<?php echo whoop_section_spacing_style(); ?>>
	<div class="container">
		<div class="faqs-block-hero reveal"<?php echo $hero_style; ?>>
			<div class="faqs-block-hero-overlay"></div>
			<div class="faqs-block-hero-copy">
				<?php if ( $headline ) : ?>
					<h2><?php echo wp_kses_post( nl2br( esc_html( $headline ) ) ); ?></h2>
				<?php endif; ?>
				<?php if ( $subline ) : ?>
					<p><?php echo esc_html( $subline ); ?></p>
				<?php endif; ?>
			</div>
		</div>

		<div class="faqs-block-shell reveal reveal-delay-1">
			<div class="faqs-block-topline">
				<div class="faqs-block-topline-rule" aria-hidden="true"></div>
				<?php if ( $intro_copy ) : ?>
					<div class="faqs-block-intro">
						<p><?php echo esc_html( $intro_copy ); ?></p>
					</div>
				<?php endif; ?>
			</div>

			<?php if ( empty( $items ) ) : ?>
				<div class="faqs-block-empty">
					<strong><?php esc_html_e( 'Add FAQ items to build this section.', 'whoop-clone' ); ?></strong>
					<p><?php esc_html_e( 'Use question and answer pairs to populate the accordion below the hero area.', 'whoop-clone' ); ?></p>
				</div>
			<?php else : ?>
				<div class="faqs-block-list" data-faqs>
					<?php foreach ( $items as $index => $item ) : ?>
						<?php
						$question = $item['question'] ?? '';
						$answer   = $item['answer'] ?? '';

						if ( '' === trim( $question . $answer ) ) {
							continue;
						}

						$item_id  = 'faq-item-' . wp_unique_id();
						$is_open  = 0 === $index;
						?>
						<article class="faqs-block-item<?php echo $is_open ? ' is-open' : ''; ?>">
							<button
								type="button"
								class="faqs-block-trigger"
								aria-expanded="<?php echo $is_open ? 'true' : 'false'; ?>"
								aria-controls="<?php echo esc_attr( $item_id ); ?>"
							>
								<span class="faqs-block-index"><?php echo esc_html( str_pad( (string) ( $index + 1 ), 2, '0', STR_PAD_LEFT ) ); ?></span>
								<span class="faqs-block-question"><?php echo esc_html( $question ); ?></span>
								<span class="faqs-block-icon" aria-hidden="true"></span>
							</button>
							<div
								id="<?php echo esc_attr( $item_id ); ?>"
								class="faqs-block-panel"
								<?php echo $is_open ? '' : 'hidden'; ?>
							>
								<div class="faqs-block-answer">
									<?php echo wp_kses_post( wpautop( $answer ) ); ?>
								</div>
							</div>
						</article>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
		</div>
	</div>
</section>
