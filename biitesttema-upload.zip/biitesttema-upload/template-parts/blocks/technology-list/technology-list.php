<?php
/**
 * Technology list block.
 *
 * ACF fields:
 *   headline (textarea)
 *   subline (textarea)
 *   items (repeater)
 *     - image (image)
 *     - title (text)
 *     - description (textarea)
 *
 * @package whoop-clone
 */

defined( 'ABSPATH' ) || exit;

$headline = whoop_field( 'headline' );
$subline  = whoop_field( 'subline' );
$items    = whoop_field( 'items' );

if ( ! is_array( $items ) ) {
	$items = array();
}

$items = array_values(
	array_filter(
		$items,
		static function ( $item ) {
			return is_array( $item ) && ( ! empty( $item['image'] ) || ! empty( $item['title'] ) || ! empty( $item['description'] ) );
		}
	)
);

?>
<section class="technology-list"<?php echo whoop_section_spacing_style(); ?>>
	<div class="container">
		<?php if ( $headline || $subline ) : ?>
			<div class="technology-list-head reveal">
				<?php if ( $headline ) : ?>
					<h2><?php echo esc_html( $headline ); ?></h2>
				<?php endif; ?>
				<?php if ( $subline ) : ?>
					<p><?php echo esc_html( $subline ); ?></p>
				<?php endif; ?>
			</div>
		<?php endif; ?>

		<div class="technology-list-shell reveal reveal-delay-1">
			<?php if ( ! $headline && ! $subline && empty( $items ) ) : ?>
				<div class="technology-list-empty">
					<strong><?php esc_html_e( 'Add the title, subtitle, and technology items to build this section.', 'whoop-clone' ); ?></strong>
					<p><?php esc_html_e( 'Each item should include its own 900 × 1200 image plus a title and description.', 'whoop-clone' ); ?></p>
				</div>
			<?php else : ?>
			<div class="technology-list-grid" data-technology-list>
				<div class="technology-list-visuals">
					<?php foreach ( $items as $index => $item ) : ?>
						<?php $item_image = $item['image'] ?? null; ?>
						<div class="technology-list-visual<?php echo 0 === $index ? ' is-active' : ''; ?>" data-technology-image="<?php echo esc_attr( $index ); ?>">
							<?php if ( $item_image ) : ?>
								<img src="<?php echo esc_url( whoop_image_src( $item_image, 'whoop-portrait' ) ); ?>" alt="<?php echo esc_attr( whoop_image_alt( $item_image, $item['title'] ?? $headline ) ); ?>" />
							<?php else : ?>
								<div class="technology-list-placeholder">
									<span>BiiTest</span>
									<strong>900 × 1200</strong>
								</div>
							<?php endif; ?>
						</div>
					<?php endforeach; ?>
				</div>

				<div class="technology-list-items">
					<?php foreach ( $items as $index => $item ) : ?>
						<button type="button" class="technology-list-item<?php echo 0 === $index ? ' is-active' : ''; ?>" data-technology-trigger="<?php echo esc_attr( $index ); ?>">
							<?php $item_image = $item['image'] ?? null; ?>
							<div class="technology-list-item-mobile-visual">
								<?php if ( $item_image ) : ?>
									<img src="<?php echo esc_url( whoop_image_src( $item_image, 'whoop-portrait' ) ); ?>" alt="<?php echo esc_attr( whoop_image_alt( $item_image, $item['title'] ?? $headline ) ); ?>" />
								<?php else : ?>
									<div class="technology-list-placeholder">
										<span>BiiTest</span>
										<strong>900 × 1200</strong>
									</div>
								<?php endif; ?>
							</div>
							<div class="technology-list-item-index"><?php echo esc_html( str_pad( (string) ( $index + 1 ), 2, '0', STR_PAD_LEFT ) ); ?></div>
							<div class="technology-list-item-copy">
								<?php if ( ! empty( $item['title'] ) ) : ?>
									<h3><?php echo esc_html( $item['title'] ); ?></h3>
								<?php endif; ?>
								<?php if ( ! empty( $item['description'] ) ) : ?>
									<p><?php echo esc_html( $item['description'] ); ?></p>
								<?php endif; ?>
							</div>
						</button>
					<?php endforeach; ?>
				</div>
			</div>
			<?php endif; ?>
		</div>
	</div>
</section>
