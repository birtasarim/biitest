<?php
/**
 * Principles block — left accordion list + right cross-fading image.
 *
 * ACF fields:
 *   headline (text)
 *   principles (repeater)
 *     - title (text)
 *     - description (textarea)
 *     - image (image)
 *
 * @package whoop-clone
 */

defined( 'ABSPATH' ) || exit;

$headline   = whoop_field( 'headline' );
$principles = whoop_field( 'principles' );

if ( ! is_array( $principles ) ) {
	$principles = array();
}

$principles_mobile_image = null;
foreach ( $principles as $principle ) {
	if ( ! empty( $principle['image'] ) ) {
		$principles_mobile_image = $principle['image'];
		break;
	}
}
?>
<section class="principles"<?php echo whoop_section_spacing_style(); ?>>
	<div class="principles-grid-new">
		<div class="principles-left">
			<?php if ( $headline ) : ?>
				<h2 class="reveal reveal-early"><?php echo esc_html( $headline ); ?></h2>
			<?php endif; ?>
			<div class="principles-list" id="principlesList">
				<?php foreach ( $principles as $i => $p ) : ?>
					<div class="principle-row<?php echo 0 === $i ? ' is-active' : ''; ?>" data-principle="<?php echo esc_attr( $i ); ?>">
						<?php if ( ! empty( $p['title'] ) ) : ?>
							<div class="principle-title"><?php echo esc_html( $p['title'] ); ?></div>
						<?php endif; ?>
						<?php if ( ! empty( $p['description'] ) ) : ?>
							<div class="principle-desc"><?php echo esc_html( $p['description'] ); ?></div>
						<?php endif; ?>
					</div>
				<?php endforeach; ?>
			</div>
		</div>

		<div class="principles-visual reveal reveal-early">
			<?php foreach ( $principles as $i => $p ) :
				if ( empty( $p['image'] ) ) {
					continue;
				}
				$src = whoop_image_src( $p['image'], 'whoop-square' );
				?>
				<img class="<?php echo 0 === $i ? 'is-active' : ''; ?>"
				     data-img="<?php echo esc_attr( $i ); ?>"
				     src="<?php echo esc_url( $src ); ?>"
				     alt="<?php echo esc_attr( whoop_image_alt( $p['image'], $p['title'] ?? '' ) ); ?>" />
			<?php endforeach; ?>
		</div>
	</div>

	<?php if ( ! empty( $principles ) ) : ?>
		<div class="principles-mobile-cards">
			<?php if ( $principles_mobile_image ) : ?>
				<div class="principles-mobile-visual reveal">
					<img src="<?php echo esc_url( whoop_image_src( $principles_mobile_image, 'whoop-square' ) ); ?>" alt="<?php echo esc_attr( whoop_image_alt( $principles_mobile_image, $headline ?: '' ) ); ?>" />
				</div>
			<?php endif; ?>
			<?php foreach ( $principles as $i => $p ) :
				$title = $p['title'] ?? '';
				$desc  = $p['description'] ?? '';

				if ( '' === trim( $title . $desc ) ) {
					continue;
				}
				?>
				<article class="principles-mobile-card reveal<?php echo $i > 0 ? esc_attr( ' reveal-delay-' . min( $i, 4 ) ) : ''; ?>">
					<div class="principles-mobile-index"><?php echo esc_html( str_pad( (string) ( $i + 1 ), 2, '0', STR_PAD_LEFT ) ); ?></div>
					<div class="principles-mobile-copy">
						<?php if ( $title ) : ?>
							<h3><?php echo esc_html( $title ); ?></h3>
						<?php endif; ?>
						<?php if ( $desc ) : ?>
							<p><?php echo esc_html( $desc ); ?></p>
						<?php endif; ?>
					</div>
				</article>
			<?php endforeach; ?>
		</div>
	<?php endif; ?>
</section>
