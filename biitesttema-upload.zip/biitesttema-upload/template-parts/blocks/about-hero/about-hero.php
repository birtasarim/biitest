<?php
/**
 * About hero block.
 *
 * @package whoop-clone
 */

defined( 'ABSPATH' ) || exit;

$hero_image   = whoop_field( 'hero_image' );
$headline     = whoop_field( 'headline' );
$subline      = whoop_field( 'subline' );
$about_image  = whoop_field( 'about_image' );
$about_title  = whoop_field( 'about_title' );
$about_text   = whoop_field( 'about_text' );
$cta_text     = whoop_field( 'cta_text' );
$cta_url      = whoop_field( 'cta_url' ) ?: '#';

$hero_style = '';
if ( $hero_image ) {
	$hero_style = sprintf( " style=\"background-image:url('%s');\"", esc_url( whoop_image_src( $hero_image, 'full' ) ) );
}
?>
<section class="about-hero">
	<div class="about-hero-top"<?php echo $hero_style; ?>>
		<div class="about-hero-overlay"></div>
		<div class="container">
			<div class="about-hero-copy reveal">
				<?php if ( $headline ) : ?>
					<h2><?php echo wp_kses_post( nl2br( esc_html( $headline ) ) ); ?></h2>
				<?php endif; ?>
				<?php if ( $subline ) : ?>
					<p><?php echo esc_html( $subline ); ?></p>
				<?php endif; ?>
			</div>
		</div>
		<div class="about-hero-curve" aria-hidden="true"></div>
	</div>

	<div class="about-hero-body">
		<div class="container">
			<div class="about-hero-grid reveal reveal-delay-1">
				<div class="about-hero-visual<?php echo $about_image ? '' : ' is-placeholder'; ?>">
					<?php if ( $about_image ) : ?>
						<img src="<?php echo esc_url( whoop_image_src( $about_image, 'whoop-portrait' ) ); ?>" alt="<?php echo esc_attr( whoop_image_alt( $about_image, $about_title ?: $headline ) ); ?>" />
					<?php else : ?>
						<div class="about-hero-placeholder">
							<span>BiiTest</span>
							<strong>900 × 1200</strong>
						</div>
					<?php endif; ?>
				</div>

				<div class="about-hero-content">
					<?php if ( $about_title ) : ?>
						<h2><?php echo esc_html( $about_title ); ?></h2>
					<?php endif; ?>
					<?php if ( $about_text ) : ?>
						<div class="about-hero-text"><?php echo wp_kses_post( wpautop( $about_text ) ); ?></div>
					<?php endif; ?>
					<?php if ( $cta_text ) : ?>
						<a href="<?php echo esc_url( $cta_url ); ?>" class="btn btn-primary"><?php echo esc_html( $cta_text ); ?></a>
					<?php endif; ?>
				</div>
			</div>
		</div>
	</div>
</section>
