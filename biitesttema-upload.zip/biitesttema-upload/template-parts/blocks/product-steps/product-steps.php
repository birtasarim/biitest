<?php
/**
 * Product steps block.
 *
 * @package whoop-clone
 */

defined( 'ABSPATH' ) || exit;

$headline = whoop_field( 'headline' );
$subline  = whoop_field( 'subline' );
$steps    = whoop_field( 'steps' );

if ( ! is_array( $steps ) ) {
	$steps = array();
}

$steps = array_values(
	array_filter(
		$steps,
		static function ( $step ) {
			return is_array( $step ) && ( ! empty( $step['label'] ) || ! empty( $step['title'] ) || ! empty( $step['text'] ) );
		}
	)
);
?>
<section class="product-steps"<?php echo whoop_section_spacing_style(); ?>>
	<div class="container">
		<?php if ( $headline || $subline ) : ?>
			<div class="product-steps-head reveal">
				<?php if ( $headline ) : ?>
					<h2><?php echo esc_html( $headline ); ?></h2>
				<?php endif; ?>
				<?php if ( $subline ) : ?>
					<p><?php echo esc_html( $subline ); ?></p>
				<?php endif; ?>
			</div>
		<?php endif; ?>

		<?php if ( empty( $steps ) ) : ?>
			<div class="product-steps-empty reveal reveal-delay-1">
				<strong><?php esc_html_e( 'Add product process steps to build this section.', 'whoop-clone' ); ?></strong>
				<p><?php esc_html_e( 'Use the repeater to add step labels, titles, and short supporting text.', 'whoop-clone' ); ?></p>
			</div>
		<?php else : ?>
			<div class="product-steps-grid">
				<?php foreach ( $steps as $index => $step ) : ?>
					<?php
					$label = $step['label'] ?? '';
					$title = $step['title'] ?? '';
					$text  = $step['text'] ?? '';
					?>
					<article class="product-steps-card reveal<?php echo $index > 0 ? esc_attr( ' reveal-delay-' . min( $index, 4 ) ) : ''; ?>">
						<div class="product-steps-card-bar" aria-hidden="true"></div>
						<?php if ( $label ) : ?>
							<div class="product-steps-label"><?php echo esc_html( $label ); ?></div>
						<?php else : ?>
							<div class="product-steps-label"><?php echo esc_html( sprintf( __( 'ADIM %02d', 'whoop-clone' ), $index + 1 ) ); ?></div>
						<?php endif; ?>
						<div class="product-steps-copy">
							<?php if ( $title ) : ?>
								<h3><?php echo esc_html( $title ); ?></h3>
							<?php endif; ?>
							<?php if ( $text ) : ?>
								<p><?php echo esc_html( $text ); ?></p>
							<?php endif; ?>
						</div>
					</article>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>
	</div>
</section>
