<?php
/**
 * Trial block.
 *
 * ACF fields:
 *   title (text)
 *   description (textarea)
 *   cta_text (text)
 *   cta_url (url)
 *   visual_image (image)
 *   show_join (true_false)
 *   join_text (text)
 *   join_url (url)
 *
 * @package whoop-clone
 */

defined( 'ABSPATH' ) || exit;

$title       = whoop_field( 'title' );
$description = whoop_field( 'description' );
$cta_text    = whoop_field( 'cta_text' );
$cta_url     = whoop_field( 'cta_url' ) ?: '#';
$visual      = whoop_field( 'visual_image' );
?>
<div class="trial-wrap">
	<section class="trial reveal" id="trial"<?php echo whoop_section_spacing_style(); ?>>
		<div class="trial-grid">
			<div class="trial-content">
				<?php if ( $title ) : ?><h2><?php echo esc_html( $title ); ?></h2><?php endif; ?>
				<?php if ( $description ) : ?><p><?php echo esc_html( $description ); ?></p><?php endif; ?>
				<?php if ( $cta_text ) : ?>
					<a href="<?php echo esc_url( $cta_url ); ?>" class="btn"><?php echo esc_html( $cta_text ); ?></a>
				<?php endif; ?>
			</div>
			<?php if ( $visual ) : ?>
				<div class="trial-visual">
					<img src="<?php echo esc_url( whoop_image_src( $visual, 'full' ) ); ?>" alt="<?php echo esc_attr( whoop_image_alt( $visual, $title ?: '' ) ); ?>" />
				</div>
			<?php endif; ?>
		</div>
	</section>
</div>
