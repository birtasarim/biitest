<?php
/**
 * Product Showcase block.
 *
 * @package whoop-clone
 */

defined( 'ABSPATH' ) || exit;

$headline = whoop_field( 'headline' );
$subline  = whoop_field( 'subline' );
$products = whoop_field( 'products' );

if ( empty( $products ) || ! is_array( $products ) ) {
	$products = array();
}
?>
<section class="prod-showcase"<?php echo whoop_section_spacing_style(); ?>>
	<div class="container">
		<?php if ( $headline || $subline ) : ?>
			<div class="prod-showcase-intro">
				<?php if ( $headline ) : ?>
					<h2 class="headline headline-h2 reveal"><?php echo wp_kses_post( $headline ); ?></h2>
				<?php endif; ?>
				<?php if ( $subline ) : ?>
					<p class="reveal reveal-delay-1"><?php echo wp_kses_post( $subline ); ?></p>
				<?php endif; ?>
			</div>
		<?php endif; ?>

		<?php if ( ! empty( $products ) ) : ?>
			<div class="prod-showcase-grid">
				<?php foreach ( $products as $i => $prod ) :
					$badge_text   = $prod['badge_text'] ?? '';
					$badge_color  = $prod['badge_color'] ?? '#ff4d4d';
					$product_logo = $prod['product_logo'] ?? null;
					$subtitle     = $prod['subtitle'] ?? '';
					$img          = $prod['image'] ?? null;
					$rating       = $prod['rating'] ?? '';
					$rating_count = $prod['rating_count'] ?? '';
					$title        = $prod['title'] ?? '';
					$old_price    = $prod['old_price'] ?? '';
					$new_price    = $prod['new_price'] ?? '';
					$features     = $prod['features'] ?? array();
					$certs        = $prod['certificates'] ?? array();
					$cta_text     = $prod['cta_text'] ?? '';
					$cta_url      = $prod['cta_url'] ?? '#';
					$cta2_text    = $prod['cta_secondary_text'] ?? '';
					$cta2_url     = $prod['cta_secondary_url'] ?? '#';
					$delay_class  = 'reveal reveal-delay-' . min( $i + 1, 3 );
					?>
					<article class="prod-card <?php echo esc_attr( $delay_class ); ?>">
						<?php if ( $badge_text ) : ?>
							<span class="prod-badge" style="background:<?php echo esc_attr( $badge_color ); ?>"><?php echo esc_html( $badge_text ); ?></span>
						<?php endif; ?>

						<div class="prod-card-header">
							<?php if ( $product_logo ) : ?>
								<img class="prod-logo" src="<?php echo esc_url( whoop_image_src( $product_logo, 'medium' ) ); ?>" alt="<?php echo esc_attr( whoop_image_alt( $product_logo, $title ) ); ?>" />
							<?php endif; ?>
							<?php if ( $subtitle ) : ?>
								<p class="prod-subtitle"><?php echo esc_html( $subtitle ); ?></p>
							<?php endif; ?>
						</div>

						<?php if ( $img ) : ?>
							<div class="prod-card-visual">
								<img src="<?php echo esc_url( whoop_image_src( $img, 'large' ) ); ?>" alt="<?php echo esc_attr( whoop_image_alt( $img, $title ) ); ?>" />
							</div>
						<?php endif; ?>

						<?php if ( $rating ) : ?>
							<div class="prod-rating">
								<span class="prod-stars" aria-label="<?php echo esc_attr( $rating ); ?> / 5">
									<?php
									$full  = floor( (float) $rating );
									$half  = ( (float) $rating - $full ) >= 0.3;
									for ( $s = 0; $s < 5; $s++ ) :
										if ( $s < $full ) : ?>
											<svg viewBox="0 0 20 20" width="14" height="14"><path d="M10 1.3l2.4 5.3 5.6.5-4.2 3.8 1.3 5.5L10 13.5l-5.1 2.9 1.3-5.5L2 7.1l5.6-.5z" fill="currentColor"/></svg>
										<?php elseif ( $half && $s === $full ) : ?>
											<svg viewBox="0 0 20 20" width="14" height="14"><defs><linearGradient id="hg<?php echo $i; ?>"><stop offset="50%" stop-color="currentColor"/><stop offset="50%" stop-color="transparent"/></linearGradient></defs><path d="M10 1.3l2.4 5.3 5.6.5-4.2 3.8 1.3 5.5L10 13.5l-5.1 2.9 1.3-5.5L2 7.1l5.6-.5z" fill="url(#hg<?php echo $i; ?>)" stroke="currentColor" stroke-width="1"/></svg>
										<?php else : ?>
											<svg viewBox="0 0 20 20" width="14" height="14"><path d="M10 1.3l2.4 5.3 5.6.5-4.2 3.8 1.3 5.5L10 13.5l-5.1 2.9 1.3-5.5L2 7.1l5.6-.5z" fill="none" stroke="currentColor" stroke-width="1"/></svg>
										<?php endif;
									endfor; ?>
								</span>
								<span class="prod-rating-text"><?php echo esc_html( $rating ); ?><?php echo $rating_count ? ' (' . esc_html( $rating_count ) . ')' : ''; ?></span>
							</div>
						<?php endif; ?>

						<div class="prod-title-row">
							<?php if ( $title ) : ?>
								<h3 class="prod-card-title"><?php echo esc_html( $title ); ?></h3>
							<?php endif; ?>
							<?php if ( is_array( $certs ) && ! empty( $certs ) ) : ?>
								<div class="prod-certs">
									<?php foreach ( $certs as $cert ) :
										if ( empty( $cert['image'] ) ) continue; ?>
										<div class="prod-cert">
											<img src="<?php echo esc_url( whoop_image_src( $cert['image'], 'thumbnail' ) ); ?>" alt="<?php echo esc_attr( whoop_image_alt( $cert['image'], 'Certificate' ) ); ?>" />
										</div>
									<?php endforeach; ?>
								</div>
							<?php endif; ?>
						</div>

						<?php if ( $old_price || $new_price ) : ?>
							<div class="prod-price">
								<?php if ( $old_price ) : ?>
									<span class="prod-price-old"><?php echo esc_html( $old_price ); ?></span>
								<?php endif; ?>
								<?php if ( $new_price ) : ?>
									<span class="prod-price-new"><?php echo esc_html( $new_price ); ?></span>
								<?php endif; ?>
							</div>
						<?php endif; ?>

						<?php if ( is_array( $features ) && ! empty( $features ) ) : ?>
							<ul class="prod-features">
								<?php foreach ( $features as $feat ) :
									if ( empty( $feat['text'] ) ) continue;
									$highlight = ! empty( $feat['is_highlight'] );
									?>
									<li<?php echo $highlight ? ' class="highlight"' : ''; ?>>
										<svg class="prod-check" viewBox="0 0 20 20" width="16" height="16"><path d="M4 10l4 4 8-8" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
										<?php echo wp_kses_post( $feat['text'] ); ?>
									</li>
								<?php endforeach; ?>
							</ul>
						<?php endif; ?>

						<div class="prod-card-actions">
							<?php if ( $cta_text ) : ?>
								<a href="<?php echo esc_url( $cta_url ); ?>" class="prod-cta"><?php echo esc_html( $cta_text ); ?></a>
							<?php endif; ?>
							<?php if ( $cta2_text ) : ?>
								<a href="<?php echo esc_url( $cta2_url ); ?>" class="prod-cta-secondary"><?php echo esc_html( $cta2_text ); ?></a>
							<?php endif; ?>
						</div>
					</article>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>
	</div>
</section>
