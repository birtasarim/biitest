<?php
/**
 * Advanced Labs block — default mode + services grid mode.
 *
 * ACF fields:
 *   display_mode (select: default|grid)
 *   headline (text)
 *   iso_certificates (repeater)
 *   bullets (repeater)
 *   cta_text (text)
 *   cta_url (url)
 *   image (image)
 *   badges (repeater)
 *   grid_image (image, grid mode)
 *   grid_cards (repeater, grid mode)
 *     - label (text)
 *     - title (text)
 *     - description (textarea)
 *   show_join (true_false)
 *   join_text (text)
 *   join_url (url)
 *
 * @package whoop-clone
 */

defined( 'ABSPATH' ) || exit;

$display_mode     = whoop_field( 'display_mode' ) ?: 'default';
$headline         = whoop_field( 'headline' );
$iso_certificates = whoop_field( 'iso_certificates' );
$bullets          = whoop_field( 'bullets' );
$cta_text         = whoop_field( 'cta_text' );
$cta_url          = whoop_field( 'cta_url' ) ?: '#';
$image            = whoop_field( 'image' );
$badges           = whoop_field( 'badges' );
$grid_image       = whoop_field( 'grid_image' );
$grid_cards       = whoop_field( 'grid_cards' );

$position_class = array(
	'top-left'     => 'labs-badge-1',
	'mid-left'     => 'labs-badge-2',
	'bottom-right' => 'labs-badge-3',
);

if ( ! is_array( $grid_cards ) ) {
	$grid_cards = array();
}
$grid_cards = array_values(
	array_filter(
		$grid_cards,
		static function ( $card ) {
			return is_array( $card ) && ( ! empty( $card['title'] ) || ! empty( $card['description'] ) );
		}
	)
);

if ( 'grid' === $display_mode ) : ?>
<section class="labs labs-grid-mode" id="labs"<?php echo whoop_section_spacing_style(); ?>>
	<div class="container">
		<?php if ( $headline ) : ?>
			<h2 class="lgm-title reveal"><?php echo esc_html( $headline ); ?></h2>
		<?php endif; ?>

		<div class="lgm">
			<?php foreach ( $grid_cards as $i => $card ) :
				$card_img = $card['card_image'] ?? null;
				$has_img  = ! empty( $card_img );
				?>
				<div class="lgm-c lgm-c<?php echo esc_attr( $i + 1 ); ?><?php echo $has_img ? ' lgm-c--has-img' : ''; ?> reveal reveal-delay-<?php echo esc_attr( min( $i + 1, 4 ) ); ?>">
					<div class="lgm-c-copy">
						<?php if ( ! empty( $card['title'] ) ) : ?>
							<h3><?php echo esc_html( $card['title'] ); ?></h3>
						<?php endif; ?>
						<?php if ( ! empty( $card['description'] ) ) : ?>
							<p><?php echo esc_html( $card['description'] ); ?></p>
						<?php endif; ?>
					</div>
					<?php if ( $has_img ) : ?>
						<div class="lgm-c-img">
							<img src="<?php echo esc_url( whoop_image_src( $card_img, 'medium' ) ); ?>" alt="<?php echo esc_attr( whoop_image_alt( $card_img, $card['title'] ?? '' ) ); ?>" />
						</div>
					<?php endif; ?>
				</div>
			<?php endforeach; ?>
		</div>
	</div>
</section>

<?php else : ?>
<section class="labs" id="labs">
	<div class="container">
		<div class="labs-grid">
			<div class="labs-content">
				<?php if ( $headline ) : ?>
					<h2 class="reveal"><?php echo esc_html( $headline ); ?></h2>
				<?php endif; ?>

				<?php if ( is_array( $iso_certificates ) && ! empty( $iso_certificates ) ) : ?>
					<div class="labs-iso-certs reveal reveal-delay-1">
						<?php foreach ( $iso_certificates as $cert ) : ?>
							<?php if ( empty( $cert['image'] ) ) continue; ?>
							<div class="labs-iso-cert">
								<img src="<?php echo esc_url( whoop_image_src( $cert['image'], 'thumbnail' ) ); ?>" alt="<?php echo esc_attr( whoop_image_alt( $cert['image'], 'ISO Certificate' ) ); ?>" />
							</div>
						<?php endforeach; ?>
					</div>
				<?php endif; ?>

				<?php if ( is_array( $bullets ) && ! empty( $bullets ) ) : ?>
					<ul class="reveal reveal-delay-1">
						<?php foreach ( $bullets as $b ) :
							if ( empty( $b['text'] ) ) {
								continue;
							}
							?>
							<li>
								<span class="labs-check"><svg viewBox="0 0 16 16"><path d="M3 8l3 3 7-7"/></svg></span>
								<?php echo esc_html( $b['text'] ); ?>
							</li>
						<?php endforeach; ?>
					</ul>
				<?php endif; ?>

				<?php if ( $cta_text ) : ?>
					<a href="<?php echo esc_url( $cta_url ); ?>" class="btn-labs reveal reveal-delay-2"><?php echo esc_html( $cta_text ); ?></a>
				<?php endif; ?>
			</div>

			<div class="labs-visual reveal">
				<?php if ( $image ) : ?>
					<img src="<?php echo esc_url( whoop_image_src( $image, 'whoop-square' ) ); ?>" alt="<?php echo esc_attr( whoop_image_alt( $image, '' ) ); ?>" />
				<?php endif; ?>

				<?php if ( is_array( $badges ) && ! empty( $badges ) ) : ?>
					<div class="labs-overlay">
						<?php foreach ( $badges as $b ) :
							$pos = $b['badge_position'] ?? 'top-left';
							$cls = $position_class[ $pos ] ?? 'labs-badge-1';
							?>
							<div class="labs-badge <?php echo esc_attr( $cls ); ?>">
								<?php if ( ! empty( $b['badge_title'] ) ) : ?>
									<div class="labs-badge-title"><?php echo esc_html( $b['badge_title'] ); ?></div>
								<?php endif; ?>
								<?php if ( ! empty( $b['badge_status'] ) ) : ?>
									<div class="labs-badge-status"><?php echo esc_html( $b['badge_status'] ); ?></div>
								<?php endif; ?>
							</div>
						<?php endforeach; ?>
					</div>
				<?php endif; ?>
			</div>
		</div>
	</div>
</section>
<?php endif; ?>
