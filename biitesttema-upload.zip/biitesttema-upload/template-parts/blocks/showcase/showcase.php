<?php
/**
 * Showcase block — image left, pill tabs + content right.
 *
 * ACF fields:
 *   headline (text)
 *   tabs (repeater)
 *     - tab_label (text)         — pill label
 *     - tab_image (image)
 *     - tab_title (text)
 *     - tab_description (textarea)
 *
 * @package whoop-clone
 */

defined( 'ABSPATH' ) || exit;

$headline = whoop_field( 'headline' );
$tabs     = whoop_field( 'tabs' );

if ( ! is_array( $tabs ) ) {
	$tabs = array();
}
?>
<section class="showcase"<?php echo whoop_section_spacing_style(); ?>>
	<div class="container">
		<?php if ( $headline ) : ?>
			<div class="showcase-head reveal">
				<h2><?php echo esc_html( $headline ); ?></h2>
			</div>
		<?php endif; ?>

		<div class="showcase-stage">
			<div class="showcase-visual">
				<?php foreach ( $tabs as $i => $t ) :
					if ( empty( $t['tab_image'] ) ) {
						continue;
					}
					?>
					<div class="showcase-vis-layer<?php echo 0 === $i ? ' is-active' : ''; ?>" data-vis="<?php echo esc_attr( $i ); ?>">
						<img src="<?php echo esc_url( whoop_image_src( $t['tab_image'], 'whoop-square' ) ); ?>" alt="<?php echo esc_attr( whoop_image_alt( $t['tab_image'], $t['tab_label'] ?? '' ) ); ?>" />
					</div>
				<?php endforeach; ?>
			</div>

			<div class="showcase-info">
				<div class="showcase-tabs">
					<?php foreach ( $tabs as $i => $t ) : ?>
						<button class="showcase-tab<?php echo 0 === $i ? ' is-active' : ''; ?>" data-tab="<?php echo esc_attr( $i ); ?>">
							<?php echo esc_html( $t['tab_label'] ?? '' ); ?>
						</button>
					<?php endforeach; ?>
				</div>

				<?php foreach ( $tabs as $i => $t ) : ?>
					<div class="showcase-content" data-content="<?php echo esc_attr( $i ); ?>"<?php echo 0 !== $i ? ' hidden' : ''; ?>>
						<?php if ( ! empty( $t['tab_title'] ) ) : ?>
							<h3><?php echo esc_html( $t['tab_title'] ); ?></h3>
						<?php endif; ?>
						<?php if ( ! empty( $t['tab_description'] ) ) : ?>
							<p><?php echo esc_html( $t['tab_description'] ); ?></p>
						<?php endif; ?>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
	</div>
</section>
