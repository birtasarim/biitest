<?php
/**
 * Story page block — enhanced version.
 *
 * @package whoop-clone
 */

defined( 'ABSPATH' ) || exit;

$hero_image = whoop_field( 'hero_image' );
$headline   = whoop_field( 'headline' );
$subline    = whoop_field( 'subline' );
$hero_cta_text = whoop_field( 'hero_cta_text' );
$hero_cta_url  = whoop_field( 'hero_cta_url' ) ?: '#';
$stats      = whoop_field( 'stats' );
$sections   = whoop_field( 'sections' );

if ( ! is_array( $sections ) ) {
	$sections = array();
}
if ( ! is_array( $stats ) ) {
	$stats = array();
}

$sections = array_values(
	array_filter(
		$sections,
		static function ( $section ) {
			return is_array( $section ) && (
				! empty( $section['image'] ) ||
				! empty( $section['title'] ) ||
				! empty( $section['text'] ) ||
				! empty( $section['cta_text'] )
			);
		}
	)
);

$hero_style = '';
if ( $hero_image ) {
	$hero_style = sprintf( " style=\"background-image:url('%s');\"", esc_url( whoop_image_src( $hero_image, 'full' ) ) );
}
?>
<section class="story-page">
	<div class="story-page-hero"<?php echo $hero_style; ?>>
		<div class="story-page-hero-overlay"></div>
		<div class="container">
			<div class="story-page-hero-copy reveal">
				<?php if ( $headline ) : ?>
					<h1><?php echo wp_kses_post( nl2br( esc_html( $headline ) ) ); ?></h1>
				<?php endif; ?>
				<?php if ( $subline ) : ?>
					<p><?php echo esc_html( $subline ); ?></p>
				<?php endif; ?>
				<?php if ( $hero_cta_text ) : ?>
					<a href="<?php echo esc_url( $hero_cta_url ); ?>" class="btn btn-on-dark story-hero-cta"><?php echo esc_html( $hero_cta_text ); ?></a>
				<?php endif; ?>
			</div>
		</div>
		<div class="story-page-hero-curve" aria-hidden="true"></div>
	</div>

	<?php if ( ! empty( $stats ) ) : ?>
		<div class="story-stats reveal">
			<div class="container">
				<div class="story-stats-grid">
					<?php foreach ( $stats as $si => $stat ) :
						if ( empty( $stat['value'] ) ) continue;
						?>
						<div class="story-stat reveal-delay-<?php echo min( $si + 1, 4 ); ?>">
							<span class="story-stat-value"><?php echo esc_html( $stat['value'] ); ?></span>
							<span class="story-stat-label"><?php echo esc_html( $stat['label'] ?? '' ); ?></span>
						</div>
					<?php endforeach; ?>
				</div>
			</div>
		</div>
	<?php endif; ?>

	<div class="story-page-body">
		<div class="container">
			<?php if ( empty( $sections ) ) : ?>
				<div class="story-page-empty reveal reveal-delay-1">
					<strong><?php esc_html_e( 'Add story sections to build this page.', 'whoop-clone' ); ?></strong>
					<p><?php esc_html_e( 'Each section supports one image, a title, rich text, bullet list, and an optional CTA.', 'whoop-clone' ); ?></p>
				</div>
			<?php else : ?>
				<div class="story-page-sections">
					<?php foreach ( $sections as $index => $section ) : ?>
						<?php
						$image    = $section['image'] ?? null;
						$title    = $section['title'] ?? '';
						$text     = $section['text'] ?? '';
						$bullets  = $section['bullets'] ?? array();
						$cta_text = $section['cta_text'] ?? '';
						$cta_url  = $section['cta_url'] ?? '#';
						$bg_style = $section['bg_style'] ?? 'white';
						$reverse  = 1 === $index % 2;
						$bg_class = 'white' !== $bg_style ? ' story-section-' . esc_attr( $bg_style ) : '';
						?>
						<section class="story-page-section<?php echo $reverse ? ' is-reversed' : ''; ?><?php echo $bg_class; ?> reveal">
							<div class="story-page-section-visual<?php echo $image ? '' : ' is-placeholder'; ?>">
								<?php if ( $image ) : ?>
									<img src="<?php echo esc_url( whoop_image_src( $image, 'whoop-portrait' ) ); ?>" alt="<?php echo esc_attr( whoop_image_alt( $image, $title ?: $headline ) ); ?>" />
								<?php else : ?>
									<div class="story-page-placeholder">
										<span>BiiTest</span>
										<strong>900 × 1200</strong>
									</div>
								<?php endif; ?>
							</div>
							<div class="story-page-section-copy">
								<?php if ( $title ) : ?>
									<h2><?php echo esc_html( $title ); ?></h2>
								<?php endif; ?>
								<?php if ( $text ) : ?>
									<div class="story-page-section-text"><?php echo wp_kses_post( wpautop( $text ) ); ?></div>
								<?php endif; ?>
								<?php if ( is_array( $bullets ) && ! empty( $bullets ) ) : ?>
									<ul class="story-bullets">
										<?php foreach ( $bullets as $bullet ) :
											if ( empty( $bullet['text'] ) ) continue; ?>
											<li>
												<svg class="story-bullet-icon" viewBox="0 0 20 20" width="18" height="18"><path d="M4 10l4 4 8-8" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
												<?php echo wp_kses_post( $bullet['text'] ); ?>
											</li>
										<?php endforeach; ?>
									</ul>
								<?php endif; ?>
								<?php if ( $cta_text ) : ?>
									<a href="<?php echo esc_url( $cta_url ); ?>" class="btn btn-primary story-section-cta"><?php echo esc_html( $cta_text ); ?></a>
								<?php endif; ?>
							</div>
						</section>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
		</div>
	</div>
</section>
