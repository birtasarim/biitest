<?php
/**
 * Sample Benefits block.
 *
 * ACF fields:
 *   image (image)
 *   items (repeater)
 *     - title (text)
 *     - description (textarea)
 *
 * @package whoop-clone
 */

defined( 'ABSPATH' ) || exit;

$headline = whoop_field( 'headline' );
$subline  = whoop_field( 'subline' );
$image    = whoop_field( 'image' );
$items    = whoop_field( 'items' );

if ( ! is_array( $items ) || empty( $items ) ) {
	$items = array(
		array(
			'title'       => 'Ağrısız numune',
			'description' => 'Kan almaya gerek yok. Pratik ve acısız işlem.',
		),
		array(
			'title'       => 'Dış faktörlerden etkilenmez',
			'description' => 'Stres, beslenme veya günlük değişimler sonucu etkilemez.',
		),
		array(
			'title'       => 'Uzun süre korunabilir',
			'description' => 'Saç numunesi bozulmaz, analiz için ideal veri sağlar.',
		),
		array(
			'title'       => 'Stabil ve güvenilir sonuç',
			'description' => 'Daha tutarlı ve tekrar edilebilir analiz.',
		),
	);
}
?>
<section class="sample-benefits"<?php echo whoop_section_spacing_style(); ?>>
	<div class="container">
		<?php if ( $headline || $subline ) : ?>
			<div class="sample-benefits-head reveal">
				<?php if ( $headline ) : ?>
					<h2><?php echo wp_kses_post( $headline ); ?></h2>
				<?php endif; ?>
				<?php if ( $subline ) : ?>
					<p><?php echo wp_kses_post( $subline ); ?></p>
				<?php endif; ?>
			</div>
		<?php endif; ?>
		<div class="sample-benefits-grid">
			<div class="sample-benefits-visual reveal<?php echo $image ? '' : ' is-placeholder'; ?>">
				<?php if ( $image ) : ?>
					<img src="<?php echo esc_url( whoop_image_src( $image, 'large' ) ); ?>" alt="<?php echo esc_attr( whoop_image_alt( $image, '' ) ); ?>" />
				<?php else : ?>
					<div class="sample-benefits-placeholder-mark" aria-hidden="true"></div>
					<div class="sample-benefits-placeholder-copy">
						<div class="sample-benefits-placeholder-eyebrow">BiiTest</div>
						<h3>Saç numunesi ile stabil analiz</h3>
						<p>Bu alana ana section görseli gelecek.</p>
					</div>
				<?php endif; ?>
			</div>

			<div class="sample-benefits-list">
				<?php foreach ( $items as $index => $item ) :
					$title       = $item['title'] ?? '';
					$description = $item['description'] ?? '';

					if ( '' === trim( $title . $description ) ) {
						continue;
					}
					?>
					<article class="sample-benefit-card sample-benefit-card-<?php echo esc_attr( $index + 1 ); ?> reveal<?php echo $index > 0 ? esc_attr( ' reveal-delay-' . min( $index, 4 ) ) : ''; ?>">
						<div class="sample-benefit-index" aria-hidden="true"><?php echo esc_html( str_pad( (string) ( $index + 1 ), 2, '0', STR_PAD_LEFT ) ); ?></div>
						<div class="sample-benefit-copy">
							<?php if ( $title ) : ?>
								<h3><?php echo esc_html( $title ); ?></h3>
							<?php endif; ?>
							<?php if ( $description ) : ?>
								<p><?php echo esc_html( $description ); ?></p>
							<?php endif; ?>
						</div>
					</article>
				<?php endforeach; ?>
			</div>
		</div>
	</div>
</section>
