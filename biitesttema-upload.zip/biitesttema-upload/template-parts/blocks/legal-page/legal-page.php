<?php
/**
 * Legal page block.
 *
 * @package whoop-clone
 */

defined( 'ABSPATH' ) || exit;

$hero_image = whoop_field( 'hero_image' );
$headline   = whoop_field( 'headline' );
$subline    = whoop_field( 'subline' );
$content    = whoop_field( 'content' );
$page_title = get_the_title();

$headline = $headline ?: $page_title;

$has_content = '' !== trim(
	wp_strip_all_tags(
		(string) $content
	)
);

$hero_style = '';
if ( $hero_image ) {
	$hero_style = sprintf( " style=\"background-image:url('%s');\"", esc_url( whoop_image_src( $hero_image, 'full' ) ) );
}
?>
<section class="legal-page">
	<div class="legal-page-hero<?php echo $hero_image ? ' has-image' : ' is-plain'; ?>"<?php echo $hero_style; ?>>
		<div class="legal-page-hero-overlay"></div>
		<div class="container">
			<div class="legal-page-hero-copy">
				<?php if ( $headline ) : ?>
					<h2><?php echo wp_kses_post( nl2br( esc_html( $headline ) ) ); ?></h2>
				<?php endif; ?>
				<?php if ( $subline ) : ?>
					<p><?php echo esc_html( $subline ); ?></p>
				<?php endif; ?>
			</div>
		</div>
		<div class="legal-page-hero-curve" aria-hidden="true"></div>
	</div>

	<div class="legal-page-body">
		<div class="container">
			<?php if ( $has_content ) : ?>
				<div class="legal-page-content">
					<?php echo wp_kses_post( $content ); ?>
				</div>
			<?php else : ?>
				<div class="legal-page-empty">
					<strong><?php esc_html_e( 'Add the legal page content here.', 'whoop-clone' ); ?></strong>
					<p><?php esc_html_e( 'Use the content field for your KVKK / policy copy. The hero image, title, and subline remain optional.', 'whoop-clone' ); ?></p>
				</div>
			<?php endif; ?>
		</div>
	</div>
</section>
