<?php
/**
 * Memberships block.
 *
 * @package whoop-clone
 */

defined( 'ABSPATH' ) || exit;

$headline = whoop_field( 'headline' );
$tiers    = whoop_field( 'tiers' );

if ( empty( $tiers ) || ! is_array( $tiers ) ) {
	$tiers = array();
}

$tiers = array_slice( $tiers, 0, 2 );
?>
<section class="tiers" id="memberships"<?php echo whoop_section_spacing_style(); ?>>
	<div class="container">
		<?php if ( $headline ) : ?>
			<div class="tiers-head reveal">
				<h2><?php echo esc_html( $headline ); ?></h2>
			</div>
		<?php endif; ?>

		<?php if ( count( $tiers ) > 1 ) : ?>
			<div class="tier-tabs reveal" role="tablist" aria-label="<?php esc_attr_e( 'Membership products', 'whoop-clone' ); ?>">
				<?php foreach ( $tiers as $i => $tier ) : ?>
					<button
						class="tier-tab<?php echo 0 === $i ? ' is-active' : ''; ?>"
						type="button"
						role="tab"
						aria-selected="<?php echo 0 === $i ? 'true' : 'false'; ?>"
						data-tier-tab="<?php echo esc_attr( $i ); ?>"
					>
						<?php echo esc_html( $tier['tier_tab_label'] ?? ( $tier['tier_name'] ?? sprintf( __( 'Product %d', 'whoop-clone' ), $i + 1 ) ) ); ?>
					</button>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>

		<div class="tier-panels">
			<?php foreach ( $tiers as $i => $tier ) :
				$slug         = ! empty( $tier['tier_slug'] ) ? sanitize_html_class( $tier['tier_slug'] ) : 'tier-' . $i;
				$tier_img     = $tier['tier_image'] ?? null;
				$features     = $tier['features'] ?? array();
				$certificates = $tier['certificates'] ?? array();
				?>
				<article class="tier-panel tier tier-<?php echo esc_attr( $slug ); ?><?php echo 0 === $i ? ' is-active' : ''; ?>" data-tier-panel="<?php echo esc_attr( $i ); ?>">
					<div class="tier-shell">
						<div class="tier-media">
							<?php if ( $tier_img ) : ?>
								<img src="<?php echo esc_url( whoop_image_src( $tier_img, 'whoop-card' ) ); ?>" alt="<?php echo esc_attr( whoop_image_alt( $tier_img, $tier['tier_name'] ?? '' ) ); ?>" />
							<?php endif; ?>
						</div>

						<div class="tier-body">
							<?php if ( ! empty( $tier['tier_name'] ) ) : ?>
								<h3 class="tier-title"><?php echo esc_html( $tier['tier_name'] ); ?></h3>
							<?php endif; ?>

							<?php if ( ! empty( $tier['tier_rating_text'] ) ) : ?>
								<div class="tier-rating">
									<span class="tier-stars" aria-hidden="true">★★★★★</span>
									<span><?php echo esc_html( $tier['tier_rating_text'] ); ?></span>
								</div>
							<?php endif; ?>

							<?php if ( ! empty( $certificates ) ) : ?>
								<div class="tier-certs tier-certs-desktop" aria-label="<?php esc_attr_e( 'ISO certificates', 'whoop-clone' ); ?>">
									<?php foreach ( $certificates as $cert ) :
										if ( empty( $cert['image'] ) ) {
											continue;
										}
										?>
										<div class="tier-cert">
											<img src="<?php echo esc_url( whoop_image_src( $cert['image'], 'medium' ) ); ?>" alt="<?php echo esc_attr( whoop_image_alt( $cert['image'], '' ) ); ?>" />
										</div>
									<?php endforeach; ?>
								</div>
							<?php endif; ?>

							<?php if ( ! empty( $tier['features_intro'] ) ) : ?>
								<div class="tier-features-intro"><?php echo esc_html( $tier['features_intro'] ); ?></div>
							<?php endif; ?>

							<?php if ( is_array( $features ) && ! empty( $features ) ) : ?>
								<ul class="tier-features">
									<?php foreach ( $features as $f ) :
										$ftext = $f['text'] ?? '';
										if ( ! $ftext ) {
											continue;
										}
										?>
										<li>
											<svg viewBox="0 0 16 16" width="16" height="16" fill="none" stroke="currentColor">
												<path d="M5 8l2 2 4-4" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
											</svg>
											<?php echo esc_html( $ftext ); ?>
										</li>
									<?php endforeach; ?>
								</ul>
							<?php endif; ?>

							<div class="tier-price-wrap">
								<?php if ( ! empty( $tier['tier_compare_price'] ) ) : ?>
									<div class="tier-compare-price"><?php echo esc_html( $tier['tier_compare_price'] ); ?></div>
								<?php endif; ?>
								<?php if ( ! empty( $tier['tier_price'] ) ) : ?>
									<div class="tier-price"><?php echo esc_html( $tier['tier_price'] ); ?></div>
								<?php endif; ?>
							</div>

							<div class="tier-cta">
								<?php if ( ! empty( $tier['cta_primary_text'] ) ) : ?>
									<a href="<?php echo esc_url( $tier['cta_primary_url'] ?? '#' ); ?>" class="btn btn-primary"><?php echo esc_html( $tier['cta_primary_text'] ); ?></a>
								<?php endif; ?>
								<?php if ( ! empty( $tier['cta_secondary_text'] ) ) : ?>
									<a
										href="<?php echo esc_url( $tier['cta_secondary_url'] ?? '#' ); ?>"
										class="btn-outline"
										data-report-url="<?php echo esc_url( $tier['cta_secondary_url'] ?? '#' ); ?>"
										data-report-title="<?php echo esc_attr( sprintf( '%s - %s', $tier['tier_name'] ?? __( 'Report', 'whoop-clone' ), $tier['cta_secondary_text'] ) ); ?>"
									><?php echo esc_html( $tier['cta_secondary_text'] ); ?></a>
								<?php endif; ?>
							</div>

							<?php if ( ! empty( $certificates ) ) : ?>
								<div class="tier-certs tier-certs-mobile" aria-label="<?php esc_attr_e( 'ISO certificates', 'whoop-clone' ); ?>">
									<?php foreach ( $certificates as $cert ) :
										if ( empty( $cert['image'] ) ) {
											continue;
										}
										?>
										<div class="tier-cert">
											<img src="<?php echo esc_url( whoop_image_src( $cert['image'], 'medium' ) ); ?>" alt="<?php echo esc_attr( whoop_image_alt( $cert['image'], '' ) ); ?>" />
										</div>
									<?php endforeach; ?>
								</div>
							<?php endif; ?>

							<?php if ( ! empty( $tier['trust_strip_text'] ) ) : ?>
								<div class="tier-trust-strip">
									<span class="tier-trust-icon" aria-hidden="true">
										<svg viewBox="0 0 20 20" width="16" height="16" fill="none">
											<path d="M2 5.5h11.5v7H2zM13.5 7h2.4L18 9.4v3.1h-4.5zM5 14.5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm11 0a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
										</svg>
									</span>
									<span><?php echo esc_html( $tier['trust_strip_text'] ); ?></span>
								</div>
							<?php endif; ?>
						</div>
					</div>

				</article>
			<?php endforeach; ?>
		</div>
	</div>
</section>

<?php
if ( ! defined( 'WHOOP_REPORT_MODAL_RENDERED' ) ) {
	define( 'WHOOP_REPORT_MODAL_RENDERED', true );
	add_action( 'wp_footer', 'whoop_render_report_modal', 5 );
}
?>
