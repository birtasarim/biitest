<?php
/**
 * Daily block — get-started card + wear-daily wide.
 *
 * ACF fields:
 *   gs_image (image)
 *   gs_title (text)
 *   gs_text (textarea)
 *   gs_cta_text (text)
 *   gs_cta_url (url)
 *
 *   wd_title (textarea)         — large headline
 *   wd_text (textarea)          — supporting copy
 *   wd_image (image)            — wide visual
 *   wd_badge_value (text)       — e.g. "29.9"
 *   wd_badge_label (text)       — e.g. "WHOOP AGE"
 *
 * @package whoop-clone
 */

defined( 'ABSPATH' ) || exit;

$gs_image = whoop_field( 'gs_image' );
$wd_image = whoop_field( 'wd_image' );
?>
<section class="daily section-rise"<?php echo whoop_section_spacing_style(); ?>>
	<div class="container">
		<?php if ( $gs_image || whoop_field( 'gs_title' ) ) : ?>
			<div class="get-started reveal">
				<div class="gs-img">
					<?php if ( $gs_image ) : ?>
						<img src="<?php echo esc_url( whoop_image_src( $gs_image, 'whoop-card' ) ); ?>" alt="<?php echo esc_attr( whoop_image_alt( $gs_image, '' ) ); ?>" />
					<?php endif; ?>
				</div>
				<div class="gs-text">
					<?php if ( $title = whoop_field( 'gs_title' ) ) : ?>
						<h3><?php echo esc_html( $title ); ?></h3>
					<?php endif; ?>
					<?php if ( $text = whoop_field( 'gs_text' ) ) : ?>
						<p><?php echo esc_html( $text ); ?></p>
					<?php endif; ?>
				</div>
				<?php if ( $cta_text = whoop_field( 'gs_cta_text' ) ) : ?>
					<div class="gs-cta">
						<a href="<?php echo esc_url( whoop_field( 'gs_cta_url' ) ?: '#' ); ?>" class="btn"><?php echo esc_html( $cta_text ); ?></a>
					</div>
				<?php endif; ?>
			</div>
		<?php endif; ?>

		<?php if ( whoop_field( 'wd_title' ) || $wd_image ) : ?>
			<div class="wear-daily-head">
				<?php if ( $wd_title = whoop_field( 'wd_title' ) ) : ?>
					<h2 class="reveal"><?php echo wp_kses_post( $wd_title ); ?></h2>
				<?php endif; ?>
				<?php if ( $wd_text = whoop_field( 'wd_text' ) ) : ?>
					<p class="reveal reveal-delay-1"><?php echo wp_kses_post( $wd_text ); ?></p>
				<?php endif; ?>
			</div>

			<?php if ( $wd_image ) : ?>
				<div class="wear-daily-visual reveal reveal-delay-2">
					<img src="<?php echo esc_url( whoop_image_src( $wd_image, 'whoop-wide' ) ); ?>" alt="<?php echo esc_attr( whoop_image_alt( $wd_image, '' ) ); ?>" />
					<?php
					$badge_value = whoop_field( 'wd_badge_value' );
					$badge_label = whoop_field( 'wd_badge_label' );
					if ( $badge_value || $badge_label ) :
						?>
						<div class="wd-badge">
							<svg viewBox="0 0 32 32" width="32" height="32" fill="none">
								<circle cx="16" cy="16" r="13" stroke="#16ec06" stroke-width="2"/>
							</svg>
							<div>
								<?php if ( $badge_value ) : ?><div class="wd-badge-num"><?php echo esc_html( $badge_value ); ?></div><?php endif; ?>
								<?php if ( $badge_label ) : ?><div class="wd-badge-label"><?php echo esc_html( $badge_label ); ?></div><?php endif; ?>
							</div>
						</div>
					<?php endif; ?>
				</div>
			<?php endif; ?>
		<?php endif; ?>
	</div>
</section>
