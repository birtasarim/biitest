<?php
/**
 * Social Proof block — athlete cards + quote cards mosaic.
 *
 * ACF fields:
 *   headline (text)
 *   subline (textarea)
 *   items (repeater)
 *     - item_type (radio)         — image | quote
 *     - layout_size (select)      — default | large | wide   (CSS span/row classes)
 *     - has_video (true_false)
 *     - video_url (url)          — when has_video, direct .mp4 or YouTube url
 *     - person_image (image)      — when item_type=image
 *     - person_name (text)        — when item_type=image
 *     - person_role (text)        — when item_type=image
 *     - quote_text (textarea)     — when item_type=quote
 *     - quote_name (text)         — when item_type=quote
 *     - quote_role (text)         — when item_type=quote
 *
 * @package whoop-clone
 */

defined( 'ABSPATH' ) || exit;

$headline = whoop_field( 'headline' );
$subline  = whoop_field( 'subline' );
$items    = whoop_field( 'items' );

if ( ! is_array( $items ) ) {
	$items = array();
}

$block_uid = 'proof-' . substr( md5( $block['id'] ?? wp_unique_id() ), 0, 8 );

// Build payload arrays for the JS modals.
$people  = array();
$quotes  = array();

if ( ! function_exists( 'whoop_normalize_video_payload' ) ) {
	/**
	 * Normalize a video URL to a modal-friendly payload.
	 *
	 * @param string $video_url Raw direct video or YouTube URL.
 * @return array{type:string,url:string,thumbnail:string}
	 */
	function whoop_normalize_video_payload( $video_url ) {
		$video_url   = is_string( $video_url ) ? trim( $video_url ) : '';
		$youtube_id  = '';
		$youtube_url = '';

		if ( '' === $video_url ) {
			return array(
				'type'      => 'none',
				'url'       => '',
				'thumbnail' => '',
			);
		}

		$parts = wp_parse_url( $video_url );
		$host  = isset( $parts['host'] ) ? strtolower( $parts['host'] ) : '';
		$path  = isset( $parts['path'] ) ? trim( $parts['path'], '/' ) : '';

		if ( false !== strpos( $host, 'youtu.be' ) && '' !== $path ) {
			$youtube_id = strtok( $path, '/' );
		} elseif ( false !== strpos( $host, 'youtube.com' ) ) {
			if ( ! empty( $parts['query'] ) ) {
				parse_str( $parts['query'], $query_args );
				if ( ! empty( $query_args['v'] ) ) {
					$youtube_id = (string) $query_args['v'];
				}
			}

			if ( '' === $youtube_id && '' !== $path ) {
				$path_parts = explode( '/', $path );
				$key_index  = array_search( 'embed', $path_parts, true );
				if ( false === $key_index ) {
					$key_index = array_search( 'shorts', $path_parts, true );
				}
				if ( false !== $key_index && ! empty( $path_parts[ $key_index + 1 ] ) ) {
					$youtube_id = (string) $path_parts[ $key_index + 1 ];
				}
			}
		}

		if ( '' !== $youtube_id ) {
			$youtube_id  = preg_replace( '/[^A-Za-z0-9_-]/', '', $youtube_id );
			$youtube_url = sprintf(
				'https://www.youtube-nocookie.com/embed/%1$s?autoplay=1&mute=0&controls=1&playsinline=1&rel=0&modestbranding=1&iv_load_policy=3',
				rawurlencode( $youtube_id )
			);
		}

		if ( '' !== $youtube_url ) {
			return array(
				'type'      => 'youtube',
				'url'       => $youtube_url,
				'thumbnail' => sprintf( 'https://i.ytimg.com/vi/%s/hqdefault.jpg', rawurlencode( $youtube_id ) ),
			);
		}

		return array(
			'type'      => 'video',
			'url'       => $video_url,
			'thumbnail' => '',
		);
	}
}
?>
<section class="proof"<?php echo whoop_section_spacing_style(); ?>>
	<div class="container">
		<?php if ( $headline || $subline ) : ?>
			<div class="proof-head reveal">
				<?php if ( $headline ) : ?><h2><?php echo esc_html( $headline ); ?></h2><?php endif; ?>
				<?php if ( $subline ) : ?><p><?php echo wp_kses_post( $subline ); ?></p><?php endif; ?>
			</div>
		<?php endif; ?>

		<div class="proof-mosaic">
			<?php
			foreach ( $items as $i => $item ) {
				$type = $item['item_type'] ?? 'image';
				$size = $item['layout_size'] ?? 'default';

				$size_class = '';
				if ( 'large' === $size ) {
					$size_class = ' row-2';
				} elseif ( 'wide' === $size ) {
					$size_class = ' span-2';
				}

				if ( 'quote' === $type ) {
					$idx = count( $quotes );
					$quotes[] = array(
						'name' => $item['quote_name'] ?? '',
						'role' => $item['quote_role'] ?? '',
						'text' => $item['quote_text'] ?? '',
					);
					?>
					<div class="proof-card proof-quote<?php echo esc_attr( $size_class ); ?>" data-quote="<?php echo esc_attr( $idx ); ?>">
						<div class="proof-quote-mark" aria-hidden="true">
							<svg viewBox="0 0 32 24" width="32" height="24" fill="none">
								<path d="M0 24V14.4C0 6.13 4.48.96 13.44 0l1.28 3.2C9.28 4.48 6.72 8.32 6.4 13.44H12.8V24H0zm17.6 0V14.4C17.6 6.13 22.08.96 31.04 0l1.28 3.2c-5.44 1.28-7.99 5.12-8.32 10.24h6.4V24H17.6z" fill="currentColor"/>
							</svg>
						</div>
						<p class="proof-quote-text"><?php echo esc_html( $item['quote_text'] ?? '' ); ?></p>
						<div class="proof-quote-meta">
							<div>
								<?php if ( ! empty( $item['quote_name'] ) ) : ?>
									<div class="meta-name"><?php echo esc_html( $item['quote_name'] ); ?></div>
								<?php endif; ?>
								<?php if ( ! empty( $item['quote_role'] ) ) : ?>
									<div class="meta-role"><?php echo esc_html( $item['quote_role'] ); ?></div>
								<?php endif; ?>
							</div>
							<button class="proof-plus" aria-label="<?php esc_attr_e( 'More', 'whoop-clone' ); ?>">
								<svg viewBox="0 0 16 16" fill="none"><path d="M8 3v10M3 8h10" stroke="currentColor" stroke-linecap="round"/></svg>
							</button>
						</div>
					</div>
					<?php
				} else {
					$person_img = $item['person_image'] ?? null;
					$video_data = whoop_normalize_video_payload( $item['video_url'] ?? '' );
					$has_video  = ! empty( $item['has_video'] ) && 'none' !== $video_data['type'];
					$card_image = whoop_image_src( $person_img, 'whoop-portrait' );
					$idx = count( $people );
					$people[] = array(
						'name'       => $item['person_name'] ?? '',
						'role'       => $item['person_role'] ?? '',
						'img'        => whoop_image_src( $person_img, 'whoop-modal' ),
						'media_type' => $has_video ? $video_data['type'] : 'image',
						'media_url'  => $has_video ? $video_data['url'] : '',
					);
					?>
					<div class="proof-card proof-image<?php echo esc_attr( $size_class ); ?>" data-person="<?php echo esc_attr( $idx ); ?>">
						<?php if ( $has_video && 'video' === $video_data['type'] ) : ?>
							<video muted playsinline preload="metadata" aria-hidden="true">
								<source src="<?php echo esc_url( $video_data['url'] ); ?>" type="video/mp4">
							</video>
						<?php elseif ( $has_video && 'youtube' === $video_data['type'] && ! empty( $video_data['thumbnail'] ) ) : ?>
							<img src="<?php echo esc_url( $video_data['thumbnail'] ); ?>" alt="<?php echo esc_attr( $item['person_name'] ?? '' ); ?>" />
						<?php elseif ( $card_image ) : ?>
							<img src="<?php echo esc_url( $card_image ); ?>" alt="<?php echo esc_attr( whoop_image_alt( $person_img, $item['person_name'] ?? '' ) ); ?>" />
						<?php endif; ?>
						<?php if ( $has_video ) : ?>
							<div class="proof-play"><svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg></div>
						<?php endif; ?>
						<div class="meta">
							<?php if ( ! empty( $item['person_name'] ) ) : ?>
								<div class="meta-name"><?php echo esc_html( $item['person_name'] ); ?></div>
							<?php endif; ?>
							<?php if ( ! empty( $item['person_role'] ) ) : ?>
								<div class="meta-role"><?php echo esc_html( $item['person_role'] ); ?></div>
							<?php endif; ?>
						</div>
						<?php if ( ! $has_video ) : ?>
							<button class="proof-plus" aria-label="<?php esc_attr_e( 'More', 'whoop-clone' ); ?>">
								<svg viewBox="0 0 16 16" fill="none"><path d="M8 3v10M3 8h10" stroke="currentColor" stroke-linecap="round"/></svg>
							</button>
						<?php endif; ?>
					</div>
					<?php
				}
			}
			?>
		</div>
	</div>
</section>

<script type="application/json" class="whoop-people-data" id="<?php echo esc_attr( $block_uid ); ?>-people">
<?php echo wp_json_encode( $people ); ?>
</script>
<script type="application/json" class="whoop-quotes-data" id="<?php echo esc_attr( $block_uid ); ?>-quotes">
<?php echo wp_json_encode( $quotes ); ?>
</script>

<?php if ( ! defined( 'WHOOP_PERSON_MODAL_RENDERED' ) ) :
	define( 'WHOOP_PERSON_MODAL_RENDERED', true );
	?>
	<div class="person-modal" id="personModal" aria-hidden="true">
		<div class="person-modal-card">
			<button class="person-modal-close" id="personModalClose" aria-label="<?php esc_attr_e( 'Close', 'whoop-clone' ); ?>">
				<svg viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M3 3l10 10M13 3L3 13"/></svg>
			</button>
			<div class="person-modal-media" id="personModalMedia">
				<img class="person-modal-img" id="personModalImg" src="" alt="" />
				<video class="person-modal-video" id="personModalVideo" controls playsinline preload="metadata"></video>
				<div class="person-modal-embed" id="personModalEmbed"></div>
			</div>
			<div class="person-modal-info">
				<h3 id="personModalName"></h3>
				<p id="personModalRole"></p>
			</div>
		</div>
	</div>

	<div class="testimonial-modal" id="testimonialModal" aria-hidden="true">
		<div class="testimonial-modal-card">
			<button class="testimonial-modal-close" id="testimonialModalClose" aria-label="<?php esc_attr_e( 'Close', 'whoop-clone' ); ?>">
				<svg viewBox="0 0 16 16" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M3 3l10 10M13 3L3 13"/></svg>
			</button>
			<div class="testimonial-quote-mark">"</div>
			<p class="testimonial-text" id="testimonialText"></p>
			<div class="testimonial-meta">
				<div class="testimonial-name" id="testimonialName"></div>
				<div class="testimonial-role" id="testimonialRole"></div>
			</div>
		</div>
	</div>
<?php endif; ?>
