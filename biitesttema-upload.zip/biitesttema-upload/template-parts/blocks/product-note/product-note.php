<?php
/**
 * Product note block.
 *
 * @package whoop-clone
 */

defined( 'ABSPATH' ) || exit;

$text = whoop_field( 'text' );

if ( ! $text ) {
	$text = __( 'Add a short supporting note for the product details area.', 'whoop-clone' );
}
?>
<section class="product-note"<?php echo whoop_section_spacing_style(); ?>>
	<div class="container">
		<div class="product-note-row reveal">
			<div class="product-note-icon" aria-hidden="true">
				<svg viewBox="0 0 20 20" width="12" height="12" fill="none">
					<path d="M4.5 10.5l3.2 3.2 7.8-8.2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
				</svg>
			</div>
			<p><?php echo esc_html( $text ); ?></p>
		</div>
	</div>
</section>
