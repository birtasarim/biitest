<?php
/**
 * Editorial carousel block.
 *
 * ACF fields:
 *   headline (text)
 *   subline (textarea)
 *   slides (repeater)
 *     - image (image)
 *     - eyebrow (text)
 *     - title (text)
 *     - description (textarea)
 *     - points (repeater -> text)
 *     - cta_text (text)
 *     - cta_url (url)
 *
 * @package whoop-clone
 */

defined( 'ABSPATH' ) || exit;

$headline = whoop_field( 'headline' );
$subline  = whoop_field( 'subline' );
$slides   = whoop_field( 'slides' );

if ( ! is_array( $slides ) ) {
	$slides = array();
}

$slides = array_values(
	array_filter(
		$slides,
		static function ( $slide ) {
			return is_array( $slide ) && ( ! empty( $slide['image'] ) || ! empty( $slide['title'] ) || ! empty( $slide['description'] ) );
		}
	)
);

$carousel_id = wp_unique_id( 'editorial-carousel-' );
?>
<section class="editorial-carousel"<?php echo whoop_section_spacing_style(); ?>>
	<div class="container">
		<?php if ( $headline || $subline ) : ?>
			<div class="editorial-carousel-head reveal">
				<?php if ( $headline ) : ?>
					<h2><?php echo esc_html( $headline ); ?></h2>
				<?php endif; ?>
				<?php if ( $subline ) : ?>
					<p><?php echo esc_html( $subline ); ?></p>
				<?php endif; ?>
			</div>
		<?php endif; ?>

		<div class="editorial-carousel-shell reveal" data-editorial-carousel="<?php echo esc_attr( $carousel_id ); ?>">
			<?php if ( empty( $slides ) ) : ?>
				<div class="editorial-carousel-empty">
					<strong><?php esc_html_e( 'Add slides to start building this section.', 'whoop-clone' ); ?></strong>
					<p><?php esc_html_e( 'Each slide supports one portrait image, title, description, optional bullet points, and an optional CTA.', 'whoop-clone' ); ?></p>
				</div>
			<?php else : ?>
				<div class="editorial-carousel-viewport">
					<div class="editorial-carousel-track" id="<?php echo esc_attr( $carousel_id ); ?>">
						<?php foreach ( $slides as $index => $slide ) : ?>
						<?php
						$image       = $slide['image'] ?? null;
						$eyebrow     = $slide['eyebrow'] ?? '';
						$title       = $slide['title'] ?? '';
						$description = $slide['description'] ?? '';
						$points      = isset( $slide['points'] ) && is_array( $slide['points'] ) ? $slide['points'] : array();
						$cta_text    = $slide['cta_text'] ?? '';
						$cta_url     = $slide['cta_url'] ?? '';
						?>
						<article class="editorial-slide<?php echo 0 === $index ? ' is-active' : ''; ?>" data-slide-index="<?php echo esc_attr( $index ); ?>">
							<div class="editorial-slide-visual">
								<?php if ( $image ) : ?>
									<img src="<?php echo esc_url( whoop_image_src( $image, 'whoop-portrait' ) ); ?>" alt="<?php echo esc_attr( whoop_image_alt( $image, $title ) ); ?>" />
								<?php else : ?>
									<div class="editorial-slide-placeholder">
										<span class="editorial-slide-placeholder-mark">BiiTest</span>
										<strong>1280 × 1600</strong>
									</div>
								<?php endif; ?>
							</div>

							<div class="editorial-slide-copy">
								<?php if ( $eyebrow ) : ?>
									<div class="editorial-slide-eyebrow"><?php echo esc_html( $eyebrow ); ?></div>
								<?php endif; ?>

								<?php if ( $title ) : ?>
									<h3><?php echo esc_html( $title ); ?></h3>
								<?php endif; ?>

								<?php if ( $description ) : ?>
									<p class="editorial-slide-description"><?php echo esc_html( $description ); ?></p>
								<?php endif; ?>

								<?php if ( ! empty( $points ) ) : ?>
									<ul class="editorial-slide-points">
										<?php foreach ( $points as $point ) : ?>
											<?php if ( empty( $point['text'] ) ) { continue; } ?>
											<li><?php echo esc_html( $point['text'] ); ?></li>
										<?php endforeach; ?>
									</ul>
								<?php endif; ?>

								<?php if ( $cta_text && $cta_url ) : ?>
									<a class="btn btn-primary" href="<?php echo esc_url( $cta_url ); ?>"><?php echo esc_html( $cta_text ); ?></a>
								<?php endif; ?>
							</div>
						</article>
						<?php endforeach; ?>
					</div>
				</div>

				<div class="editorial-carousel-controls">
					<button type="button" class="editorial-carousel-arrow" data-carousel-arrow="prev" aria-label="<?php esc_attr_e( 'Previous slide', 'whoop-clone' ); ?>">
						<span aria-hidden="true">&larr;</span>
					</button>
					<div class="editorial-carousel-dots" role="tablist" aria-label="<?php esc_attr_e( 'Carousel slides', 'whoop-clone' ); ?>">
						<?php foreach ( $slides as $index => $slide ) : ?>
							<button
								type="button"
								class="editorial-carousel-dot<?php echo 0 === $index ? ' is-active' : ''; ?>"
								data-carousel-dot="<?php echo esc_attr( $index ); ?>"
								role="tab"
								aria-selected="<?php echo 0 === $index ? 'true' : 'false'; ?>"
								aria-label="<?php echo esc_attr( sprintf( __( 'Go to slide %d', 'whoop-clone' ), $index + 1 ) ); ?>"
							></button>
						<?php endforeach; ?>
					</div>
					<button type="button" class="editorial-carousel-arrow" data-carousel-arrow="next" aria-label="<?php esc_attr_e( 'Next slide', 'whoop-clone' ); ?>">
						<span aria-hidden="true">&rarr;</span>
					</button>
				</div>
			<?php endif; ?>
		</div>
	</div>
</section>
