<?php
/**
 * Gift block — compact dark card on black bg.
 *
 * ACF fields:
 *   gift_image (image)
 *   gift_title (text)
 *   gift_text (textarea)
 *   gift_cta_text (text)
 *   gift_cta_url (url)
 *
 * @package whoop-clone
 */

defined( 'ABSPATH' ) || exit;

$image = whoop_field( 'gift_image' );
$title = whoop_field( 'gift_title' );
$text  = whoop_field( 'gift_text' );
$cta_t = whoop_field( 'gift_cta_text' );
$cta_u = whoop_field( 'gift_cta_url' ) ?: '#';
?>
<section class="gift-section"<?php echo whoop_section_spacing_style(); ?>>
	<div class="container">
		<div class="gift-card reveal">
			<?php if ( $image ) : ?>
				<div class="gift-img">
					<img src="<?php echo esc_url( whoop_image_src( $image, 'whoop-card' ) ); ?>" alt="<?php echo esc_attr( whoop_image_alt( $image, $title ?: '' ) ); ?>" />
				</div>
			<?php endif; ?>
			<div class="gift-text">
				<?php if ( $title ) : ?><h3><?php echo esc_html( $title ); ?></h3><?php endif; ?>
				<?php if ( $text ) : ?><p><?php echo esc_html( $text ); ?></p><?php endif; ?>
			</div>
			<?php if ( $cta_t ) : ?>
				<div class="gift-cta">
					<a href="<?php echo esc_url( $cta_u ); ?>" class="btn"><?php echo esc_html( $cta_t ); ?></a>
				</div>
			<?php endif; ?>
		</div>
	</div>
</section>
