<?php
/**
 * Archive template — blog index, categories, tags.
 *
 * @package whoop-clone
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>

<div class="container archive-wrap">
	<header class="archive-header">
		<h1 class="archive-title">
			<?php
			if ( is_category() ) {
				single_cat_title();
			} elseif ( is_tag() ) {
				single_tag_title();
			} elseif ( is_author() ) {
				printf(
					/* translators: %s: author display name */
					esc_html__( 'Author: %s', 'whoop-clone' ),
					esc_html( get_the_author() )
				);
			} elseif ( is_year() ) {
				echo esc_html( get_the_date( 'Y' ) );
			} else {
				esc_html_e( 'Journal', 'whoop-clone' );
			}
			?>
		</h1>
		<?php
		$desc = get_the_archive_description();
		if ( $desc ) {
			echo '<div class="archive-description">' . wp_kses_post( $desc ) . '</div>';
		}
		?>
	</header>

	<?php if ( have_posts() ) : ?>
		<div class="post-grid">
			<?php while ( have_posts() ) : the_post(); ?>
				<article <?php post_class( 'post-card' ); ?>>
					<a href="<?php the_permalink(); ?>" class="post-card-link">
						<?php if ( has_post_thumbnail() ) : ?>
							<div class="post-card-thumb">
								<?php the_post_thumbnail( 'medium_large' ); ?>
							</div>
						<?php endif; ?>
						<div class="post-card-body">
							<?php
							$cats = get_the_category();
							if ( ! empty( $cats ) ) {
								echo '<span class="post-card-category">' . esc_html( $cats[0]->name ) . '</span>';
							}
							?>
							<h2 class="post-card-title"><?php the_title(); ?></h2>
							<div class="post-card-excerpt"><?php the_excerpt(); ?></div>
							<time class="post-card-date"><?php echo esc_html( get_the_date() ); ?></time>
						</div>
					</a>
				</article>
			<?php endwhile; ?>
		</div>

		<nav class="pagination">
			<?php
			the_posts_pagination(
				array(
					'mid_size'  => 1,
					'prev_text' => __( '← Previous', 'whoop-clone' ),
					'next_text' => __( 'Next →', 'whoop-clone' ),
				)
			);
			?>
		</nav>
	<?php else : ?>
		<p class="no-results"><?php esc_html_e( 'No posts found.', 'whoop-clone' ); ?></p>
	<?php endif; ?>
</div>

<?php
get_footer();
