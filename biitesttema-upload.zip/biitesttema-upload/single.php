<?php
/**
 * Single blog post template.
 *
 * @package whoop-clone
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>

<div class="container post-wrap">
	<?php
	if ( have_posts() ) {
		while ( have_posts() ) {
			the_post();
			?>
			<article id="post-<?php the_ID(); ?>" <?php post_class( 'post-single' ); ?>>
				<header class="post-header">
					<div class="post-meta">
						<?php
						$categories = get_the_category();
						if ( ! empty( $categories ) ) {
							echo '<span class="post-category">' . esc_html( $categories[0]->name ) . '</span>';
						}
						?>
						<time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>" class="post-date">
							<?php echo esc_html( get_the_date() ); ?>
						</time>
					</div>
					<h1 class="post-title"><?php the_title(); ?></h1>
				</header>

				<?php if ( has_post_thumbnail() ) : ?>
					<div class="post-thumb">
						<?php the_post_thumbnail( 'large' ); ?>
					</div>
				<?php endif; ?>

				<div class="post-content">
					<?php the_content(); ?>
				</div>

				<footer class="post-footer">
					<?php
					$tags = get_the_tags();
					if ( ! empty( $tags ) ) {
						echo '<div class="post-tags">';
						foreach ( $tags as $tag ) {
							printf( '<a href="%s" class="tag">%s</a> ', esc_url( get_tag_link( $tag->term_id ) ), esc_html( $tag->name ) );
						}
						echo '</div>';
					}
					?>
				</footer>
			</article>
			<?php

			if ( comments_open() || get_comments_number() ) {
				comments_template();
			}
		}
	}
	?>
</div>

<?php
get_footer();
