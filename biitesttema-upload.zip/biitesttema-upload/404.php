<?php
/**
 * 404 not found template.
 *
 * @package whoop-clone
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>

<section class="not-found">
	<div class="container">
		<h1 class="not-found-title">404</h1>
		<p class="not-found-text"><?php esc_html_e( "We couldn't find that page. Let's get you back on track.", 'whoop-clone' ); ?></p>
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="btn btn-primary"><?php esc_html_e( 'Go home', 'whoop-clone' ); ?></a>
	</div>
</section>

<?php
get_footer();
