(function () {
	function normalizeSingleProductQuantityLayout() {
		document.querySelectorAll('body.single-product form.cart').forEach(function (form) {
			var quantity = form.querySelector('.quantity');
			if (!quantity) {
				return;
			}

			var minus = form.querySelector('.whoop-qty-step--minus');
			var plus = form.querySelector('.whoop-qty-step--plus');
			var input = quantity.querySelector('input.qty');

			if (!input || !minus || !plus) {
				return;
			}

			quantity.classList.add('whoop-qty-inline');
			if (minus.parentElement !== quantity) {
				quantity.insertBefore(minus, input);
			}
			if (plus.parentElement !== quantity) {
				quantity.appendChild(plus);
			}
		});
	}

	function updateQuantity(input, delta) {
		const min = Number(input.min || 1);
		const max = Number(input.max || 999);
		const step = Number(input.step || 1);
		const current = Number(input.value || min);
		const next = Math.min(max, Math.max(min, current + delta * step));
		input.value = String(next);
		input.dispatchEvent(new Event('change', { bubbles: true }));
	}

	document.addEventListener('click', function (event) {
		const button = event.target.closest('[data-whoop-qty-step]');
		if (!button) {
			return;
		}

		const quantity = button.parentElement ? button.parentElement.querySelector('input.qty') : null;
		if (!quantity) {
			return;
		}

		event.preventDefault();
		updateQuantity(quantity, Number(button.getAttribute('data-whoop-qty-step') || 0));
	});

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', normalizeSingleProductQuantityLayout);
	} else {
		normalizeSingleProductQuantityLayout();
	}
})();
