(function () {
	const config = window.whoopWcCartCheckoutRuntime || {};
	const isCheckout = Boolean(config.isCheckout);
	const storeApiRoot = typeof config.storeApiRoot === 'string' ? config.storeApiRoot.replace(/\/$/, '') : '';
	let storeApiNonce = typeof config.nonce === 'string' ? config.nonce : '';
	const totalLabel = config.totalLabel || 'Toplam';
	const observedRoot = document.body;
	let refreshTimer = null;
	let isUpdatingQuantity = false;
	let cartItems = [];

	function scheduleRefresh() {
		window.clearTimeout(refreshTimer);
		refreshTimer = window.setTimeout(refreshUi, 80);
	}

	function removeSavingsBadges() {
		const selectors = [
			'.wc-block-components-product-badge',
			'.wc-block-components-sale-badge',
			'.wc-block-components-order-summary-item .onsale',
			'.wc-block-cart-item .onsale',
		];

		selectors.forEach((selector) => {
			document.querySelectorAll(selector).forEach((node) => node.remove());
		});

		document
			.querySelectorAll('.wc-block-cart [class], .wc-block-checkout [class]')
			.forEach((node) => {
				if (!node.children.length && /tasarruf/i.test(node.textContent || '')) {
					node.remove();
				}
			});
	}

	function replaceTotalLabels() {
		document
			.querySelectorAll('.wc-block-cart, .wc-block-checkout')
			.forEach((scope) => {
				scope.querySelectorAll('*').forEach((node) => {
					if (node.children.length) {
						return;
					}

					const value = (node.textContent || '').trim();
					if (value === 'Estimated total' || value === 'Tahmini toplam') {
						node.textContent = totalLabel;
					}
				});
			});
	}

	function createQtyControl(item) {
		const wrapper = document.createElement('div');
		wrapper.className = 'whoop-checkout-qty';
		wrapper.dataset.cartItemKey = item.key;
		wrapper.innerHTML =
			'<span class="whoop-checkout-qty__label">Adet</span>' +
			'<div class="wc-block-components-quantity-selector">' +
			'<button type="button" class="wc-block-components-quantity-selector__button" data-whoop-qty-action="decrease" aria-label="Adedi azalt">-</button>' +
			'<input type="number" class="wc-block-components-quantity-selector__input" data-whoop-qty-input min="1" step="1" inputmode="numeric" aria-label="Ürün adedi" />' +
			'<button type="button" class="wc-block-components-quantity-selector__button" data-whoop-qty-action="increase" aria-label="Adedi artır">+</button>' +
			'</div>';
		return wrapper;
	}

	function syncQtyControls() {
		document.querySelectorAll('.whoop-checkout-qty').forEach((control) => {
			const key = control.dataset.cartItemKey;
			const item = cartItems.find((entry) => entry.key === key);
			if (!item) {
				return;
			}

			const input = control.querySelector('[data-whoop-qty-input]');
			const decrease = control.querySelector('[data-whoop-qty-action="decrease"]');
			const increase = control.querySelector('[data-whoop-qty-action="increase"]');
			const min = Math.max(1, Number(item.quantity_limits?.minimum || 1));
			const max = Number(item.quantity_limits?.maximum || 99);
			const quantity = Number(item.quantity || min);

			input.value = String(quantity);
			input.min = String(min);
			input.max = String(max);
			decrease.disabled = isUpdatingQuantity || quantity <= min;
			increase.disabled = isUpdatingQuantity || quantity >= max;
			input.disabled = isUpdatingQuantity;
		});
	}

	function mountCheckoutQtyControls() {
		if (!isCheckout || !cartItems.length) {
			return;
		}

		const summaryItems = document.querySelectorAll('.wc-block-components-order-summary-item');
		summaryItems.forEach((summaryItem, index) => {
			const cartItem = cartItems[index];
			if (!cartItem || cartItem.quantity_limits?.editable === false) {
				return;
			}

			if (summaryItem.querySelector('.whoop-checkout-qty')) {
				return;
			}

			const target =
				summaryItem.querySelector('.wc-block-components-product-metadata') ||
				summaryItem.querySelector('.wc-block-components-product-name');

			if (!target) {
				return;
			}

			target.insertAdjacentElement('afterend', createQtyControl(cartItem));
		});

		syncQtyControls();
	}

	async function requestStoreApi(path, options) {
		const headers = new Headers(options && options.headers ? options.headers : {});
		headers.set('Accept', 'application/json');
		if (storeApiNonce) {
			headers.set('Nonce', storeApiNonce);
		}

		const response = await fetch(storeApiRoot + path, {
			credentials: 'same-origin',
			...options,
			headers,
		});

		const nextNonce = response.headers.get('Nonce');
		if (nextNonce) {
			storeApiNonce = nextNonce;
		}

		if (!response.ok) {
			throw new Error('Store API request failed');
		}

		return response.json();
	}

	async function loadCartItems() {
		if (!isCheckout || !storeApiRoot) {
			return;
		}

		try {
			const cart = await requestStoreApi('/cart', { method: 'GET' });
			cartItems = Array.isArray(cart.items) ? cart.items : [];
			mountCheckoutQtyControls();
		} catch (error) {
			// Fail closed: checkout stays usable even if the enhancement cannot load.
		}
	}

	async function updateCheckoutQuantity(key, nextQuantity) {
		if (!key || !storeApiRoot || isUpdatingQuantity) {
			return;
		}

		isUpdatingQuantity = true;
		syncQtyControls();

		try {
			await requestStoreApi(
				'/cart/update-item?key=' +
					encodeURIComponent(key) +
					'&quantity=' +
					encodeURIComponent(String(nextQuantity)),
				{ method: 'POST' }
			);
			window.location.reload();
		} catch (error) {
			isUpdatingQuantity = false;
			syncQtyControls();
		}
	}

	function handleQtyClick(event) {
		const button = event.target.closest('[data-whoop-qty-action]');
		if (!button) {
			return;
		}

		const control = button.closest('.whoop-checkout-qty');
		const input = control ? control.querySelector('[data-whoop-qty-input]') : null;
		if (!control || !input) {
			return;
		}

		const delta = button.dataset.whoopQtyAction === 'increase' ? 1 : -1;
		const min = Number(input.min || 1);
		const max = Number(input.max || 99);
		const current = Number(input.value || min);
		const next = Math.min(max, Math.max(min, current + delta));

		if (next !== current) {
			updateCheckoutQuantity(control.dataset.cartItemKey, next);
		}
	}

	function handleQtyChange(event) {
		const input = event.target.closest('[data-whoop-qty-input]');
		if (!input) {
			return;
		}

		const control = input.closest('.whoop-checkout-qty');
		if (!control) {
			return;
		}

		const min = Number(input.min || 1);
		const max = Number(input.max || 99);
		const next = Math.min(max, Math.max(min, Number(input.value || min)));
		updateCheckoutQuantity(control.dataset.cartItemKey, next);
	}

	function refreshUi() {
		removeSavingsBadges();
		replaceTotalLabels();
		mountCheckoutQtyControls();
	}

	document.addEventListener('click', handleQtyClick);
	document.addEventListener('change', handleQtyChange);

	const observer = new MutationObserver(scheduleRefresh);
	observer.observe(observedRoot, { childList: true, subtree: true });

	refreshUi();
	loadCartItems();
})();
