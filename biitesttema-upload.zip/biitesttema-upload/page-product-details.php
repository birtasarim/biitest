<?php
/**
 * Template Name: Product Details Page
 * Template Post Type: page
 *
 * Reusable single-page product details layout driven by page-level ACF fields.
 *
 * @package whoop-clone
 */

defined( 'ABSPATH' ) || exit;

get_header();

$hero_headline   = function_exists( 'get_field' ) ? ( get_field( 'pd_hero_headline' ) ?: '' ) : '';
$hero_subline    = function_exists( 'get_field' ) ? ( get_field( 'pd_hero_subline' ) ?: '' ) : '';
$hero_image      = function_exists( 'get_field' ) ? get_field( 'pd_hero_image' ) : null;
$hero_cta1_text  = function_exists( 'get_field' ) ? ( get_field( 'pd_hero_cta_primary_text' ) ?: '' ) : '';
$hero_cta1_url   = function_exists( 'get_field' ) ? ( get_field( 'pd_hero_cta_primary_url' ) ?: '#' ) : '#';
$hero_cta2_text  = function_exists( 'get_field' ) ? ( get_field( 'pd_hero_cta_secondary_text' ) ?: '' ) : '';
$hero_cta2_url   = function_exists( 'get_field' ) ? ( get_field( 'pd_hero_cta_secondary_url' ) ?: '#' ) : '#';

$intro_eyebrow   = function_exists( 'get_field' ) ? ( get_field( 'pd_intro_eyebrow' ) ?: '' ) : '';
$intro_headline  = function_exists( 'get_field' ) ? ( get_field( 'pd_intro_headline' ) ?: '' ) : '';
$intro_text      = function_exists( 'get_field' ) ? ( get_field( 'pd_intro_text' ) ?: '' ) : '';
$intro_image     = function_exists( 'get_field' ) ? get_field( 'pd_intro_image' ) : null;
$intro_cards     = function_exists( 'get_field' ) ? get_field( 'pd_intro_cards' ) : array();

$offer_eyebrow   = function_exists( 'get_field' ) ? ( get_field( 'pd_offer_eyebrow' ) ?: '' ) : '';
$offer_headline  = function_exists( 'get_field' ) ? ( get_field( 'pd_offer_headline' ) ?: '' ) : '';
$offer_text      = function_exists( 'get_field' ) ? ( get_field( 'pd_offer_text' ) ?: '' ) : '';
$offer_items     = function_exists( 'get_field' ) ? get_field( 'pd_offer_items' ) : array();

$feature_sections = function_exists( 'get_field' ) ? get_field( 'pd_feature_sections' ) : array();

$closing_headline = function_exists( 'get_field' ) ? ( get_field( 'pd_closing_headline' ) ?: '' ) : '';
$closing_text     = function_exists( 'get_field' ) ? ( get_field( 'pd_closing_text' ) ?: '' ) : '';
$closing_image    = function_exists( 'get_field' ) ? get_field( 'pd_closing_image' ) : null;
$closing_cta_text = function_exists( 'get_field' ) ? ( get_field( 'pd_closing_cta_text' ) ?: '' ) : '';
$closing_cta_url  = function_exists( 'get_field' ) ? ( get_field( 'pd_closing_cta_url' ) ?: '#' ) : '#';
?>

<div class="hero-pin" id="heroPin">
	<section class="hero hero-product-detail">
		<?php if ( $hero_image ) : ?>
			<img class="hero-poster" src="<?php echo esc_url( whoop_image_src( $hero_image, 'full' ) ); ?>" alt="<?php echo esc_attr( whoop_image_alt( $hero_image, '' ) ); ?>" />
		<?php endif; ?>

		<div class="hero-overlay" id="heroOverlay" aria-hidden="true"></div>

		<div class="hero-content container">
			<?php if ( $hero_headline ) : ?>
				<h1 class="hero-title"><?php echo wp_kses_post( $hero_headline ); ?></h1>
			<?php endif; ?>

			<?php if ( $hero_subline ) : ?>
				<p class="hero-sub"><?php echo wp_kses_post( $hero_subline ); ?></p>
			<?php endif; ?>

			<?php if ( $hero_cta1_text || $hero_cta2_text ) : ?>
				<div class="hero-actions">
					<?php if ( $hero_cta1_text ) : ?>
						<a href="<?php echo esc_url( $hero_cta1_url ); ?>" class="btn btn-on-dark hero-cta-primary">
							<span><?php echo esc_html( $hero_cta1_text ); ?></span>
							<span class="arrow" aria-hidden="true">
								<svg viewBox="0 0 20 20" width="16" height="16" fill="none">
									<path d="M4 10h10" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>
									<path d="M10 5l5 5-5 5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
								</svg>
							</span>
						</a>
					<?php endif; ?>
					<?php if ( $hero_cta2_text ) : ?>
						<a href="<?php echo esc_url( $hero_cta2_url ); ?>" class="btn btn-secondary-on-dark"><?php echo esc_html( $hero_cta2_text ); ?></a>
					<?php endif; ?>
				</div>
			<?php endif; ?>
		</div>
	</section>
</div>

<section class="product-intro section-rise">
	<div class="container product-intro-grid">
		<div class="product-intro-copy">
			<?php if ( $intro_eyebrow ) : ?>
				<div class="product-section-kicker reveal"><?php echo esc_html( $intro_eyebrow ); ?></div>
			<?php endif; ?>
			<?php if ( $intro_headline ) : ?>
				<h2 class="product-section-title reveal reveal-delay-1"><?php echo wp_kses_post( $intro_headline ); ?></h2>
			<?php endif; ?>
			<?php if ( $intro_text ) : ?>
				<p class="product-section-text reveal reveal-delay-2"><?php echo wp_kses_post( $intro_text ); ?></p>
			<?php endif; ?>
		</div>

		<div class="product-intro-visual reveal reveal-delay-2<?php echo $intro_image ? '' : ' is-placeholder'; ?>">
			<?php if ( $intro_image ) : ?>
				<img src="<?php echo esc_url( whoop_image_src( $intro_image, 'whoop-square' ) ); ?>" alt="<?php echo esc_attr( whoop_image_alt( $intro_image, '' ) ); ?>" />
			<?php else : ?>
				<div class="product-placeholder-copy">
					<div class="product-placeholder-eyebrow"><?php echo esc_html__( 'Product Image', 'whoop-clone' ); ?></div>
					<p><?php echo esc_html__( 'Add the first supporting image here.', 'whoop-clone' ); ?></p>
				</div>
			<?php endif; ?>
		</div>
	</div>

	<?php if ( is_array( $intro_cards ) && ! empty( $intro_cards ) ) : ?>
		<div class="container">
			<div class="product-intro-cards">
				<?php foreach ( $intro_cards as $index => $card ) :
					$card_title = isset( $card['title'] ) ? (string) $card['title'] : '';
					$card_text  = isset( $card['text'] ) ? (string) $card['text'] : '';
					if ( '' === trim( $card_title . $card_text ) ) {
						continue;
					}
					?>
					<article class="product-info-card reveal<?php echo $index > 0 ? esc_attr( ' reveal-delay-' . min( $index, 4 ) ) : ''; ?>">
						<?php if ( $card_title ) : ?><h3><?php echo esc_html( $card_title ); ?></h3><?php endif; ?>
						<?php if ( $card_text ) : ?><p><?php echo esc_html( $card_text ); ?></p><?php endif; ?>
					</article>
				<?php endforeach; ?>
			</div>
		</div>
	<?php endif; ?>
</section>

<?php if ( $offer_headline || $offer_text || ( is_array( $offer_items ) && ! empty( $offer_items ) ) ) : ?>
	<section class="product-offer section">
		<div class="container">
			<div class="product-section-head">
				<?php if ( $offer_eyebrow ) : ?><div class="product-section-kicker reveal"><?php echo esc_html( $offer_eyebrow ); ?></div><?php endif; ?>
				<?php if ( $offer_headline ) : ?><h2 class="product-section-title reveal reveal-delay-1"><?php echo wp_kses_post( $offer_headline ); ?></h2><?php endif; ?>
				<?php if ( $offer_text ) : ?><p class="product-section-text reveal reveal-delay-2"><?php echo wp_kses_post( $offer_text ); ?></p><?php endif; ?>
			</div>

			<?php if ( is_array( $offer_items ) && ! empty( $offer_items ) ) : ?>
				<div class="product-offer-grid">
					<?php foreach ( $offer_items as $index => $item ) :
						$item_label = isset( $item['label'] ) ? (string) $item['label'] : '';
						$item_title = isset( $item['title'] ) ? (string) $item['title'] : '';
						$item_text  = isset( $item['text'] ) ? (string) $item['text'] : '';
						if ( '' === trim( $item_label . $item_title . $item_text ) ) {
							continue;
						}
						?>
						<article class="product-offer-card reveal<?php echo $index > 0 ? esc_attr( ' reveal-delay-' . min( $index, 4 ) ) : ''; ?>">
							<?php if ( $item_label ) : ?><div class="product-offer-label"><?php echo esc_html( $item_label ); ?></div><?php endif; ?>
							<?php if ( $item_title ) : ?><h3><?php echo esc_html( $item_title ); ?></h3><?php endif; ?>
							<?php if ( $item_text ) : ?><p><?php echo esc_html( $item_text ); ?></p><?php endif; ?>
						</article>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
		</div>
	</section>
<?php endif; ?>

<?php if ( is_array( $feature_sections ) && ! empty( $feature_sections ) ) : ?>
	<?php foreach ( $feature_sections as $index => $section ) :
		$section_eyebrow = isset( $section['eyebrow'] ) ? (string) $section['eyebrow'] : '';
		$section_title   = isset( $section['headline'] ) ? (string) $section['headline'] : '';
		$section_text    = isset( $section['text'] ) ? (string) $section['text'] : '';
		$section_image   = isset( $section['image'] ) ? $section['image'] : null;
		$section_points  = isset( $section['points'] ) && is_array( $section['points'] ) ? $section['points'] : array();
		$section_cta     = isset( $section['cta_text'] ) ? (string) $section['cta_text'] : '';
		$section_cta_url = isset( $section['cta_url'] ) ? (string) $section['cta_url'] : '#';
		$is_reversed     = 1 === $index % 2;

		if ( '' === trim( $section_eyebrow . $section_title . $section_text . $section_cta ) && empty( $section_points ) && empty( $section_image ) ) {
			continue;
		}
		?>
		<section class="product-feature section<?php echo $is_reversed ? ' is-reversed' : ''; ?>">
			<div class="container product-feature-grid">
				<div class="product-feature-visual reveal<?php echo $section_image ? '' : ' is-placeholder'; ?>">
					<?php if ( $section_image ) : ?>
						<img src="<?php echo esc_url( whoop_image_src( $section_image, 'whoop-wide' ) ); ?>" alt="<?php echo esc_attr( whoop_image_alt( $section_image, '' ) ); ?>" />
					<?php else : ?>
						<div class="product-placeholder-copy">
							<div class="product-placeholder-eyebrow"><?php echo esc_html__( 'Feature Image', 'whoop-clone' ); ?></div>
							<p><?php echo esc_html__( 'Add a product detail image for this section.', 'whoop-clone' ); ?></p>
						</div>
					<?php endif; ?>
				</div>

				<div class="product-feature-copy">
					<?php if ( $section_eyebrow ) : ?><div class="product-section-kicker reveal"><?php echo esc_html( $section_eyebrow ); ?></div><?php endif; ?>
					<?php if ( $section_title ) : ?><h2 class="product-section-title reveal reveal-delay-1"><?php echo wp_kses_post( $section_title ); ?></h2><?php endif; ?>
					<?php if ( $section_text ) : ?><p class="product-section-text reveal reveal-delay-2"><?php echo wp_kses_post( $section_text ); ?></p><?php endif; ?>

					<?php if ( ! empty( $section_points ) ) : ?>
						<ul class="product-feature-points reveal reveal-delay-3">
							<?php foreach ( $section_points as $point ) :
								$point_text = isset( $point['text'] ) ? (string) $point['text'] : '';
								if ( '' === trim( $point_text ) ) {
									continue;
								}
								?>
								<li><?php echo esc_html( $point_text ); ?></li>
							<?php endforeach; ?>
						</ul>
					<?php endif; ?>

					<?php if ( $section_cta ) : ?>
						<a href="<?php echo esc_url( $section_cta_url ); ?>" class="btn btn-primary reveal reveal-delay-4"><?php echo esc_html( $section_cta ); ?></a>
					<?php endif; ?>
				</div>
			</div>
		</section>
	<?php endforeach; ?>
<?php endif; ?>

<?php if ( $closing_headline || $closing_text || $closing_cta_text || $closing_image ) : ?>
	<section class="product-closing section">
		<div class="container product-closing-grid">
			<div class="product-closing-copy">
				<?php if ( $closing_headline ) : ?><h2 class="product-section-title reveal"><?php echo wp_kses_post( $closing_headline ); ?></h2><?php endif; ?>
				<?php if ( $closing_text ) : ?><p class="product-section-text reveal reveal-delay-1"><?php echo wp_kses_post( $closing_text ); ?></p><?php endif; ?>
				<?php if ( $closing_cta_text ) : ?><a href="<?php echo esc_url( $closing_cta_url ); ?>" class="btn btn-primary reveal reveal-delay-2"><?php echo esc_html( $closing_cta_text ); ?></a><?php endif; ?>
			</div>
			<div class="product-closing-visual reveal reveal-delay-1<?php echo $closing_image ? '' : ' is-placeholder'; ?>">
				<?php if ( $closing_image ) : ?>
					<img src="<?php echo esc_url( whoop_image_src( $closing_image, 'whoop-square' ) ); ?>" alt="<?php echo esc_attr( whoop_image_alt( $closing_image, '' ) ); ?>" />
				<?php else : ?>
					<div class="product-placeholder-copy">
						<div class="product-placeholder-eyebrow"><?php echo esc_html__( 'Closing Image', 'whoop-clone' ); ?></div>
						<p><?php echo esc_html__( 'Add the final CTA image here.', 'whoop-clone' ); ?></p>
					</div>
				<?php endif; ?>
			</div>
		</div>
	</section>
<?php endif; ?>

<?php
get_footer();
