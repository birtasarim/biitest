import { defineConfig } from 'vite';

/**
 * Vite + WordPress configuration.
 *
 * Source:  src/js/main.js (which imports src/styles/main.scss)
 * Output:  assets/dist/   with manifest.json read by inc/enqueue.php
 *
 * Dev:    npm run dev   → http://localhost:5173 with HMR.
 *                          inc/enqueue.php detects .dev flag file or WHOOP_VITE_DEV
 *                          constant and points <script> at the dev server.
 *
 * Build:  npm run build → hashed assets + manifest.json under assets/dist/.
 */
export default defineConfig({
  build: {
    manifest: true,
    outDir: 'assets/dist',
    emptyOutDir: true,
    rollupOptions: {
      input: {
        main: 'src/js/main.js',
        'wc-shell': 'src/js/wc-shell.js',
      },
    },
    sourcemap: true,
    cssCodeSplit: false,
    assetsInlineLimit: 4096,
  },
  css: {
    preprocessorOptions: {
      scss: {
        api: 'modern-compiler',
      },
    },
  },
  server: {
    cors: true,
    strictPort: true,
    port: 5173,
    host: '127.0.0.1',
    origin: 'http://localhost:5173',
  },
});
