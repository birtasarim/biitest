<?php
/**
 * Site footer.
 *
 * @package whoop-clone
 */

defined( 'ABSPATH' ) || exit;

$footer_company_title    = get_theme_mod( 'whoop_footer_company_title', __( 'Company', 'whoop-clone' ) );
$footer_legal_title      = get_theme_mod( 'whoop_footer_legal_title', __( 'Legal', 'whoop-clone' ) );
$footer_show_newsletter  = (bool) get_theme_mod( 'whoop_footer_show_newsletter', 1 );
$footer_show_company     = (bool) get_theme_mod( 'whoop_footer_show_company', 1 );
$footer_show_legal       = (bool) get_theme_mod( 'whoop_footer_show_legal', 1 );
$footer_newsletter_title = get_theme_mod( 'whoop_footer_newsletter_title', __( 'Stay connected', 'whoop-clone' ) );
$footer_email_placeholder = get_theme_mod( 'whoop_footer_email_placeholder', __( 'Your email address', 'whoop-clone' ) );
$footer_subscribe_text   = get_theme_mod( 'whoop_footer_subscribe_text', __( 'Subscribe', 'whoop-clone' ) );
$footer_policy_text      = get_theme_mod( 'whoop_footer_policy_text', __( 'By signing up, you agree to our data protection policy.', 'whoop-clone' ) );
$footer_copyright_text   = get_theme_mod( 'whoop_footer_copyright_text', __( 'All rights reserved.', 'whoop-clone' ) );
$footer_logo_id          = absint( get_theme_mod( 'whoop_footer_logo', 0 ) );
$footer_contact_title    = get_theme_mod( 'whoop_footer_contact_title', __( 'İletişim', 'whoop-clone' ) );
$footer_service_label    = get_theme_mod( 'whoop_footer_contact_service_label', __( 'Müşteri Hizmetleri', 'whoop-clone' ) );
$footer_service_value    = get_theme_mod( 'whoop_footer_contact_service_value', '0216 709 75 01' );
$footer_email_label      = get_theme_mod( 'whoop_footer_contact_email_label', __( 'E-posta', 'whoop-clone' ) );
$footer_email_value      = get_theme_mod( 'whoop_footer_contact_email_value', 'iletisim@biitest-tr.com' );
$footer_offices_title    = get_theme_mod( 'whoop_footer_contact_offices_title', __( 'Ofisler', 'whoop-clone' ) );
$footer_etbis_title      = get_theme_mod( 'whoop_footer_etbis_title', __( 'ETBİS QR Kodu', 'whoop-clone' ) );
$footer_etbis_script     = get_theme_mod( 'whoop_footer_etbis_script', '' );
$footer_disclaimer_title = get_theme_mod( 'whoop_footer_disclaimer_title', __( 'Yasal Uyarı / Legal Disclaimer', 'whoop-clone' ) );
$footer_disclaimer_text  = get_theme_mod( 'whoop_footer_disclaimer_text', '' );
$footer_legacy_disclaimer_text = get_theme_mod( 'whoop_footer_legal_disclaimer', '' );
$footer_alt_disclaimer_text = get_theme_mod( 'whoop_footer_disclaimer', '' );
$footer_cookie_text      = get_theme_mod( 'whoop_footer_cookie_text', __( 'Çerez Aydınlatma Metni', 'whoop-clone' ) );
$footer_cookie_url       = get_theme_mod( 'whoop_footer_cookie_url', '#' );
$footer_kvkk_text        = get_theme_mod( 'whoop_footer_kvkk_text', __( 'Kişisel Verilerin Korunması - KVKK', 'whoop-clone' ) );
$footer_kvkk_url         = get_theme_mod( 'whoop_footer_kvkk_url', '#' );
$footer_refund_text      = get_theme_mod( 'whoop_footer_refund_text', __( 'Geri Ödeme ve İade Politikası', 'whoop-clone' ) );
$footer_refund_url       = get_theme_mod( 'whoop_footer_refund_url', '#' );

if ( '' === trim( wp_strip_all_tags( $footer_disclaimer_text ) ) && '' !== trim( wp_strip_all_tags( $footer_legacy_disclaimer_text ) ) ) {
	$footer_disclaimer_text = $footer_legacy_disclaimer_text;
}

if ( '' === trim( wp_strip_all_tags( $footer_disclaimer_text ) ) && '' !== trim( wp_strip_all_tags( $footer_alt_disclaimer_text ) ) ) {
	$footer_disclaimer_text = $footer_alt_disclaimer_text;
}

if ( '' === trim( wp_strip_all_tags( $footer_disclaimer_text ) ) ) {
	$footer_disclaimer_text = "Yasal Uyarı — Besin intoleransı testleri tamamlayıcı ve alternatif tıp kategorisine girer, teşhis ve tedavi amacı ile kullanılamaz. Sağlanan sonuçlar ve ilgili bilgiler tıbbi bir teşhis koymaz ve profesyonel tıbbi tavsiye, teşhis veya tedavinin yerine geçmesi amaçlanmamıştır. Tıbbi bir sorununuz varsa ilgili birim ve doktoru ile irtibata geçmenizi tavsiye ederiz.\n\nLegal Disclaimer — Food intolerance tests fall under the category of complementary and alternative medicine and cannot be used for diagnosis and treatment purposes. The results and related information provided do not constitute a medical diagnosis and are not intended to substitute for professional medical advice, diagnosis, or treatment. We recommend contacting the relevant unit and doctor if you have a medical problem.";
}

$footer_offices = array(
	array(
		'flag'    => get_theme_mod( 'whoop_footer_office_tr_flag', '🇹🇷' ),
		'title'   => get_theme_mod( 'whoop_footer_office_tr_title', __( 'Türkiye', 'whoop-clone' ) ),
		'address' => get_theme_mod( 'whoop_footer_office_tr_address', __( 'Ritim İstanbul, Maltepe / İstanbul', 'whoop-clone' ) ),
	),
	array(
		'flag'    => get_theme_mod( 'whoop_footer_office_uk_flag', '🇬🇧' ),
		'title'   => get_theme_mod( 'whoop_footer_office_uk_title', __( 'İngiltere', 'whoop-clone' ) ),
		'address' => get_theme_mod( 'whoop_footer_office_uk_address', __( 'Innovation Centre, University of Northampton', 'whoop-clone' ) ),
	),
	array(
		'flag'    => get_theme_mod( 'whoop_footer_office_cy_flag', '🇨🇾' ),
		'title'   => get_theme_mod( 'whoop_footer_office_cy_title', __( 'KKTC', 'whoop-clone' ) ),
		'address' => get_theme_mod( 'whoop_footer_office_cy_address', __( 'Serbest Liman, Gazimağusa', 'whoop-clone' ) ),
	),
);

$footer_grid_columns = 2;
if ( $footer_show_company ) {
	$footer_grid_columns++;
}
if ( $footer_show_legal ) {
	$footer_grid_columns++;
}

$whoop_home      = home_url( '/' );
$whoop_shop_url  = $whoop_home;
$whoop_account   = $whoop_home;
if ( function_exists( 'wc_get_page_id' ) ) {
	$sid = wc_get_page_id( 'shop' );
	if ( $sid > 0 ) {
		$whoop_shop_url = get_permalink( $sid );
	}
	$aid = wc_get_page_id( 'myaccount' );
	if ( $aid > 0 ) {
		$whoop_account = get_permalink( $aid );
	}
}

$footer_fallback_links = array(
	'footer-shop' => array(
		__( 'Member support', 'whoop-clone' ) => $whoop_home . '#contact-faq',
		__( 'Order status', 'whoop-clone' )   => $whoop_account,
		__( 'Community', 'whoop-clone' )      => $whoop_home . '#social-proof',
		__( 'Member login', 'whoop-clone' )   => $whoop_account,
	),
	'footer-company' => array(
		__( 'Our mission', 'whoop-clone' ) => $whoop_home . '#why',
		__( 'Careers', 'whoop-clone' )    => $whoop_home,
		__( 'Press', 'whoop-clone' )      => $whoop_home,
		__( 'Contact', 'whoop-clone' )    => $whoop_home . '#contact-faq',
	),
	'footer-support' => array(
		__( 'Affiliates', 'whoop-clone' )    => $whoop_home,
		__( 'Developers', 'whoop-clone' )    => $whoop_home,
		__( 'Hero discounts', 'whoop-clone' ) => $whoop_home . '#trial',
		__( 'Store locator', 'whoop-clone' ) => $whoop_shop_url,
	),
	'footer-legal' => array(
		__( 'Privacy', 'whoop-clone' )    => $whoop_home,
		__( 'Terms', 'whoop-clone' )      => $whoop_home,
		__( 'Sales terms', 'whoop-clone' ) => $whoop_shop_url,
		__( 'Patents', 'whoop-clone' )    => $whoop_home,
	),
);
?>
</main><!-- /#site-main -->

<footer class="footer">
	<div class="container">
		<div class="footer-links footer-links-cols-<?php echo esc_attr( $footer_grid_columns ); ?>">
			<div class="footer-col footer-brand-col">
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="logo">
					<?php
					if ( $footer_logo_id ) {
						echo wp_get_attachment_image( $footer_logo_id, 'full', false, array( 'class' => 'custom-logo footer-custom-logo', 'loading' => 'lazy' ) );
					} elseif ( has_custom_logo() ) {
						the_custom_logo();
					} else {
						echo '<span class="dot"></span>';
						bloginfo( 'name' );
					}
					?>
				</a>
				<p><?php echo esc_html( get_theme_mod( 'whoop_footer_tagline', __( 'Unlock better performance and long-term health.', 'whoop-clone' ) ) ); ?></p>
			</div>
			<?php if ( $footer_show_company ) : ?>
				<div class="footer-col">
					<h4><?php echo esc_html( $footer_company_title ); ?></h4>
					<?php
					if ( has_nav_menu( 'footer-company' ) ) {
						wp_nav_menu(
							array(
								'theme_location' => 'footer-company',
								'container'      => false,
								'menu_class'     => 'footer-menu',
								'depth'          => 1,
								'fallback_cb'    => '__return_false',
							)
						);
					} else {
						echo '<ul class="footer-menu">';
						foreach ( $footer_fallback_links['footer-company'] as $label => $url ) {
							printf( '<li><a href="%s">%s</a></li>', esc_url( $url ), esc_html( $label ) );
						}
						echo '</ul>';
					}
					?>
				</div>
			<?php endif; ?>
			<?php if ( $footer_show_legal ) : ?>
				<div class="footer-col">
					<h4><?php echo esc_html( $footer_legal_title ); ?></h4>
					<?php
					if ( has_nav_menu( 'footer-legal' ) ) {
						wp_nav_menu(
							array(
								'theme_location' => 'footer-legal',
								'container'      => false,
								'menu_class'     => 'footer-menu',
								'depth'          => 1,
								'fallback_cb'    => '__return_false',
							)
						);
					} else {
						echo '<ul class="footer-menu">';
						foreach ( $footer_fallback_links['footer-legal'] as $label => $url ) {
							printf( '<li><a href="%s">%s</a></li>', esc_url( $url ), esc_html( $label ) );
						}
						echo '</ul>';
					}
					?>
				</div>
			<?php endif; ?>
			<div class="footer-col footer-contact-col">
				<?php if ( $footer_contact_title ) : ?>
					<h4><?php echo esc_html( $footer_contact_title ); ?></h4>
				<?php endif; ?>
				<div class="footer-contact-stack">
					<?php if ( $footer_service_label || $footer_service_value ) : ?>
						<div class="footer-contact-row">
							<?php if ( $footer_service_label ) : ?><span class="footer-contact-label"><?php echo esc_html( $footer_service_label ); ?></span><?php endif; ?>
							<?php if ( $footer_service_value ) : ?><a href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', $footer_service_value ) ); ?>" class="footer-contact-value"><?php echo esc_html( $footer_service_value ); ?></a><?php endif; ?>
						</div>
					<?php endif; ?>
					<?php if ( $footer_email_label || $footer_email_value ) : ?>
						<div class="footer-contact-row">
							<?php if ( $footer_email_label ) : ?><span class="footer-contact-label"><?php echo esc_html( $footer_email_label ); ?></span><?php endif; ?>
							<?php if ( $footer_email_value ) : ?><a href="mailto:<?php echo esc_attr( antispambot( $footer_email_value ) ); ?>" class="footer-contact-value"><?php echo esc_html( antispambot( $footer_email_value ) ); ?></a><?php endif; ?>
						</div>
					<?php endif; ?>
				</div>
			</div>
		</div>

		<div class="footer-meta-row">
			<div class="footer-etbis-col">
				<?php if ( $footer_etbis_title ) : ?>
					<div class="footer-etbis-title"><?php echo esc_html( $footer_etbis_title ); ?></div>
				<?php endif; ?>
				<div class="footer-etbis-script">
					<?php echo $footer_etbis_script ? $footer_etbis_script : '<div class="footer-etbis-placeholder">' . esc_html__( 'ETBİS script alanı', 'whoop-clone' ) . '</div>'; ?>
				</div>
			</div>
			<div class="footer-offices-col">
				<?php if ( $footer_offices_title ) : ?>
					<div class="footer-office-title"><?php echo esc_html( $footer_offices_title ); ?></div>
				<?php endif; ?>
				<div class="footer-office-list">
					<?php foreach ( $footer_offices as $office ) : ?>
						<?php if ( empty( $office['title'] ) && empty( $office['address'] ) ) { continue; } ?>
						<div class="footer-office-item">
							<?php if ( ! empty( $office['flag'] ) ) : ?><div class="footer-office-flag"><?php echo esc_html( $office['flag'] ); ?></div><?php endif; ?>
							<div>
								<?php if ( ! empty( $office['title'] ) ) : ?><div class="footer-office-name"><?php echo esc_html( $office['title'] ); ?></div><?php endif; ?>
								<?php if ( ! empty( $office['address'] ) ) : ?><div class="footer-office-address"><?php echo esc_html( $office['address'] ); ?></div><?php endif; ?>
							</div>
						</div>
					<?php endforeach; ?>
				</div>
			</div>
		</div>

		<?php if ( $footer_show_newsletter ) : ?>
			<div class="footer-signup">
				<div class="footer-newsletter-title"><?php echo esc_html( $footer_newsletter_title ); ?></div>
				<form class="newsletter" action="#" method="post" onsubmit="return false">
					<input type="email" placeholder="<?php echo esc_attr( $footer_email_placeholder ); ?>" required />
					<button type="submit"><?php echo esc_html( $footer_subscribe_text ); ?></button>
				</form>
				<?php if ( $footer_policy_text ) : ?>
					<div class="footer-policy"><?php echo esc_html( $footer_policy_text ); ?></div>
				<?php endif; ?>
			</div>
		<?php endif; ?>

		<?php if ( $footer_disclaimer_title || $footer_disclaimer_text ) : ?>
			<div class="footer-disclaimer">
				<?php if ( $footer_disclaimer_title ) : ?>
					<div class="footer-disclaimer-summary"><?php echo esc_html( $footer_disclaimer_title ); ?></div>
				<?php endif; ?>
				<?php if ( $footer_disclaimer_text ) : ?>
					<div class="footer-disclaimer-body"><?php echo wp_kses_post( wpautop( $footer_disclaimer_text ) ); ?></div>
				<?php endif; ?>
			</div>
		<?php endif; ?>

		<div class="footer-bottom">
			<span>&copy; <?php echo esc_html( gmdate( 'Y' ) ); ?> <?php bloginfo( 'name' ); ?>. <?php echo esc_html( $footer_copyright_text ); ?></span>
			<div class="footer-bottom-links">
				<?php if ( $footer_cookie_text ) : ?><a href="<?php echo esc_url( $footer_cookie_url ); ?>"><?php echo esc_html( $footer_cookie_text ); ?></a><?php endif; ?>
				<?php if ( $footer_kvkk_text ) : ?><a href="<?php echo esc_url( $footer_kvkk_url ); ?>"><?php echo esc_html( $footer_kvkk_text ); ?></a><?php endif; ?>
					<?php if ( $footer_refund_text ) : ?><a href="<?php echo esc_url( $footer_refund_url ); ?>"><?php echo esc_html( $footer_refund_text ); ?></a><?php endif; ?>
			</div>
		</div>
	</div>
</footer>

<?php wp_footer(); ?>
<script>
(function(){
	function forceUnlockScroll(){
		document.body.style.overflow = '';
		document.documentElement.style.overflow = '';
		document.documentElement.classList.remove('lenis-stopped');
	}

	['personModal','testimonialModal'].forEach(function(id){
		var el = document.getElementById(id);
		if (!el) return;
		new MutationObserver(function(){
			if (!el.classList.contains('is-open')) {
				setTimeout(forceUnlockScroll, 50);
			}
		}).observe(el, { attributes: true, attributeFilter: ['class'] });
	});

	setInterval(function(){
		var personOpen = document.getElementById('personModal');
		var testiOpen = document.getElementById('testimonialModal');
		var anyOpen = (personOpen && personOpen.classList.contains('is-open')) ||
		              (testiOpen && testiOpen.classList.contains('is-open'));
		if (!anyOpen && document.body.style.overflow === 'hidden') {
			forceUnlockScroll();
		}
	}, 3000);
})();
</script>
</body>
</html>
