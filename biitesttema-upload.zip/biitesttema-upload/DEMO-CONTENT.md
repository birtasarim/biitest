# Demo İçerik Referansı

Her bloğa örnek içerik koyarken bu listeyi kullan. WHOOP orijinal sitesindeki metinleri/görselleri taklit eder.

## 1. Hero

| Alan | Örnek değer |
|------|-------------|
| Eyebrow | (boş bırakabilirsin) |
| Headline | Unlock human performance |
| Subline | A continuous wearable that decodes how your body is responding — every minute, every day. |
| Video URL | https://videos.pexels.com/video-files/4761426/4761426-uhd_2560_1440_25fps.mp4 |
| Poster Image | yatay format, 1920×1080+ önerilir |
| Primary CTA Text | Get started |
| Primary CTA URL | #memberships |
| Secondary CTA Text | Watch the film |
| Secondary CTA URL | #features |

## 2. Daily

**Get Started kartı:**
- Image: bilek üzerinde WHOOP, kapalı battaniye, sıcak ışık (~800×1067)
- Title: Get started for free
- Text: Get a 1-month free trial of Peak membership with a WHOOP device and charger included.
- CTA Text: Try WHOOP for free
- CTA URL: #trial

**Wear Daily:**
- Headline: Wear WHOOP daily, improve your health
- Subline: Daily WHOOP wear is linked to 91 more minutes of weekly activity, 2.3 more hours of sleep per week, and over 10% higher HRV. Members see faster gains, stronger habits, and better outcomes across their goals.*
- Wide Image: gün batımı, doğa, atletik bir figür (~1920×820)
- Badge Value: 29.9
- Badge Label: WHOOP AGE

## 3. Features Slider

6 kart öneririz:

| Card Title | Tiers | Modal Title (aynı veya genişletilmiş) |
|-----------|-------|--------------------------------------|
| Quantify how your body is feeling | ONE \| PEAK \| LIFE | (aynı) |
| Extend your prime for years to come | PEAK \| LIFE | (aynı) |
| Optimize your sleep | ONE \| PEAK \| LIFE | (aynı) |
| Measure the impact of every step and rep | ONE \| PEAK \| LIFE | (aynı) |
| Stay connected to your heart health | LIFE | (aynı) |
| Get daily Blood Pressure Insights | LIFE | (aynı) |

Her birinin **Modal Description**ı 3-4 cümle, **Member Quote**ı tırnaklı 2 cümle.

## 4. Memberships

3 tier, sırayla:

### Tier 1
- tier_slug: `one`
- tier_name: ONE
- tier_price: Starts at $199/yr
- tier_image: WHOOP One ürün mockup (telefon + bant)
- tier_colors_text: +14
- features_intro: (boş)
- features:
  - WHOOP 5.0 with 14+ day battery
  - Sleep, Strain, & Recovery insights
  - Personalized coaching
  - VO₂ Max & heart rate zones
  - Women's Hormonal Insights
- cta_primary_text: Start with ONE
- cta_secondary_text: Learn more

### Tier 2
- tier_slug: `peak`
- tier_name: PEAK
- tier_price: Starts at $239/yr
- tier_image: WHOOP Peak mockup (Healthspan ekranı)
- tier_colors_text: +14
- features_intro: Everything on WHOOP One, plus
- features:
  - WHOOP 5.0 with 14+ day battery
  - Healthspan and Pace of Aging
  - Health Monitor with health alerts
  - Real-time Stress Monitor
- cta_primary_text: Start with PEAK
- cta_secondary_text: Learn more

### Tier 3
- tier_slug: `life`
- tier_name: LIFE
- tier_price: Starts at $359/yr
- tier_image: WHOOP Life mockup (ECG ekranı)
- tier_colors_text: +10
- features_intro: Everything on WHOOP Peak, plus
- features:
  - WHOOP MG with 14+ day battery
  - Daily Blood Pressure Insights (beta)
  - Heart Screener with ECG readings
  - On-demand AFib Detection
- cta_primary_text: Start with LIFE
- cta_secondary_text: Learn more

**Footnote:** Pay with HSA/FSA Card | Additional medical information below.

## 5. Gift Banner

- Image: anne+çocuk veya bir hediye anı
- Title: The gift of better health
- Text: Give the gift of better sleep, smarter training, healthier habits, and more years with WHOOP.
- CTA Text: Gift WHOOP
- CTA URL: /gift

## 6. Social Proof Mosaic

- Headline: Backed by PhDs, worn by MVPs
- Subline: Whether you're #1 in the world or on day 1 of your journey, WHOOP helps you optimize your health, fitness, and life.

8 item öneririz, sırayla:

1. **Image — large** (Cristiano Ronaldo, Football Legend & Global Icon, has_video=true)
2. **Image — default** (Rory McIlroy, Grand Slam Champion)
3. **Image — default** (Sha'Carri Richardson, Track and Field Star)
4. **Quote — default** ("WHOOP continues to transform my approach to health and wellness daily." — Weilynn T., WHOOP member)
5. **Image — default** (Aryna Sabalenka, World No. 1 Tennis Player)
6. **Quote — default** ("WHOOP has helped me greatly improve my physical health and wellbeing" — Samatha R., WHOOP member)
7. **Image — large** (Patrick Mahomes, All-Star Quarterback, has_video=true)
8. **Image — default** (Virgil van Dijk, Global Football Star, has_video=true)

## 7. Principles Accordion

- Headline: Built to be worn 24/7

4 principle:

| Title | Description | Image |
|-------|-------------|-------|
| Zero distractions | A screen-free design means no pings, distractions, or unnecessary bells & whistles. | minimalist watch close-up |
| Always-on sensors | For unmatched precision and insights, heart rate sensors collect data points every second — 24/7. | beyin/sinir hücreleri makro |
| 14+ day battery life | Power up on-the-go and stay charged with the waterproof Wireless PowerPack. | şarj cihazı + bant |
| Completely customizable | Create a look that's uniquely you, or wear off-wrist with the new Body Smart Apparel. | bant detay, dokuma |

## 8. Showcase

- Headline: One device, endless ways to wear it

4 tab:

| Label | Title | Description |
|-------|-------|-------------|
| LeatherLuxe | Live in luxe | Crafted from premium Italian leather and precious metals, LeatherLuxe elevates your look with timeless sophistication and style. |
| SportFlex | Built for performance | Engineered for athletes — moisture-wicking, breathable, and stretchable. SportFlex moves with you through every rep, mile, and recovery. |
| CloudKnit | Soft as a cloud | A signature WHOOP knit that feels weightless against your skin. Perfect for sleep, recovery, and all-day comfort without compromise. |
| SuperKnit | Made to perform | Durable, sweat-resistant, and ready for whatever you throw at it. SuperKnit holds its shape through training, travel, and daily life. |

## 9. Trial

- Title: No other wearable lets you try before you buy
- Description: Get a 1-month free trial of Peak membership with a certified pre-owned WHOOP 5.0 device to improve fitness, manage stress, and receive personalized guidance to optimize your Healthspan.
- CTA Text: Try WHOOP for free
- CTA URL: /trial
- Visual Image: koyu kompozisyon — bant + şarj + telefon
- Show JOIN NOW pill: ON
- Join Pill Text: Join Now
- Join Pill URL: /join

## 10. Advanced Labs

- Headline: Put your health into focus with Advanced Labs

4 bullet:

- Analyze 65+ biomarkers alongside your 24/7 WHOOP data
- Get clinician-reviewed results with next steps, all on WHOOP
- See connections between your results and daily behaviors
- Feel safe with your encrypted data, kept private and secure

- CTA Text: Get started with Advanced Labs
- CTA URL: /labs
- Image: bir kadın tablet ile (lifestyle, gece şehir ışığı)

3 badge:

| Title | Status | Position |
|-------|--------|----------|
| HRV ▲ | (boş) | Top Left |
| Cholesterol | ! Out of Range | Middle Left |
| Hemoglobin | ● Sufficient | Bottom Right |

- Show JOIN NOW pill: ON
- Join Pill Text: Join Now

## Genel ipuçları

- **Görsel kalitesi**: Tüm fotoğrafları yüklemeden önce 70-80% kalitede WebP formatına dönüştür. WP varsayılan olarak yeniden boyutlar ama uploadta orijinali da saklar.
- **Renk tutarlılığı**: Tier kartları (one/peak/life) renkleri CSS'te sabitlendi. tier_slug'ı doğru yaz, yoksa default gri kalır.
- **Ücretsiz görsel kaynakları**: Pexels, Unsplash, Pixabay (her zaman lisans şartlarını oku).
- **Video boyutu**: Hero video 5-10MB civarı .mp4 ideal. Daha büyükse mobilde yavaş yüklenir, optimize için ffmpeg veya HandBrake.
