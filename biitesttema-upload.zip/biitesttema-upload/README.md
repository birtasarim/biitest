# WHOOP Clone — WordPress Theme

A custom WordPress theme built from a WHOOP-inspired landing page. Every section is a **Gutenberg block** powered by ACF Pro, so editors can compose pages by drag-and-drop without touching code.

## Requirements

- **WordPress** 6.0+
- **PHP** 7.4+
- **Advanced Custom Fields Pro** ≥ 6.0 — required for the editor experience
- **WooCommerce** (optional) — only if you enable the shop

## Installation

### 1. Install ACF Pro
Download from [advancedcustomfields.com](https://www.advancedcustomfields.com/pro/) and upload via **Plugins → Add New → Upload Plugin**. Activate and enter your license key under **ACF → Updates**.

### 2. Install this theme
- Zip this folder (or use the bundled `whoop-theme.zip`)
- WP Admin → **Appearance → Themes → Add New → Upload Theme**
- Activate **WHOOP Clone**

### 3. Install WooCommerce (optional)
**Plugins → Add New → search "WooCommerce" → Install → Activate**. Run the setup wizard.

### 4. Set the homepage
- Create a new page titled "Home"
- WP Admin → **Settings → Reading**
- Choose "A static page" → set **Homepage** to "Home"
- Edit the Home page and start dropping blocks from the **WHOOP** category

## Block reference

All blocks appear under the **WHOOP** category in the block inserter (`/` then start typing).

| Block | Purpose | Key fields |
| --- | --- | --- |
| Hero | Sticky video hero with scroll overlay | video URL, poster image, headline, CTAs |
| Daily | Get-started card + Wear daily wide image | small image+title+CTA, big headline+wide image+badge |
| Features Slider | Horizontal feature cards with modal | repeater of feature cards, each with modal content |
| Memberships | Tier grid (one/peak/life) | repeater of tiers, each with image+price+features |
| Gift Banner | Compact dark gift card | image, title, text, CTA |
| Social Proof Mosaic | Athletes + quotes mosaic | repeater of mixed image/quote items |
| Principles Accordion | Auto-cycling list with timer | repeater of principles (title+desc+image) |
| Showcase | Image left + pill tabs right | repeater of tabs (label+image+title+desc) |
| Trial | Dark card with try-before-buy CTA | title, desc, CTA, visual image, JOIN NOW pill |
| Advanced Labs | Light section with bullets + glass badges | headline, bullets, CTA, image, badge repeater |

## Global text (Customizer)

**Appearance → Customize → WHOOP — Global Text** lets editors change:
- Promo bar text + link
- Header "Gift WHOOP" / "Join Now" buttons
- Footer tagline

## Navigation menus

Register menus under **Appearance → Menus**. Available locations:
- **Primary Navigation** — main header nav
- **Footer — Shop / Company / Support / Legal** — four footer columns

## File structure

```
whoop-theme/
├── style.css                         theme metadata + complete CSS
├── functions.php                     bootstrap; require()s inc/* files
├── header.php / footer.php           promo bar + nav, footer columns
├── front-page.php                    homepage (renders editor blocks)
├── page.php / single.php / archive.php / index.php / 404.php / searchform.php
├── assets/js/main.js                 GSAP + Lenis + modals + slider + accordion
├── assets/images/                    static logos
├── inc/
│   ├── theme-setup.php               supports, menus, image sizes
│   ├── enqueue.php                   CSS/JS/font loading
│   ├── blocks.php                    auto-registers blocks/, helpers
│   └── acf-fields.php                all ACF field groups in PHP
└── template-parts/blocks/<name>/
    ├── block.json                    block manifest
    └── <name>.php                    render template
```

## Development

### Add a new block
1. Create `template-parts/blocks/my-block/`
2. Add `block.json`:
   ```json
   {
     "$schema": "https://schemas.wp.org/trunk/block.json",
     "apiVersion": 3,
     "name": "whoop/my-block",
     "title": "My Block",
     "category": "whoop",
     "icon": "smiley",
     "supports": { "align": ["full"], "anchor": true },
     "acf": { "mode": "preview", "renderTemplate": "my-block.php" }
   }
   ```
3. Add `my-block.php` (the render template)
4. Add a field group in `inc/acf-fields.php` with location `block == whoop/my-block`
5. Add CSS to `style.css`
6. Reload WP admin — new block appears automatically

### Image sizes
Defined in `inc/theme-setup.php`. After adding a new size, run a regeneration plugin (Regenerate Thumbnails) or re-upload the affected images.

### Caching
Bump `WHOOP_THEME_VERSION` in `functions.php` to bust browser caches after CSS/JS changes.

## Known caveats

- **No ACF Pro = no editor UI.** Front-end will still render saved blocks, but editors cannot create or modify them.
- **Smooth scroll (Lenis)** is loaded from a public CDN. For zero-third-party-requests, download `lenis.min.js` and serve locally — adjust `inc/enqueue.php`.
- **GSAP** loaded from cdnjs. Same — host locally if your CSP requires it.

## License

GPL v2 or later, same as WordPress core.
