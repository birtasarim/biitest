<?php
/**
 * Front page template.
 *
 * Renders whatever blocks the admin assembled in the Page Editor.
 * Out of the box, the home page is set in WP Settings → Reading.
 *
 * @package whoop-clone
 */

defined( 'ABSPATH' ) || exit;

get_header();

/**
 * Render default landing sections when the homepage content is empty.
 */
function whoop_render_front_page_fallback_sections() {
	if ( ! function_exists( 'get_field' ) ) {
		echo '<section class="container">';
		echo '<h1>' . esc_html__( 'Page builder content requires ACF', 'whoop-clone' ) . '</h1>';
		echo '<p>' . esc_html__( 'Activate the Advanced Custom Fields plugin to render the full landing sections.', 'whoop-clone' ) . '</p>';
		echo '</section>';
		return;
	}

	$default_blocks = array(
		'hero'            => 'template-parts/blocks/hero/hero',
		'daily'           => 'template-parts/blocks/daily/daily',
		'features-slider' => 'template-parts/blocks/features-slider/features-slider',
		'memberships'     => 'template-parts/blocks/memberships/memberships',
		'gift'            => 'template-parts/blocks/gift/gift',
		'social-proof'    => 'template-parts/blocks/social-proof/social-proof',
		'trial'           => 'template-parts/blocks/trial/trial',
		'principles'      => 'template-parts/blocks/principles/principles',
		'showcase'        => 'template-parts/blocks/showcase/showcase',
		'advanced-labs'   => 'template-parts/blocks/advanced-labs/advanced-labs',
		'sample-benefits' => 'template-parts/blocks/sample-benefits/sample-benefits',
		'contact-faq'     => 'template-parts/blocks/contact-faq/contact-faq',
	);

	foreach ( $default_blocks as $block_slug => $block_template ) {
		whoop_set_fallback_block_context( $block_slug );
		get_template_part( $block_template );
	}
	whoop_set_fallback_block_context( '' );
}

if ( have_posts() ) {
	the_post();
	$page_content = get_the_content();

	if ( has_blocks( $page_content ) || '' !== trim( wp_strip_all_tags( $page_content ) ) ) {
		?>
		<article id="post-<?php the_ID(); ?>" <?php post_class( 'page-article' ); ?>>
			<?php the_content(); ?>
		</article>
		<?php
	} else {
		whoop_render_front_page_fallback_sections();
	}
} else {
	whoop_render_front_page_fallback_sections();
}

get_footer();
