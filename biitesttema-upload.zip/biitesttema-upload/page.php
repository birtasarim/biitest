<?php
/**
 * Generic page template.
 * Used for any custom static page; admin can drop blocks freely.
 *
 * @package whoop-clone
 */

defined( 'ABSPATH' ) || exit;

get_header();

if ( have_posts() ) {
	while ( have_posts() ) {
		the_post();
		$wc_narrow =
			function_exists( 'WC' ) &&
			(
				is_cart() ||
				is_checkout() ||
				( function_exists( 'is_account_page' ) && is_account_page() ) ||
				( function_exists( 'is_order_received_page' ) && is_order_received_page() )
			);
		?>
		<article id="post-<?php the_ID(); ?>" <?php post_class( 'page-article' ); ?>>
			<?php if ( $wc_narrow ) : ?>
				<div class="whoop-wc-page-inner whoop-wc-surface">
			<?php endif; ?>
			<?php
			if ( function_exists( 'is_checkout' ) && is_checkout() && function_exists( 'whoop_checkout_trust_strip' ) ) {
				whoop_checkout_trust_strip();
			}
			the_content();
			?>
			<?php if ( $wc_narrow ) : ?>
				</div>
			<?php endif; ?>
		</article>
		<?php
	}
}

get_footer();
