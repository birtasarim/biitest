<?php
/**
 * WordPress menu item enhancements for mega-menu cards.
 *
 * Adds an optional image field to nav menu items and a custom walker
 * that renders submenu items as richer cards.
 *
 * @package whoop-clone
 */

defined( 'ABSPATH' ) || exit;

/**
 * Attach saved menu item image data to menu item objects.
 */
function whoop_setup_nav_menu_item_image( $menu_item ) {
	$image_id = (int) get_post_meta( $menu_item->ID, '_menu_item_whoop_image_id', true );

	$menu_item->whoop_image_id  = $image_id;
	$menu_item->whoop_image_url = $image_id ? wp_get_attachment_image_url( $image_id, 'medium' ) : '';

	return $menu_item;
}
add_filter( 'wp_setup_nav_menu_item', 'whoop_setup_nav_menu_item_image' );

/**
 * Add menu item image controls in Appearance -> Menus.
 */
function whoop_nav_menu_item_custom_fields( $item_id, $item, $depth ) {
	$image_id  = (int) get_post_meta( $item_id, '_menu_item_whoop_image_id', true );
	$image_url = $image_id ? wp_get_attachment_image_url( $image_id, 'medium' ) : '';
	?>
	<p class="description description-wide whoop-menu-image-field">
		<label for="edit-menu-item-whoop-image-id-<?php echo esc_attr( $item_id ); ?>">
			<?php esc_html_e( 'Mega Menu Image', 'whoop-clone' ); ?><br />
			<input
				type="hidden"
				class="widefat code edit-menu-item-whoop-image-id"
				id="edit-menu-item-whoop-image-id-<?php echo esc_attr( $item_id ); ?>"
				name="menu-item-whoop-image-id[<?php echo esc_attr( $item_id ); ?>]"
				value="<?php echo esc_attr( $image_id ); ?>"
			/>
			<span class="whoop-menu-image-preview<?php echo $image_url ? ' has-image' : ''; ?>">
				<?php if ( $image_url ) : ?>
					<img src="<?php echo esc_url( $image_url ); ?>" alt="" />
				<?php endif; ?>
			</span>
		</label>
		<span class="whoop-menu-image-actions">
			<button type="button" class="button button-secondary whoop-menu-image-select">
				<?php esc_html_e( 'Choose image', 'whoop-clone' ); ?>
			</button>
			<button type="button" class="button-link whoop-menu-image-remove"<?php echo $image_url ? '' : ' hidden'; ?>>
				<?php esc_html_e( 'Remove image', 'whoop-clone' ); ?>
			</button>
		</span>
		<?php if ( 0 === (int) $depth ) : ?>
			<span class="description">
				<?php esc_html_e( 'Top-level items use child items as mega-menu cards. Add images to the child items you want to show as cards.', 'whoop-clone' ); ?>
			</span>
		<?php endif; ?>
	</p>
	<?php
}
add_action( 'wp_nav_menu_item_custom_fields', 'whoop_nav_menu_item_custom_fields', 10, 3 );

/**
 * Save menu item image field.
 */
function whoop_update_nav_menu_item( $menu_id, $menu_item_db_id ) {
	$value = 0;
	if ( isset( $_POST['menu-item-whoop-image-id'][ $menu_item_db_id ] ) ) {
		$value = absint( wp_unslash( $_POST['menu-item-whoop-image-id'][ $menu_item_db_id ] ) );
	}

	if ( $value ) {
		update_post_meta( $menu_item_db_id, '_menu_item_whoop_image_id', $value );
	} else {
		delete_post_meta( $menu_item_db_id, '_menu_item_whoop_image_id' );
	}
}
add_action( 'wp_update_nav_menu_item', 'whoop_update_nav_menu_item', 10, 2 );

/**
 * Enqueue media support and admin UI helpers on the nav menu screen.
 */
function whoop_nav_menu_admin_assets( $hook_suffix ) {
	if ( 'nav-menus.php' !== $hook_suffix ) {
		return;
	}

	wp_enqueue_media();
	wp_add_inline_style(
		'nav-menus',
		'.whoop-menu-image-preview{display:none;margin-top:8px;max-width:180px;border:1px solid #dcdcde;border-radius:8px;overflow:hidden;background:#fff}' .
		'.whoop-menu-image-preview.has-image{display:block}' .
		'.whoop-menu-image-preview img{display:block;width:100%;height:auto}' .
		'.whoop-menu-image-actions{display:flex;gap:10px;align-items:center;margin-top:10px}' .
		'.whoop-menu-image-remove[hidden]{display:none!important}'
	);
	$inline_script = <<<'JS'
(function($){
	$(document).on('click', '.whoop-menu-image-select', function(e){
		e.preventDefault();
		var wrap = $(this).closest('.whoop-menu-image-field');
		var input = wrap.find('.edit-menu-item-whoop-image-id');
		var preview = wrap.find('.whoop-menu-image-preview');
		var remove = wrap.find('.whoop-menu-image-remove');
		var frame = wp.media({
			title: 'Select mega menu image',
			button: { text: 'Use image' },
			multiple: false
		});

		frame.on('select', function(){
			var attachment = frame.state().get('selection').first().toJSON();
			var src = (attachment.sizes && attachment.sizes.medium && attachment.sizes.medium.url) || attachment.url;
			input.val(attachment.id);
			preview.html('<img src="' + src + '" alt="" />').addClass('has-image');
			remove.prop('hidden', false);
		});

		frame.open();
	});

	$(document).on('click', '.whoop-menu-image-remove', function(e){
		e.preventDefault();
		var wrap = $(this).closest('.whoop-menu-image-field');
		wrap.find('.edit-menu-item-whoop-image-id').val('');
		wrap.find('.whoop-menu-image-preview').removeClass('has-image').empty();
		$(this).prop('hidden', true);
	});
})(jQuery);
JS;
	wp_add_inline_script(
		'nav-menu',
		$inline_script
	);
}
add_action( 'admin_enqueue_scripts', 'whoop_nav_menu_admin_assets' );

/**
 * Custom walker for the primary nav mega-menu markup.
 */
class Whoop_Primary_Nav_Walker extends Walker_Nav_Menu {
	/**
	 * Start the submenu list.
	 */
	public function start_lvl( &$output, $depth = 0, $args = null ) {
		$indent  = str_repeat( "\t", $depth );
		$output .= "\n$indent<ul class=\"sub-menu\">\n";
	}

	/**
	 * Start each menu item.
	 */
	public function start_el( &$output, $item, $depth = 0, $args = null, $id = 0 ) {
		$indent     = $depth ? str_repeat( "\t", $depth ) : '';
		$classes    = empty( $item->classes ) ? array() : (array) $item->classes;
		$classes[]  = 'menu-item-' . $item->ID;
		$class_name = trim( implode( ' ', array_map( 'sanitize_html_class', array_filter( $classes ) ) ) );

		$output .= $indent . '<li' . ( $class_name ? ' class="' . esc_attr( $class_name ) . '"' : '' ) . '>';

		$atts = array(
			'title'  => ! empty( $item->attr_title ) ? $item->attr_title : '',
			'target' => ! empty( $item->target ) ? $item->target : '',
			'rel'    => ! empty( $item->xfn ) ? $item->xfn : '',
			'href'   => ! empty( $item->url ) ? $item->url : '',
			'class'  => 0 === $depth ? 'nav-link' : 'mega-link',
		);

		$attributes = '';
		foreach ( $atts as $attr => $value ) {
			if ( '' === $value ) {
				continue;
			}
			$value       = 'href' === $attr ? esc_url( $value ) : esc_attr( $value );
			$attributes .= ' ' . $attr . '="' . $value . '"';
		}

		$title = apply_filters( 'the_title', $item->title, $item->ID );

		if ( 0 === $depth ) {
			$output .= '<a' . $attributes . '>' . esc_html( $title ) . '</a>';
			return;
		}

		$output .= '<a' . $attributes . '>';
		if ( ! empty( $item->whoop_image_id ) ) {
			$output .= '<span class="mega-link-media">' . wp_get_attachment_image( $item->whoop_image_id, 'medium', false, array( 'loading' => 'lazy' ) ) . '</span>';
		}
		$output .= '<span class="mega-link-copy">';
		$output .= '<span class="mega-link-title">' . esc_html( $title ) . '</span>';
		if ( ! empty( $item->description ) ) {
			$output .= '<span class="mega-link-desc">' . esc_html( $item->description ) . '</span>';
		}
		$output .= '</span>';
		$output .= '<span class="mega-link-arrow" aria-hidden="true">&rarr;</span>';
		$output .= '</a>';
	}

	/**
	 * End each menu item.
	 */
	public function end_el( &$output, $item, $depth = 0, $args = null ) {
		$output .= "</li>\n";
	}
}
