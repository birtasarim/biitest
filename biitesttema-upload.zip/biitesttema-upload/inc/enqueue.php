<?php
/**
 * Asset enqueue — Vite-aware.
 *
 * In dev mode (whoop-theme/.dev exists OR define('WHOOP_VITE_DEV', true) in wp-config.php),
 * we load assets directly from the Vite dev server (http://localhost:5173).
 *
 * In production, we read assets/dist/.vite/manifest.json to find the hashed
 * compiled JS/CSS and enqueue those.
 *
 * If neither dev mode nor a manifest is present, we fall back to a CDN bundle
 * so a freshly-installed theme still renders without `npm run build`.
 *
 * @package whoop-clone
 */

defined( 'ABSPATH' ) || exit;

/**
 * Check whether we should serve assets from the Vite dev server.
 */
function whoop_is_vite_dev() {
	$dev_requested = false;
	if ( defined( 'WHOOP_VITE_DEV' ) && WHOOP_VITE_DEV ) {
		$dev_requested = true;
	}
	if ( file_exists( WHOOP_THEME_DIR . '/.dev' ) ) {
		$dev_requested = true;
	}
	if ( ! $dev_requested ) {
		return false;
	}

	// Only use dev mode if Vite server is actually reachable.
	$host = '127.0.0.1';
	$port = 5173;
	$sock = @fsockopen( $host, $port, $errno, $errstr, 0.2 );
	if ( is_resource( $sock ) ) {
		fclose( $sock );
		return true;
	}
	return false;
}

/**
 * Read the Vite manifest produced by `npm run build`.
 *
 * Vite 5 emits manifest.json at the build output root; 4 emitted to .vite/manifest.json.
 * We check both for compatibility.
 *
 * @return array
 */
function whoop_vite_manifest() {
	static $manifest = null;
	if ( null !== $manifest ) {
		return $manifest;
	}
	$candidates = array(
		WHOOP_THEME_DIR . '/assets/dist/manifest.json',
		WHOOP_THEME_DIR . '/assets/dist/.vite/manifest.json',
	);
	foreach ( $candidates as $path ) {
		if ( file_exists( $path ) ) {
			$json     = file_get_contents( $path );
			$manifest = $json ? json_decode( $json, true ) : array();
			return $manifest;
		}
	}
	$manifest = array();
	return $manifest;
}

/**
 * Fonts are loaded the same way regardless of build mode.
 */
function whoop_enqueue_fonts() {
	add_action(
		'wp_head',
		function () {
			echo '<link rel="preconnect" href="https://fonts.googleapis.com">';
			echo '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>';
		},
		1
	);

	wp_enqueue_style(
		'whoop-fonts',
		'https://fonts.googleapis.com/css2?family=Archivo:wght@400;500;600;700;800;900&family=Archivo+Narrow:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;700&display=swap',
		array(),
		null
	);
}

/**
 * Collect CSS file paths from the Vite manifest (main entry + standalone CSS chunks).
 *
 * @param array $manifest Vite manifest.
 * @return string[]
 */
function whoop_manifest_main_entry_key( $manifest ) {
	foreach ( array( 'src/js/main.js', 'main' ) as $key ) {
		if ( ! empty( $manifest[ $key ] ) ) {
			return $key;
		}
	}
	return 'src/js/main.js';
}

function whoop_manifest_wc_shell_entry_key( $manifest ) {
	foreach ( array( 'src/js/wc-shell.js', 'wc-shell' ) as $key ) {
		if ( ! empty( $manifest[ $key ] ) ) {
			return $key;
		}
	}
	return 'src/js/wc-shell.js';
}

/**
 * CSS belongs to the main bundle only (checkout uses wc-shell JS without a second stylesheet).
 *
 * @param array $manifest Vite manifest.
 * @return string[]
 */
function whoop_manifest_css_files( $manifest ) {
	$entry     = whoop_manifest_main_entry_key( $manifest );
	$css_files = array();

	if ( ! empty( $manifest[ $entry ]['css'] ) && is_array( $manifest[ $entry ]['css'] ) ) {
		$css_files = array_merge( $css_files, $manifest[ $entry ]['css'] );
	}

	if ( ! empty( $manifest['style.css']['file'] ) ) {
		$css_files[] = $manifest['style.css']['file'];
	}

	foreach ( $manifest as $info ) {
		if ( ! empty( $info['file'] ) && substr( $info['file'], -4 ) === '.css' ) {
			$css_files[] = $info['file'];
		}
	}

	return array_unique( $css_files );
}

/**
 * Enqueue compiled theme styles from the manifest.
 *
 * @param array  $manifest Vite manifest.
 * @param string $base_uri Base URI for dist assets.
 */
function whoop_enqueue_manifest_styles( $manifest, $base_uri ) {
	foreach ( whoop_manifest_css_files( $manifest ) as $css_file ) {
		wp_enqueue_style(
			'whoop-style-' . md5( $css_file ),
			$base_uri . $css_file,
			array( 'whoop-fonts' ),
			WHOOP_THEME_VERSION
		);
	}
}

/**
 * Enqueue dev-server assets (HMR + ESM-native).
 */
function whoop_enqueue_dev_assets() {
	$dev_url = 'http://localhost:5173';
	$lite    = function_exists( 'whoop_use_checkout_lite_script' ) && whoop_use_checkout_lite_script();

	wp_enqueue_script(
		'whoop-vite-client',
		$dev_url . '/@vite/client',
		array(),
		null,
		false
	);

	$entry_path = $lite ? '/src/js/wc-shell.js' : '/src/js/main.js';
	$handle     = $lite ? 'whoop-wc-shell' : 'whoop-main';

	wp_enqueue_script(
		$handle,
		$dev_url . $entry_path,
		array( 'whoop-vite-client' ),
		null,
		true
	);
}

/**
 * Enqueue production build assets (hashed, compiled).
 */
function whoop_enqueue_built_assets() {
	$manifest = whoop_vite_manifest();
	$main_key = whoop_manifest_main_entry_key( $manifest );

	if ( empty( $manifest[ $main_key ] ) ) {
		whoop_enqueue_cdn_fallback();
		return;
	}

	$base   = WHOOP_THEME_URI . '/assets/dist/';
	$lite   = function_exists( 'whoop_use_checkout_lite_script' ) && whoop_use_checkout_lite_script();
	$js_key = $lite ? whoop_manifest_wc_shell_entry_key( $manifest ) : $main_key;

	whoop_enqueue_manifest_styles( $manifest, $base );

	if ( ! empty( $manifest[ $js_key ]['file'] ) ) {
		wp_enqueue_script(
			$lite ? 'whoop-wc-shell' : 'whoop-main',
			$base . $manifest[ $js_key ]['file'],
			array(),
			WHOOP_THEME_VERSION,
			true
		);
	} elseif ( ! $lite && ! empty( $manifest[ $main_key ]['file'] ) ) {
		wp_enqueue_script(
			'whoop-main',
			$base . $manifest[ $main_key ]['file'],
			array(),
			WHOOP_THEME_VERSION,
			true
		);
	}
}

/**
 * Type=module on the main script tag (Vite output is ESM).
 */
function whoop_module_script_loader_tag( $tag, $handle ) {
	$module_handles = array( 'whoop-main', 'whoop-wc-shell', 'whoop-vite-client' );
	if ( in_array( $handle, $module_handles, true ) ) {
		$tag = str_replace( '<script ', '<script type="module" ', $tag );
	}
	return $tag;
}
add_filter( 'script_loader_tag', 'whoop_module_script_loader_tag', 10, 2 );

/**
 * Last-resort fallback when no build artifact is present.
 * Surfaces a clear admin notice telling the user to run the build, but doesn't
 * try to render anything else — silent CDN fallbacks just hide the real problem.
 */
function whoop_enqueue_cdn_fallback() {
	// Intentionally empty. The admin notice (whoop_admin_build_notice) does the work.
	// On the front-end, the page will still load with raw HTML — visually unstyled
	// until `npm run build` runs.
}

/**
 * Show admin notice if no build artifact exists and not in dev mode.
 */
function whoop_admin_build_notice() {
	if ( whoop_is_vite_dev() ) {
		return;
	}
	if ( ! empty( whoop_vite_manifest() ) ) {
		return;
	}
	?>
	<div class="notice notice-info">
		<p>
			<strong>WHOOP Theme:</strong>
			<?php
			echo wp_kses_post(
				__(
					'No compiled assets found. Run <code>npm install && npm run build</code> in the theme directory to compile SCSS/JS. Falling back to a CDN bundle for now.',
					'whoop-clone'
				)
			);
			?>
		</p>
	</div>
	<?php
}
add_action( 'admin_notices', 'whoop_admin_build_notice' );

/**
 * Main enqueue dispatcher.
 */
function whoop_enqueue_assets() {
	whoop_enqueue_fonts();

	if ( whoop_is_vite_dev() ) {
		whoop_enqueue_dev_assets();
	} else {
		whoop_enqueue_built_assets();
	}

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'whoop_enqueue_assets' );

/**
 * Editor (Gutenberg) styles so block previews resemble the front-end.
 */
function whoop_enqueue_editor_assets() {
	wp_enqueue_style(
		'whoop-fonts-editor',
		'https://fonts.googleapis.com/css2?family=Archivo:wght@400;500;600;700;800;900&family=Archivo+Narrow:wght@400;500;600;700&display=swap',
		array(),
		null
	);

	$manifest = whoop_vite_manifest();
	if ( empty( $manifest ) ) {
		return;
	}

	$base  = WHOOP_THEME_URI . '/assets/dist/';
	$entry = 'src/js/main.js';

	foreach ( whoop_manifest_css_files( $manifest ) as $css_file ) {
		wp_enqueue_style(
			'whoop-editor-style-' . md5( $css_file ),
			$base . $css_file,
			array( 'whoop-fonts-editor' ),
			WHOOP_THEME_VERSION
		);
	}
}
add_action( 'enqueue_block_editor_assets', 'whoop_enqueue_editor_assets' );
