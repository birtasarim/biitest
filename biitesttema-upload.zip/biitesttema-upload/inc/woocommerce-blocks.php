<?php
/**
 * WooCommerce Blocks compatibility checks and page format detection.
 *
 * @package whoop-clone
 */

defined( 'ABSPATH' ) || exit;

/**
 * Detect cart or checkout page content format.
 *
 * @param string $page_type 'cart' or 'checkout'.
 * @return string 'block'|'classic'|'missing'|'unknown'
 */
function whoop_wc_page_uses_blocks( $page_type ) {
	if ( ! whoop_is_woocommerce_active() || ! function_exists( 'wc_get_page_id' ) ) {
		return 'unknown';
	}

	$page_key = in_array( $page_type, array( 'cart', 'checkout' ), true ) ? $page_type : '';
	if ( '' === $page_key ) {
		return 'unknown';
	}

	$page_id = absint( wc_get_page_id( $page_key ) );
	if ( ! $page_id ) {
		return 'unknown';
	}

	$post = get_post( $page_id );
	if ( ! $post ) {
		return 'unknown';
	}

	$block_name = 'cart' === $page_key ? 'woocommerce/cart' : 'woocommerce/checkout';
	$shortcode  = 'cart' === $page_key ? 'woocommerce_cart' : 'woocommerce_checkout';

	if ( function_exists( 'has_block' ) && has_block( $block_name, $post ) ) {
		return 'block';
	}

	if ( function_exists( 'has_shortcode' ) && has_shortcode( $post->post_content, $shortcode ) ) {
		return 'classic';
	}

	return 'missing';
}

/**
 * Detect checkout page rendering mode (block-only theme).
 *
 * @return string 'block'|'classic'|'missing'|'unknown'
 */
function whoop_get_checkout_page_format() {
	return whoop_wc_page_uses_blocks( 'checkout' );
}

/**
 * Detect cart page rendering mode (block-only theme).
 *
 * @return string 'block'|'classic'|'missing'|'unknown'
 */
function whoop_get_cart_page_format() {
	return whoop_wc_page_uses_blocks( 'cart' );
}

/**
 * Whether the current request should use the lite checkout script bundle.
 *
 * @return bool
 */
function whoop_use_checkout_lite_script() {
	if ( ! function_exists( 'is_checkout' ) || ! is_checkout() ) {
		return false;
	}

	if ( function_exists( 'is_wc_endpoint_url' ) && is_wc_endpoint_url() ) {
		return false;
	}

	return true;
}

/**
 * Admin notice when cart/checkout pages are not using blocks.
 */
function whoop_admin_wc_page_format_notices() {
	if ( ! current_user_can( 'manage_woocommerce' ) || ! whoop_is_woocommerce_active() ) {
		return;
	}

	$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
	if ( ! $screen ) {
		return;
	}

	$allowed = array( 'edit-page', 'page', 'woocommerce_page_wc-settings' );
	if ( ! in_array( $screen->id, $allowed, true ) ) {
		return;
	}

	$docs_url = 'https://woocommerce.com/document/cart-checkout-blocks-status/';
	$pages    = array(
		'cart'     => array(
			'label' => __( 'Cart', 'whoop-clone' ),
			'id'    => absint( wc_get_page_id( 'cart' ) ),
		),
		'checkout' => array(
			'label' => __( 'Checkout', 'whoop-clone' ),
			'id'    => absint( wc_get_page_id( 'checkout' ) ),
		),
	);

	foreach ( $pages as $type => $meta ) {
		if ( ! $meta['id'] ) {
			continue;
		}

		if ( 'page' === $screen->id ) {
			$editing_id = isset( $_GET['post'] ) ? absint( $_GET['post'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			if ( $editing_id && $editing_id !== $meta['id'] ) {
				continue;
			}
		}

		$format = whoop_wc_page_uses_blocks( $type );
		if ( 'block' === $format ) {
			continue;
		}

		$edit_link = get_edit_post_link( $meta['id'], 'raw' );
		$class     = 'notice notice-warning';

		if ( 'classic' === $format ) {
			$message = sprintf(
				/* translators: 1: page label (Cart/Checkout), 2: edit link, 3: docs URL */
				__( '%1$s page uses the classic shortcode. This theme supports Cart/Checkout blocks only. Edit the page and add the %1$s block, or use the block transform in the editor. %2$s | %3$s', 'whoop-clone' ),
				esc_html( $meta['label'] ),
				$edit_link ? '<a href="' . esc_url( $edit_link ) . '">' . esc_html__( 'Edit page', 'whoop-clone' ) . '</a>' : '',
				'<a href="' . esc_url( $docs_url ) . '" target="_blank" rel="noopener noreferrer">' . esc_html__( 'WooCommerce guide', 'whoop-clone' ) . '</a>'
			);
		} else {
			$message = sprintf(
				/* translators: 1: page label, 2: edit link, 3: docs URL */
				__( '%1$s page has no Cart/Checkout block or shortcode. Add the WooCommerce %1$s block. %2$s | %3$s', 'whoop-clone' ),
				esc_html( $meta['label'] ),
				$edit_link ? '<a href="' . esc_url( $edit_link ) . '">' . esc_html__( 'Edit page', 'whoop-clone' ) . '</a>' : '',
				'<a href="' . esc_url( $docs_url ) . '" target="_blank" rel="noopener noreferrer">' . esc_html__( 'WooCommerce guide', 'whoop-clone' ) . '</a>'
			);
		}

		echo '<div class="' . esc_attr( $class ) . '"><p>' . wp_kses_post( $message ) . '</p>';
		echo '<p><em>' . esc_html__( 'Payment methods must support block checkout. If a gateway is missing, contact your payment provider for Blocks API support.', 'whoop-clone' ) . '</em></p></div>';
	}
}
add_action( 'admin_notices', 'whoop_admin_wc_page_format_notices' );

/**
 * Admin notice when block checkout scripts are missing on the checkout page.
 */
function whoop_admin_checkout_blocks_notice() {
	if ( ! current_user_can( 'manage_woocommerce' ) ) {
		return;
	}

	$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
	if ( ! $screen || 'woocommerce_page_wc-settings' !== $screen->id ) {
		return;
	}

	if ( ! whoop_is_woocommerce_active() ) {
		return;
	}

	if ( 'block' !== whoop_get_checkout_page_format() ) {
		return;
	}

	if ( wp_script_is( 'wc-blocks-checkout', 'registered' ) ) {
		return;
	}

	echo '<div class="notice notice-warning"><p>';
	echo esc_html__(
		'WooCommerce Blocks checkout scripts are not registered. Ensure WooCommerce is active and updated. Block checkout may show a loading skeleton on the front end.',
		'whoop-clone'
	);
	echo '</p></div>';
}
add_action( 'admin_notices', 'whoop_admin_checkout_blocks_notice' );

/**
 * Verify WC Blocks checkout script is enqueued on the front end (debug hook).
 */
function whoop_verify_checkout_blocks_scripts() {
	if ( ! whoop_use_checkout_lite_script() || is_admin() ) {
		return;
	}

	if ( ! wp_script_is( 'wc-blocks-checkout', 'enqueued' ) && ! wp_script_is( 'wc-blocks-checkout', 'done' ) ) {
		if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
			error_log( 'WHOOP Theme: wc-blocks-checkout script was not enqueued on checkout.' ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
		}
	}
}
add_action( 'wp_footer', 'whoop_verify_checkout_blocks_scripts', 99 );
