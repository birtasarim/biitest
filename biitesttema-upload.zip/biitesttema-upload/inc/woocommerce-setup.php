<?php
/**
 * WooCommerce integration: layout wrappers, cart fragments, checkout type hints.
 *
 * Cart and checkout: WooCommerce Blocks only (page content + .wc-block-* CSS).
 *
 * @package whoop-clone
 */

defined( 'ABSPATH' ) || exit;

/**
 * Whether WooCommerce is active.
 *
 * @return bool
 */
function whoop_is_woocommerce_active() {
	return class_exists( 'WooCommerce' );
}

/**
 * Add body classes for checkout mode (CSS hooks).
 *
 * @param string[] $classes Body classes.
 * @return string[]
 */
function whoop_woocommerce_body_classes( $classes ) {
	if ( ! whoop_is_woocommerce_active() ) {
		return $classes;
	}

	if ( function_exists( 'is_checkout' ) && is_checkout() ) {
		$classes[] = 'whoop-lenis-native';
		if ( 'block' === whoop_wc_page_uses_blocks( 'checkout' ) ) {
			$classes[] = 'whoop-checkout-block';
		}
	}

	if ( function_exists( 'is_account_page' ) && is_account_page() ) {
		$classes[] = 'whoop-lenis-native';
		$classes[] = 'whoop-account-page';
	}

	if ( function_exists( 'is_product' ) && is_product() && ! is_shop() ) {
		$classes[] = 'whoop-lenis-native';
		$classes[] = 'whoop-single-product';
	}

	if ( function_exists( 'is_shop' ) && is_shop() ) {
		$classes[] = 'whoop-lenis-native';
	}

	if ( function_exists( 'is_product_taxonomy' ) && is_product_taxonomy() ) {
		$classes[] = 'whoop-lenis-native';
	}

	if ( function_exists( 'is_order_received_page' ) && is_order_received_page() ) {
		$classes[] = 'whoop-lenis-native';
		$classes[] = 'whoop-order-received';
	}

	if ( function_exists( 'is_cart' ) && is_cart() ) {
		$classes[] = 'whoop-lenis-native';
		$classes[] = 'whoop-cart-page';
		if ( 'block' === whoop_wc_page_uses_blocks( 'cart' ) ) {
			$classes[] = 'whoop-cart-block';
		}
	}

	return $classes;
}
add_filter( 'body_class', 'whoop_woocommerce_body_classes' );

/**
 * Replace WooCommerce default #container wrappers with theme .container alignment.
 */
function whoop_woocommerce_wrapper_start() {
	$classes = 'whoop-wc-wrap';

	if (
		( function_exists( 'is_cart' ) && is_cart() ) ||
		( function_exists( 'is_checkout' ) && is_checkout() ) ||
		( function_exists( 'is_account_page' ) && is_account_page() )
	) {
		// page.php uses .whoop-wc-page-inner for width — no nested .container.
	} else {
		$classes .= ' container';
	}
	if ( function_exists( 'is_product' ) && is_product() && ! is_shop() ) {
		$classes .= ' whoop-product-single';
	}
	echo '<div class="' . esc_attr( $classes ) . '">';
}
function whoop_woocommerce_wrapper_end() {
	echo '</div>';
}

/**
 * Register wrappers after WC loads.
 */
function whoop_woocommerce_register_wrappers() {
	if ( ! whoop_is_woocommerce_active() ) {
		return;
	}

	remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10 );
	remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10 );
	remove_action( 'woocommerce_sidebar', 'woocommerce_get_sidebar', 10 );

	add_action( 'woocommerce_before_main_content', 'whoop_woocommerce_wrapper_start', 10 );
	add_action( 'woocommerce_after_main_content', 'whoop_woocommerce_wrapper_end', 10 );
}
add_action( 'wp', 'whoop_woocommerce_register_wrappers' );

/**
 * Cart count fragments for header mini badge (AJAX add to cart).
 *
 * @param array $fragments Fragments.
 * @return array
 */
function whoop_woocommerce_cart_fragments( $fragments ) {
	if ( ! whoop_is_woocommerce_active() || ! WC()->cart ) {
		return $fragments;
	}

	$count   = (int) WC()->cart->get_cart_contents_count();
	$display = '';
	if ( $count > 0 ) {
		$display = $count > 99 ? '99+' : (string) $count;
	}

	$html = sprintf(
		'<span class="whoop-cart-count-badge" aria-hidden="true">%s</span>',
		esc_html( $display )
	);

	$fragments['.nav-cta .whoop-header-cart .whoop-cart-count-badge']           = $html;
	$fragments['.mobile-nav-actions .whoop-header-cart .whoop-cart-count-badge'] = $html;

	return $fragments;
}
add_filter( 'woocommerce_add_to_cart_fragments', 'whoop_woocommerce_cart_fragments' );

/**
 * Style handles that must load before WooCommerce overrides.
 *
 * @return string[]
 */
function whoop_wc_custom_style_dependencies() {
	$deps = array();

	if ( wp_style_is( 'woocommerce-general', 'registered' ) ) {
		$deps[] = 'woocommerce-general';
	}

	global $wp_styles;
	if ( $wp_styles instanceof WP_Styles ) {
		foreach ( array_keys( $wp_styles->registered ) as $handle ) {
			if ( 0 === strpos( $handle, 'whoop-style-' ) ) {
				$deps[] = $handle;
				break;
			}
		}
	}

	return $deps;
}

/**
 * Enqueue WooCommerce compatibility layer (after theme dist + Woo core).
 */
function whoop_enqueue_woocommerce_compat_styles() {
	if ( ! whoop_is_woocommerce_active() ) {
		return;
	}

	$path = WHOOP_THEME_DIR . '/assets/css/woocommerce-custom.css';
	if ( ! file_exists( $path ) ) {
		return;
	}

	wp_enqueue_style(
		'whoop-wc-custom',
		WHOOP_THEME_URI . '/assets/css/woocommerce-custom.css',
		whoop_wc_custom_style_dependencies(),
		WHOOP_THEME_VERSION
	);
}
add_action( 'wp_enqueue_scripts', 'whoop_enqueue_woocommerce_compat_styles', 99 );

/**
 * Enqueue late cart/checkout overrides against the compiled WooCommerce bundle.
 *
 * The production dist CSS contains the current cart and checkout gradients and
 * spacing rules. This late-loaded file targets the same block selectors to
 * ensure the uploaded theme can override those surfaces without a full rebuild.
 */
function whoop_enqueue_woocommerce_cart_checkout_fixes() {
	if ( ! whoop_is_woocommerce_active() ) {
		return;
	}

	if ( ! function_exists( 'is_cart' ) || ! function_exists( 'is_checkout' ) ) {
		return;
	}

	if ( ! is_cart() && ! is_checkout() ) {
		return;
	}

	$path = WHOOP_THEME_DIR . '/assets/css/woocommerce-cart-checkout-fixes.css';
	if ( ! file_exists( $path ) ) {
		return;
	}

	wp_enqueue_style(
		'whoop-wc-cart-checkout-fixes',
		WHOOP_THEME_URI . '/assets/css/woocommerce-cart-checkout-fixes.css',
		array( 'whoop-wc-custom' ),
		WHOOP_THEME_VERSION
	);
}
add_action( 'wp_enqueue_scripts', 'whoop_enqueue_woocommerce_cart_checkout_fixes', 110 );

/**
 * Enqueue cart/checkout runtime fixes that don't require a full asset rebuild.
 */
function whoop_enqueue_woocommerce_cart_checkout_runtime() {
	if ( ! whoop_is_woocommerce_active() ) {
		return;
	}

	if ( ! function_exists( 'is_cart' ) || ! function_exists( 'is_checkout' ) ) {
		return;
	}

	if ( ! is_cart() && ! is_checkout() ) {
		return;
	}

	$path = WHOOP_THEME_DIR . '/assets/js/woocommerce-cart-checkout-runtime.js';
	if ( ! file_exists( $path ) ) {
		return;
	}

	wp_enqueue_script(
		'whoop-wc-cart-checkout-runtime',
		WHOOP_THEME_URI . '/assets/js/woocommerce-cart-checkout-runtime.js',
		array(),
		WHOOP_THEME_VERSION,
		true
	);

	wp_localize_script(
		'whoop-wc-cart-checkout-runtime',
		'whoopWcCartCheckoutRuntime',
		array(
			'isCheckout'   => function_exists( 'is_checkout' ) && is_checkout(),
			'storeApiRoot' => esc_url_raw( rest_url( 'wc/store/v1' ) ),
			'nonce'        => wp_create_nonce( 'wc_store_api' ),
			'totalLabel'   => 'Toplam',
		)
	);
}
add_action( 'wp_enqueue_scripts', 'whoop_enqueue_woocommerce_cart_checkout_runtime', 120 );

/**
 * Enqueue single-product runtime enhancements without a full rebuild.
 */
function whoop_enqueue_woocommerce_single_product_runtime() {
	if ( ! whoop_is_woocommerce_active() || ! function_exists( 'is_product' ) || ! is_product() ) {
		return;
	}

	$path = WHOOP_THEME_DIR . '/assets/js/woocommerce-single-product-runtime.js';
	if ( ! file_exists( $path ) ) {
		return;
	}

	wp_enqueue_script(
		'whoop-wc-single-product-runtime',
		WHOOP_THEME_URI . '/assets/js/woocommerce-single-product-runtime.js',
		array(),
		WHOOP_THEME_VERSION,
		true
	);
}
add_action( 'wp_enqueue_scripts', 'whoop_enqueue_woocommerce_single_product_runtime', 121 );

/**
 * Quantity stepper buttons around single-product quantity input.
 */
function whoop_single_product_quantity_button_before() {
	echo '<button type="button" class="whoop-qty-step whoop-qty-step--minus" data-whoop-qty-step="-1" aria-label="' . esc_attr__( 'Adedi azalt', 'whoop-clone' ) . '">-</button>';
}
add_action( 'woocommerce_before_add_to_cart_quantity', 'whoop_single_product_quantity_button_before' );

/**
 * Quantity stepper buttons around single-product quantity input.
 */
function whoop_single_product_quantity_button_after() {
	echo '<button type="button" class="whoop-qty-step whoop-qty-step--plus" data-whoop-qty-step="1" aria-label="' . esc_attr__( 'Adedi artır', 'whoop-clone' ) . '">+</button>';
}
add_action( 'woocommerce_after_add_to_cart_quantity', 'whoop_single_product_quantity_button_after' );

/**
 * Free shipping threshold amount (store currency).
 *
 * @return float
 */
function whoop_free_shipping_threshold() {
	$mod = get_theme_mod( 'whoop_free_shipping_threshold', 500 );
	return (float) apply_filters( 'whoop_free_shipping_threshold', (float) $mod );
}

/**
 * SVG icon for trust rows.
 *
 * @param string $name Icon key.
 * @return string
 */
function whoop_wc_trust_icon_svg( $name ) {
	$icons = array(
		'lock'    => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 118 0v3"/></svg>',
		'truck'   => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M3 7h11v8H3zM14 10h4l3 3v2h-7z"/><circle cx="7" cy="17" r="2"/><circle cx="17" cy="17" r="2"/></svg>',
		'refresh' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M4 12a8 8 0 0114-5M20 12a8 8 0 01-14 5"/><path d="M4 4v4h4M20 20v-4h-4"/></svg>',
		'shield'  => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M12 3l8 3v6c0 5-3.5 8.5-8 9-4.5-.5-8-4-8-9V6z"/></svg>',
	);
	$svg = isset( $icons[ $name ] ) ? $icons[ $name ] : $icons['shield'];
	return '<span class="whoop-trust-icon">' . $svg . '</span>';
}

/**
 * Trust items for PDP and checkout.
 *
 * @return array<int, array{icon: string, text: string}>
 */
function whoop_get_trust_items() {
	$allowed_icons = array( 'lock', 'truck', 'refresh', 'shield' );
	$items         = array();

	for ( $i = 1; $i <= 3; $i++ ) {
		$text = (string) get_theme_mod( "whoop_trust_{$i}_text" );
		if ( '' === trim( $text ) ) {
			continue;
		}

		$icon = (string) get_theme_mod( "whoop_trust_{$i}_icon", 'shield' );
		if ( ! in_array( $icon, $allowed_icons, true ) ) {
			$icon = 'shield';
		}

		$items[] = array(
			'icon' => $icon,
			'text' => $text,
		);
	}

	return apply_filters( 'whoop_product_trust_items', $items );
}

/**
 * Render trust row list markup.
 *
 * @param string $class Extra class on ul.
 */
function whoop_render_trust_row( $class = 'whoop-product-trust-row' ) {
	$items = whoop_get_trust_items();
	if ( empty( $items ) ) {
		return;
	}
	echo '<ul class="' . esc_attr( $class ) . '">';
	foreach ( $items as $item ) {
		$icon = isset( $item['icon'] ) ? (string) $item['icon'] : 'shield';
		$text = isset( $item['text'] ) ? (string) $item['text'] : '';
		if ( '' === $text ) {
			continue;
		}
		echo '<li>' . whoop_wc_trust_icon_svg( $icon ) . esc_html( $text ) . '</li>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
	echo '</ul>';
}

/**
 * PDP trust row below price.
 */
function whoop_product_trust_row() {
	whoop_render_trust_row( 'whoop-product-trust-row' );
}
add_action( 'woocommerce_single_product_summary', 'whoop_product_trust_row', 12 );

/**
 * Checkout trust strip (block checkout via page.php; classic hook removed).
 */
function whoop_checkout_trust_strip() {
	static $rendered = false;

	if ( $rendered || ! function_exists( 'is_checkout' ) || ! is_checkout() ) {
		return;
	}

	$rendered = true;
	whoop_render_trust_row( 'whoop-checkout-trust-strip' );
}

/**
 * Free shipping progress on cart.
 */
function whoop_cart_free_shipping_bar() {
	return;

	if ( ! function_exists( 'is_cart' ) || ! is_cart() || ! WC()->cart || WC()->cart->is_empty() ) {
		return;
	}

	$threshold = whoop_free_shipping_threshold();
	if ( $threshold <= 0 ) {
		return;
	}

	$subtotal  = (float) WC()->cart->get_displayed_subtotal();
	$percent   = min( 100, max( 0, ( $subtotal / $threshold ) * 100 ) );
	$complete  = $subtotal >= $threshold;
	$remaining = max( 0, $threshold - $subtotal );

	$complete_msg  = whoop_wc_theme_mod( 'whoop_free_shipping_complete', __( 'You qualify for free shipping!', 'whoop-clone' ) );
	$remaining_tpl = whoop_wc_theme_mod( 'whoop_free_shipping_remaining', __( 'Add %s more for free shipping', 'whoop-clone' ) );

	$label = $complete
		? $complete_msg
		: sprintf( $remaining_tpl, wp_strip_all_tags( wc_price( $remaining ) ) );

	$class = 'whoop-shipping-progress' . ( $complete ? ' is-complete' : '' );
	?>
	<div class="<?php echo esc_attr( $class ); ?>" role="status">
		<div class="whoop-shipping-progress__label">
			<span><?php echo esc_html( $label ); ?></span>
			<span><?php echo esc_html( (string) (int) round( $percent ) ); ?>%</span>
		</div>
		<div class="whoop-shipping-progress__track" aria-hidden="true">
			<span class="whoop-shipping-progress__fill" style="width: <?php echo esc_attr( (string) $percent ); ?>%;"></span>
		</div>
	</div>
	<?php
}
add_action( 'woocommerce_before_main_content', 'whoop_cart_free_shipping_bar', 14 );
add_action( 'woocommerce_before_cart', 'whoop_cart_free_shipping_bar', 5 );

/**
 * Mobile sticky add-to-cart bar (markup; JS toggles visibility).
 */
function whoop_sticky_add_to_cart_bar() {
	if ( ! function_exists( 'is_product' ) || ! is_product() ) {
		return;
	}

	global $product;
	if ( ! $product instanceof WC_Product || ! $product->is_purchasable() ) {
		return;
	}

	$image_id  = $product->get_image_id();
	$image_url = $image_id ? wp_get_attachment_image_url( $image_id, 'woocommerce_thumbnail' ) : wc_placeholder_img_src();
	$title     = wp_strip_all_tags( $product->get_name() );
	?>
	<div class="whoop-sticky-atc" id="whoopStickyAtc" hidden aria-hidden="true">
		<div class="whoop-sticky-atc__inner">
			<img class="whoop-sticky-atc__media" src="<?php echo esc_url( $image_url ); ?>" alt="" width="48" height="48" loading="lazy" data-whoop-sticky-image />
			<div class="whoop-sticky-atc__meta">
				<div class="whoop-sticky-atc__title" data-whoop-sticky-title><?php echo esc_html( $title ); ?></div>
				<div class="whoop-sticky-atc__price" data-whoop-sticky-price><?php echo wp_kses_post( $product->get_price_html() ); ?></div>
			</div>
			<button type="button" class="whoop-sticky-atc__btn" data-whoop-sticky-submit>
				<?php echo esc_html( $product->single_add_to_cart_text() ); ?>
			</button>
		</div>
	</div>
	<?php
}
add_action( 'wp_footer', 'whoop_sticky_add_to_cart_bar', 25 );

/**
 * Mobile sticky proceed-to-checkout on cart.
 */
function whoop_cart_sticky_bar() {
	if ( ! function_exists( 'is_cart' ) || ! is_cart() || ! WC()->cart || WC()->cart->is_empty() ) {
		return;
	}

	$checkout_url = wc_get_checkout_url();
	$total        = WC()->cart->get_total();
	?>
	<div class="whoop-cart-sticky-bar" id="whoopCartStickyBar" hidden aria-hidden="true">
		<div class="whoop-cart-sticky-bar__inner">
			<div class="whoop-cart-sticky-bar__total">
				<small><?php echo esc_html( whoop_wc_theme_mod( 'whoop_cart_sticky_total_label', __( 'Toplam', 'whoop-clone' ) ) ); ?></small>
				<?php echo wp_kses_post( $total ); ?>
			</div>
			<a class="whoop-cart-sticky-bar__btn whoop-sticky-atc__btn" href="<?php echo esc_url( $checkout_url ); ?>">
				<?php echo esc_html( whoop_wc_theme_mod( 'whoop_cart_sticky_cta_text', __( 'Proceed to checkout', 'whoop-clone' ) ) ); ?>
			</a>
		</div>
	</div>
	<?php
}
add_action( 'wp_footer', 'whoop_cart_sticky_bar', 25 );

/**
 * Gallery thumbnail columns.
 *
 * @return int
 */
function whoop_product_thumbnail_columns() {
	return (int) apply_filters( 'whoop_product_thumbnail_columns', 5 );
}
add_filter( 'woocommerce_product_thumbnails_columns', 'whoop_product_thumbnail_columns' );

/**
 * Inject trust / shipping UI before block cart & checkout (page.php templates).
 *
 * @param string $content Block HTML.
 * @param array  $block   Block data.
 * @return string
 */
function whoop_prepend_wc_block_ui( $content, $block ) {
	if ( is_admin() || ! whoop_is_woocommerce_active() || empty( $block['blockName'] ) ) {
		return $content;
	}

	static $injected = array();

	if ( 'woocommerce/cart' === $block['blockName'] && function_exists( 'is_cart' ) && is_cart() && empty( $injected['cart'] ) ) {
		$injected['cart'] = true;
		ob_start();
		whoop_cart_free_shipping_bar();
		$prepend = ob_get_clean();
		return $prepend . $content;
	}

	return $content;
}
add_filter( 'render_block', 'whoop_prepend_wc_block_ui', 8, 2 );

/**
 * Normalize cart/checkout strings that Woo Blocks renders internally.
 *
 * @param string $translation Translated text.
 * @param string $text        Original text.
 * @param string $domain      Text domain.
 * @return string
 */
function whoop_filter_woocommerce_ui_strings( $translation, $text, $domain ) {
	if ( is_admin() || 'woocommerce' !== $domain ) {
		return $translation;
	}

	if ( ! function_exists( 'is_cart' ) || ! function_exists( 'is_checkout' ) ) {
		return $translation;
	}

	if ( ! is_cart() && ! is_checkout() ) {
		return $translation;
	}

	if ( in_array( $text, array( 'Estimated total', 'Tahmini toplam' ), true ) ) {
		return 'Toplam';
	}

	return $translation;
}
add_filter( 'gettext', 'whoop_filter_woocommerce_ui_strings', 20, 3 );

/*
 * Manual QA (responsive: 375px, 768px, 1280px):
 * - Shop archive grid, pagination, ordering.
 * - Single product: premium hero grid; no sidebar widgets; gallery, add to cart, tabs, ACF steps/note.
 * - Cart / Checkout: WooCommerce Blocks only; empty cart; coupon row on small screens.
 * - Checkout: guest vs logged-in; block order summary on mobile (order: -1).
 * - Cart/checkout: readable text on light bg; block layout full width; dark sidebar panels only.
 * - Payments: WooCommerce → Settings → Payments — at least one gateway enabled for checkout.
 * - My Account endpoints; wc-notices visibility.
 * Official reference: https://developer.files.wordpress.com/2017/12/woocommerce-theme-testing-checklist.pdf
 */
