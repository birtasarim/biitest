<?php
/**
 * Theme setup: supports, menus, image sizes.
 *
 * @package whoop-clone
 */

defined( 'ABSPATH' ) || exit;

/**
 * Register theme features.
 */
function whoop_theme_setup() {
	// Title tag handled by WP.
	add_theme_support( 'title-tag' );

	// Featured images.
	add_theme_support( 'post-thumbnails' );

	// HTML5 markup for core elements.
	add_theme_support(
		'html5',
		array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' )
	);

	// Custom logo.
	add_theme_support(
		'custom-logo',
		array(
			'height'      => 72,
			'width'       => 240,
			'flex-height' => true,
			'flex-width'  => true,
		)
	);

	// Wide & full block alignments.
	add_theme_support( 'align-wide' );

	// Editor styles in Gutenberg match the front end.
	add_theme_support( 'editor-styles' );
	add_editor_style( 'style.css' );

	// Responsive embeds.
	add_theme_support( 'responsive-embeds' );

	// WooCommerce — image widths & catalog grid defaults (Customizer can still adjust).
	add_theme_support(
		'woocommerce',
		array(
			'thumbnail_image_width' => 480,
			'single_image_width'    => 800,
			'product_grid'          => array(
				'default_rows'    => 4,
				'min_rows'        => 2,
				'max_rows'        => 9,
				'default_columns' => 2,
				'min_columns'     => 1,
				'max_columns'     => 4,
			),
		)
	);
	add_theme_support( 'wc-product-gallery-zoom' );
	add_theme_support( 'wc-product-gallery-lightbox' );
	add_theme_support( 'wc-product-gallery-slider' );

	// Nav menu locations.
	register_nav_menus(
		array(
			'primary' => __( 'Primary Navigation', 'whoop-clone' ),
			'footer-shop'    => __( 'Footer — Shop', 'whoop-clone' ),
			'footer-company' => __( 'Footer — Company', 'whoop-clone' ),
			'footer-support' => __( 'Footer — Support', 'whoop-clone' ),
			'footer-legal'   => __( 'Footer — Legal', 'whoop-clone' ),
		)
	);

	// Custom image sizes used inside blocks.
	add_image_size( 'whoop-card', 800, 1067, true );           // 3:4 feature card
	add_image_size( 'whoop-wide', 1920, 820, true );           // wear-daily strip
	add_image_size( 'whoop-portrait', 900, 1200, true );       // athlete cards
	add_image_size( 'whoop-square', 1200, 1200, true );        // showcase, principles
	add_image_size( 'whoop-modal', 1600, 0, false );           // person modal full
}
add_action( 'after_setup_theme', 'whoop_theme_setup' );

/**
 * Add named image sizes to the editor's image-size dropdown.
 */
function whoop_image_size_names( $sizes ) {
	return array_merge(
		$sizes,
		array(
			'whoop-card'     => __( 'Card 3:4', 'whoop-clone' ),
			'whoop-wide'     => __( 'Wide strip', 'whoop-clone' ),
			'whoop-portrait' => __( 'Portrait', 'whoop-clone' ),
			'whoop-square'   => __( 'Square', 'whoop-clone' ),
			'whoop-modal'    => __( 'Modal full', 'whoop-clone' ),
		)
	);
}
add_filter( 'image_size_names_choose', 'whoop_image_size_names' );

/**
 * Return structured fallback items for the primary navigation.
 */
function whoop_primary_menu_fallback_items() {
	return array(
		array(
			'label'    => __( 'Memberships', 'whoop-clone' ),
			'url'      => '#memberships',
			'children' => array(
				array(
					'label' => __( 'Explore all memberships', 'whoop-clone' ),
					'url'   => '#memberships',
				),
				array(
					'label' => __( 'Gifts', 'whoop-clone' ),
					'url'   => '#gift',
				),
				array(
					'label' => __( 'One month free trial', 'whoop-clone' ),
					'url'   => '#trial',
				),
				array(
					'label' => __( 'Family plans', 'whoop-clone' ),
					'url'   => '#memberships',
				),
				array(
					'label' => __( 'Upgrade to 5.0/MG', 'whoop-clone' ),
					'url'   => '#labs',
				),
			),
		),
		array(
			'label' => __( 'How it works', 'whoop-clone' ),
			'url'   => '#features',
		),
		array(
			'label' => __( 'Why us', 'whoop-clone' ),
			'url'   => '#why',
		),
		array(
			'label' => __( 'Accessories', 'whoop-clone' ),
			'url'   => '#showcase',
		),
		array(
			'label' => __( 'Trial', 'whoop-clone' ),
			'url'   => '#trial',
		),
		array(
			'label' => __( 'Advanced Labs', 'whoop-clone' ),
			'url'   => '#labs',
		),
	);
}

/**
 * Render fallback when no menu is set on the primary location.
 */
function whoop_primary_menu_fallback( $menu_class = 'nav-links' ) {
	$items = whoop_primary_menu_fallback_items();

	printf( '<ul class="%s">', esc_attr( $menu_class ) );
	foreach ( $items as $item ) {
		$has_children = ! empty( $item['children'] ) && is_array( $item['children'] );
		printf( '<li%s>', $has_children ? ' class="menu-item-has-children"' : '' );
		printf(
			'<a class="nav-link" href="%s">%s</a>',
			esc_url( $item['url'] ?? '#' ),
			esc_html( $item['label'] ?? '' )
		);

		if ( $has_children ) {
			echo '<ul class="sub-menu">';
			foreach ( $item['children'] as $child ) {
				printf(
					'<li><a href="%s">%s</a></li>',
					esc_url( $child['url'] ?? '#' ),
					esc_html( $child['label'] ?? '' )
				);
			}
			echo '</ul>';
		}

		echo '</li>';
	}
	echo '</ul>';
}

/**
 * Add the .nav-link class to every <a> in the primary nav menu output.
 */
function whoop_nav_menu_link_attributes( $atts, $item, $args ) {
	if ( isset( $args->theme_location ) && 'primary' === $args->theme_location && empty( $atts['class'] ) ) {
		$atts['class'] = 'nav-link';
	}
	return $atts;
}
add_filter( 'nav_menu_link_attributes', 'whoop_nav_menu_link_attributes', 10, 3 );

/**
 * Pingback header for posts.
 */
function whoop_pingback_header() {
	if ( is_singular() && pings_open() ) {
		printf( '<link rel="pingback" href="%s">', esc_url( get_bloginfo( 'pingback_url' ) ) );
	}
}
add_action( 'wp_head', 'whoop_pingback_header' );
