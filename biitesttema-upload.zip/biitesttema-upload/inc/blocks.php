<?php
/**
 * Auto-register every ACF block under /template-parts/blocks/
 * Each block lives in its own folder with a block.json + render template.
 *
 * Block JSON convention:
 *   "name": "whoop/<block-id>"
 *   "acf": { "renderTemplate": "<block-id>.php" }
 *
 * @package whoop-clone
 */

defined( 'ABSPATH' ) || exit;

/**
 * Register all theme blocks.
 *
 * Uses register_block_type() against each block's directory; WP reads block.json.
 * Falls back gracefully if ACF isn't active (admin sees a notice but the front-end
 * still renders any block that has been published).
 */
function whoop_register_blocks() {
	$blocks_dir = WHOOP_THEME_DIR . '/template-parts/blocks';
	if ( ! is_dir( $blocks_dir ) ) {
		return;
	}

	foreach ( glob( $blocks_dir . '/*', GLOB_ONLYDIR ) as $block_path ) {
		if ( file_exists( $block_path . '/block.json' ) ) {
			register_block_type( $block_path );
		}
	}
}
add_action( 'init', 'whoop_register_blocks' );

/**
 * Show an admin notice if ACF Pro isn't active.
 */
function whoop_acf_admin_notice() {
	if ( function_exists( 'acf_register_block_type' ) || class_exists( 'ACF' ) ) {
		return;
	}
	?>
	<div class="notice notice-warning">
		<p>
			<strong>WHOOP Clone:</strong>
			<?php esc_html_e( 'Advanced Custom Fields Pro is required for the editor experience. Without it, blocks can still render but cannot be edited.', 'whoop-clone' ); ?>
		</p>
	</div>
	<?php
}
add_action( 'admin_notices', 'whoop_acf_admin_notice' );

/**
 * Add a custom "WHOOP" block category so all theme blocks appear together.
 */
function whoop_block_category( $categories ) {
	return array_merge(
		array(
			array(
				'slug'  => 'whoop',
				'title' => __( 'WHOOP', 'whoop-clone' ),
				'icon'  => 'heart',
			),
		),
		$categories
	);
}
add_filter( 'block_categories_all', 'whoop_block_category', 10, 1 );

/**
 * Helper used inside block render templates to resolve image arrays from ACF.
 *
 * @param mixed  $image ACF image field — may be an ID, URL, or array depending on return format.
 * @param string $size  Image size to fetch.
 * @return string Image URL or empty string.
 */
function whoop_image_src( $image, $size = 'full' ) {
	if ( empty( $image ) ) {
		return '';
	}
	if ( is_numeric( $image ) ) {
		$src = wp_get_attachment_image_src( (int) $image, $size );
		return $src ? $src[0] : '';
	}
	if ( is_array( $image ) ) {
		if ( ! empty( $image['sizes'][ $size ] ) ) {
			return $image['sizes'][ $size ];
		}
		return $image['url'] ?? '';
	}
	if ( is_string( $image ) ) {
		return $image;
	}
	return '';
}

/**
 * Helper: render an alt attribute from an ACF image array, with sensible fallback.
 *
 * @param mixed  $image ACF image.
 * @param string $fallback Fallback alt text.
 * @return string Escaped alt text.
 */
function whoop_image_alt( $image, $fallback = '' ) {
	if ( is_array( $image ) && ! empty( $image['alt'] ) ) {
		return $image['alt'];
	}
	if ( is_numeric( $image ) ) {
		$alt = get_post_meta( (int) $image, '_wp_attachment_image_alt', true );
		if ( ! empty( $alt ) ) {
			return $alt;
		}
	}
	return $fallback;
}

/**
 * Keep current fallback block context for JSON demo data.
 *
 * @param string $block_slug Block slug without path, e.g. "hero".
 */
function whoop_set_fallback_block_context( $block_slug ) {
	$GLOBALS['whoop_fallback_block_context'] = sanitize_key( (string) $block_slug );
}

/**
 * Get current fallback block context.
 *
 * @return string
 */
function whoop_get_fallback_block_context() {
	return isset( $GLOBALS['whoop_fallback_block_context'] ) ? (string) $GLOBALS['whoop_fallback_block_context'] : '';
}

/**
 * Read JSON demo homepage data.
 *
 * @return array
 */
function whoop_get_demo_homepage_data() {
	static $data = null;
	if ( null !== $data ) {
		return $data;
	}

	$data_path = WHOOP_THEME_DIR . '/data/demo-homepage.json';
	if ( ! file_exists( $data_path ) ) {
		$data = array();
		return $data;
	}

	$raw  = file_get_contents( $data_path );
	$json = $raw ? json_decode( $raw, true ) : array();
	$data = is_array( $json ) ? $json : array();
	return $data;
}

/**
 * Provide JSON fallback values to ACF when a field is empty.
 *
 * This only applies while rendering front-page fallback templates where
 * whoop_set_fallback_block_context() has set a current block slug.
 *
 * @param mixed       $value   Current ACF value.
 * @param string|int  $post_id Current post id.
 * @param array       $field   ACF field schema.
 * @return mixed
 */
function whoop_acf_demo_fallback_value( $value, $post_id, $field ) {
	if ( ! empty( $value ) ) {
		return $value;
	}

	$block_slug = whoop_get_fallback_block_context();
	if ( '' === $block_slug ) {
		return $value;
	}

	$field_name = isset( $field['name'] ) ? (string) $field['name'] : '';
	if ( '' === $field_name ) {
		return $value;
	}

	$demo_data = whoop_get_demo_homepage_data();
	if ( empty( $demo_data[ $block_slug ] ) || ! is_array( $demo_data[ $block_slug ] ) ) {
		return $value;
	}

	if ( array_key_exists( $field_name, $demo_data[ $block_slug ] ) ) {
		return $demo_data[ $block_slug ][ $field_name ];
	}

	return $value;
}
add_filter( 'acf/load_value', 'whoop_acf_demo_fallback_value', 20, 3 );

/**
 * Read a field value from demo JSON during fallback rendering.
 *
 * Falls back to ACF get_field() when no JSON value is available.
 *
 * @param string $field_name Field name.
 * @param mixed  $default    Default value if nothing is found.
 * @return mixed
 */
function whoop_field( $field_name, $default = '' ) {
	$block_slug = whoop_get_fallback_block_context();
	if ( '' !== $block_slug ) {
		$demo_data = whoop_get_demo_homepage_data();
		if ( ! empty( $demo_data[ $block_slug ] ) && array_key_exists( $field_name, $demo_data[ $block_slug ] ) ) {
			return $demo_data[ $block_slug ][ $field_name ];
		}
	}

	if ( function_exists( 'get_field' ) ) {
		$value = get_field( $field_name );
		return null === $value ? $default : $value;
	}

	return $default;
}

/**
 * Build an inline style string for custom section spacing.
 *
 * Reads section_spacing_top / section_spacing_bottom ACF fields.
 * Returns a ready-to-use style="..." attribute (or empty string).
 */
function whoop_section_spacing_style() {
	$top    = whoop_field( 'section_spacing_top' );
	$bottom = whoop_field( 'section_spacing_bottom' );
	$parts  = array();

	if ( '' !== $top && null !== $top && false !== $top ) {
		$parts[] = 'padding-top:' . intval( $top ) . 'px !important';
	}
	if ( '' !== $bottom && null !== $bottom && false !== $bottom ) {
		$parts[] = 'padding-bottom:' . intval( $bottom ) . 'px !important';
	}

	return $parts ? ' style="' . esc_attr( implode( ';', $parts ) ) . '"' : '';
}

/**
 * Render the report preview modal in wp_footer so it sits outside
 * all block wrappers and stacking contexts.
 */
function whoop_render_report_modal() {
	?>
	<div class="report-modal" id="reportModal" aria-hidden="true">
		<div class="report-modal-card">
			<div class="report-modal-toolbar">
				<h3 class="report-modal-title" id="reportModalTitle"></h3>
				<div class="report-modal-actions">
					<a class="report-modal-open" id="reportModalOpen" href="#" target="_blank" rel="noopener noreferrer">
						<span aria-hidden="true">↗</span>
						<span><?php esc_html_e( 'Yeni sekmede aç', 'whoop-clone' ); ?></span>
					</a>
					<button class="report-modal-close" id="reportModalClose" type="button" aria-label="<?php esc_attr_e( 'Close', 'whoop-clone' ); ?>">
						<svg viewBox="0 0 16 16" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M3 3l10 10M13 3L3 13"/></svg>
					</button>
				</div>
			</div>
			<div class="report-modal-frame-wrap">
				<iframe class="report-modal-frame" id="reportModalFrame" src="" title="<?php esc_attr_e( 'Report preview', 'whoop-clone' ); ?>"></iframe>
			</div>
		</div>
	</div>
	<?php
}
