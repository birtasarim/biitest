<?php
/**
 * ACF field groups for every block.
 *
 * All field groups are PHP-registered so they live in version control.
 * Each group is bound to its corresponding block via location rules.
 *
 * @package whoop-clone
 */

defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'acf_add_local_field_group' ) ) {
	return; // ACF not active.
}

/**
 * Register all field groups on init (after ACF has loaded).
 */
function whoop_register_acf_field_groups() {

	/* ============================================================
	 * HERO
	 * ============================================================ */
	acf_add_local_field_group(
		array(
			'key'      => 'group_whoop_hero',
			'title'    => 'Hero',
			'fields'   => array(
				array( 'key' => 'field_hero_headline', 'label' => 'Headline', 'name' => 'headline', 'type' => 'textarea', 'rows' => 2 ),
				array( 'key' => 'field_hero_subline', 'label' => 'Subline', 'name' => 'subline', 'type' => 'textarea', 'rows' => 3 ),
				array( 'key' => 'field_hero_video_file', 'label' => 'Uploaded Video File (Desktop)', 'name' => 'video_file', 'type' => 'file', 'return_format' => 'array', 'mime_types' => 'mp4,webm,mov', 'instructions' => 'Desktop video — 1920×1080 (16:9 yatay)' ),
				array( 'key' => 'field_hero_video_file_mobile', 'label' => 'Uploaded Video File (Mobile)', 'name' => 'video_file_mobile', 'type' => 'file', 'return_format' => 'array', 'mime_types' => 'mp4,webm,mov', 'instructions' => 'Mobil video — 1080×1920 (9:16 dikey). Boş bırakılırsa desktop video kullanılır.' ),
				array( 'key' => 'field_hero_video', 'label' => 'Video URL (.mp4 or YouTube)', 'name' => 'video_url', 'type' => 'url' ),
				array( 'key' => 'field_hero_poster', 'label' => 'Poster Image (fallback)', 'name' => 'poster_image', 'type' => 'image', 'return_format' => 'array', 'preview_size' => 'medium' ),
				array( 'key' => 'field_hero_cta1_text', 'label' => 'Primary CTA Text', 'name' => 'cta_primary_text', 'type' => 'text' ),
				array( 'key' => 'field_hero_cta1_url', 'label' => 'Primary CTA URL', 'name' => 'cta_primary_url', 'type' => 'url' ),
				array( 'key' => 'field_hero_cta2_text', 'label' => 'Secondary CTA Text', 'name' => 'cta_secondary_text', 'type' => 'text' ),
				array( 'key' => 'field_hero_cta2_url', 'label' => 'Secondary CTA URL', 'name' => 'cta_secondary_url', 'type' => 'url' ),
			),
			'location' => array( array( array( 'param' => 'block', 'operator' => '==', 'value' => 'whoop/hero' ) ) ),
		)
	);

	/* ============================================================
	 * DAILY (Get started + Wear daily)
	 * ============================================================ */
	acf_add_local_field_group(
		array(
			'key'      => 'group_whoop_daily',
			'title'    => 'Daily — Get Started + Wear Daily',
			'fields'   => array(
				array( 'key' => 'field_daily_gs_label', 'label' => 'Get Started Card', 'name' => '', 'type' => 'message', 'message' => '<strong>Top card</strong> — small image + headline + CTA.' ),
				array( 'key' => 'field_daily_gs_image', 'label' => 'Image', 'name' => 'gs_image', 'type' => 'image', 'return_format' => 'array' ),
				array( 'key' => 'field_daily_gs_title', 'label' => 'Title', 'name' => 'gs_title', 'type' => 'text' ),
				array( 'key' => 'field_daily_gs_text', 'label' => 'Text', 'name' => 'gs_text', 'type' => 'textarea', 'rows' => 3 ),
				array( 'key' => 'field_daily_gs_cta_text', 'label' => 'CTA Text', 'name' => 'gs_cta_text', 'type' => 'text' ),
				array( 'key' => 'field_daily_gs_cta_url', 'label' => 'CTA URL', 'name' => 'gs_cta_url', 'type' => 'url' ),

				array( 'key' => 'field_daily_wd_label', 'label' => 'Wear Daily', 'name' => '', 'type' => 'message', 'message' => '<strong>Big section</strong> below the card.' ),
				array( 'key' => 'field_daily_wd_title', 'label' => 'Headline', 'name' => 'wd_title', 'type' => 'textarea', 'rows' => 2 ),
				array( 'key' => 'field_daily_wd_text', 'label' => 'Subline', 'name' => 'wd_text', 'type' => 'textarea', 'rows' => 3 ),
				array( 'key' => 'field_daily_wd_image', 'label' => 'Wide Image', 'name' => 'wd_image', 'type' => 'image', 'return_format' => 'array' ),
				array( 'key' => 'field_daily_wd_badge_value', 'label' => 'Badge Value', 'name' => 'wd_badge_value', 'type' => 'text', 'placeholder' => '29.9' ),
				array( 'key' => 'field_daily_wd_badge_label', 'label' => 'Badge Label', 'name' => 'wd_badge_label', 'type' => 'text', 'placeholder' => 'WHOOP AGE' ),
			),
			'location' => array( array( array( 'param' => 'block', 'operator' => '==', 'value' => 'whoop/daily' ) ) ),
		)
	);

	/* ============================================================
	 * FEATURES SLIDER
	 * ============================================================ */
	acf_add_local_field_group(
		array(
			'key'      => 'group_whoop_features',
			'title'    => 'Features Slider',
			'fields'   => array(
				array( 'key' => 'field_feat_headline', 'label' => 'Headline', 'name' => 'headline', 'type' => 'textarea', 'rows' => 2 ),
				array( 'key' => 'field_feat_subline', 'label' => 'Subline', 'name' => 'subline', 'type' => 'textarea', 'rows' => 3 ),
				array(
					'key'        => 'field_feat_features',
					'label'      => 'Feature Cards',
					'name'       => 'features',
					'type'       => 'repeater',
					'min'        => 1,
					'layout'     => 'block',
					'button_label' => 'Add Feature',
					'sub_fields' => array(
						array( 'key' => 'field_feat_card_image', 'label' => 'Card Image', 'name' => 'card_image', 'type' => 'image', 'return_format' => 'array' ),
						array( 'key' => 'field_feat_card_title', 'label' => 'Card Title', 'name' => 'card_title', 'type' => 'text' ),
						array( 'key' => 'field_feat_tiers', 'label' => 'Available On', 'name' => 'tiers', 'type' => 'text', 'placeholder' => 'PEAK | LIFE' ),
						array( 'key' => 'field_feat_modal_title', 'label' => 'Modal Title', 'name' => 'modal_title', 'type' => 'text' ),
						array( 'key' => 'field_feat_modal_desc', 'label' => 'Modal Description', 'name' => 'modal_description', 'type' => 'textarea', 'rows' => 4 ),
						array( 'key' => 'field_feat_modal_image', 'label' => 'Modal Image', 'name' => 'modal_image', 'type' => 'image', 'return_format' => 'array', 'instructions' => 'Optional. Defaults to the card image.' ),
						array( 'key' => 'field_feat_quote', 'label' => 'Member Quote', 'name' => 'quote', 'type' => 'textarea', 'rows' => 3 ),
					),
				),
			),
			'location' => array( array( array( 'param' => 'block', 'operator' => '==', 'value' => 'whoop/features-slider' ) ) ),
		)
	);

	/* ============================================================
	 * MEMBERSHIPS
	 * ============================================================ */
	acf_add_local_field_group(
		array(
			'key'      => 'group_whoop_memberships',
			'title'    => 'Memberships',
			'fields'   => array(
				array( 'key' => 'field_mem_headline', 'label' => 'Headline', 'name' => 'headline', 'type' => 'text', 'default_value' => 'Choose a membership' ),
				array(
					'key'        => 'field_mem_tiers',
					'label'      => 'Tiers',
					'name'       => 'tiers',
					'type'       => 'repeater',
					'min'        => 1,
					'max'        => 2,
					'layout'     => 'block',
					'button_label' => 'Add Tier',
					'sub_fields' => array(
						array( 'key' => 'field_mem_slug', 'label' => 'Slug (one / peak / life)', 'name' => 'tier_slug', 'type' => 'text', 'instructions' => 'Used to apply the gradient color. Use: one, peak, or life.' ),
						array( 'key' => 'field_mem_tab_label', 'label' => 'Tab Label', 'name' => 'tier_tab_label', 'type' => 'text', 'instructions' => 'Short tab label shown above the product card.' ),
						array( 'key' => 'field_mem_name', 'label' => 'Tier Name', 'name' => 'tier_name', 'type' => 'text' ),
						array( 'key' => 'field_mem_rating', 'label' => 'Rating Text', 'name' => 'tier_rating_text', 'type' => 'text', 'placeholder' => '4.7 (176 değerlendirme)' ),
						array( 'key' => 'field_mem_price', 'label' => 'Price Line', 'name' => 'tier_price', 'type' => 'text', 'placeholder' => 'Starts at $199/yr' ),
						array( 'key' => 'field_mem_compare_price', 'label' => 'Compare Price', 'name' => 'tier_compare_price', 'type' => 'text', 'placeholder' => '₺4.990' ),
						array( 'key' => 'field_mem_image', 'label' => 'Product Image', 'name' => 'tier_image', 'type' => 'image', 'return_format' => 'array' ),
						array( 'key' => 'field_mem_colors', 'label' => 'Color count text', 'name' => 'tier_colors_text', 'type' => 'text', 'placeholder' => '+14' ),
						array( 'key' => 'field_mem_intro', 'label' => 'Features Intro Line', 'name' => 'features_intro', 'type' => 'text', 'instructions' => 'Optional, e.g. "Everything on WHOOP One, plus".' ),
						array(
							'key'        => 'field_mem_certs',
							'label'      => 'ISO Certificates',
							'name'       => 'certificates',
							'type'       => 'repeater',
							'layout'     => 'table',
							'button_label' => 'Add Certificate',
							'sub_fields' => array(
								array( 'key' => 'field_mem_cert_image', 'label' => 'Certificate Image', 'name' => 'image', 'type' => 'image', 'return_format' => 'array' ),
							),
						),
						array(
							'key'        => 'field_mem_features',
							'label'      => 'Feature List',
							'name'       => 'features',
							'type'       => 'repeater',
							'layout'     => 'table',
							'button_label' => 'Add Item',
							'sub_fields' => array(
								array( 'key' => 'field_mem_feature_text', 'label' => 'Text', 'name' => 'text', 'type' => 'text' ),
							),
						),
						array( 'key' => 'field_mem_cta1_text', 'label' => 'Primary Button Text', 'name' => 'cta_primary_text', 'type' => 'text' ),
						array( 'key' => 'field_mem_cta1_url', 'label' => 'Primary Button URL', 'name' => 'cta_primary_url', 'type' => 'url' ),
						array( 'key' => 'field_mem_cta2_text', 'label' => 'Secondary Button Text', 'name' => 'cta_secondary_text', 'type' => 'text', 'default_value' => 'Report example' ),
						array( 'key' => 'field_mem_cta2_url', 'label' => 'Secondary Button URL', 'name' => 'cta_secondary_url', 'type' => 'url' ),
						array( 'key' => 'field_mem_trust_strip_text', 'label' => 'Trust Strip Text', 'name' => 'trust_strip_text', 'type' => 'text', 'placeholder' => 'Bugün sipariş ver, hızlı kargo avantajını yakala' ),
					),
				),
				array( 'key' => 'field_mem_footnote', 'label' => 'Footnote', 'name' => 'footnote', 'type' => 'text', 'placeholder' => 'Pay with HSA/FSA Card | Additional medical information below.' ),
			),
			'location' => array( array( array( 'param' => 'block', 'operator' => '==', 'value' => 'whoop/memberships' ) ) ),
		)
	);

	/* ============================================================
	 * GIFT
	 * ============================================================ */
	acf_add_local_field_group(
		array(
			'key'      => 'group_whoop_gift',
			'title'    => 'Gift Banner',
			'fields'   => array(
				array( 'key' => 'field_gift_image', 'label' => 'Image', 'name' => 'gift_image', 'type' => 'image', 'return_format' => 'array' ),
				array( 'key' => 'field_gift_title', 'label' => 'Title', 'name' => 'gift_title', 'type' => 'text' ),
				array( 'key' => 'field_gift_text', 'label' => 'Text', 'name' => 'gift_text', 'type' => 'textarea', 'rows' => 3 ),
				array( 'key' => 'field_gift_cta_text', 'label' => 'CTA Text', 'name' => 'gift_cta_text', 'type' => 'text', 'default_value' => 'Gift WHOOP' ),
				array( 'key' => 'field_gift_cta_url', 'label' => 'CTA URL', 'name' => 'gift_cta_url', 'type' => 'url' ),
			),
			'location' => array( array( array( 'param' => 'block', 'operator' => '==', 'value' => 'whoop/gift' ) ) ),
		)
	);

	/* ============================================================
	 * SOCIAL PROOF
	 * ============================================================ */
	acf_add_local_field_group(
		array(
			'key'      => 'group_whoop_social',
			'title'    => 'Social Proof',
			'fields'   => array(
				array( 'key' => 'field_sp_headline', 'label' => 'Headline', 'name' => 'headline', 'type' => 'text' ),
				array( 'key' => 'field_sp_subline', 'label' => 'Subline', 'name' => 'subline', 'type' => 'textarea', 'rows' => 3 ),
				array(
					'key'        => 'field_sp_items',
					'label'      => 'Items (Athletes & Quotes)',
					'name'       => 'items',
					'type'       => 'repeater',
					'layout'     => 'block',
					'button_label' => 'Add Item',
					'sub_fields' => array(
						array(
							'key'           => 'field_sp_type',
							'label'         => 'Item Type',
							'name'          => 'item_type',
							'type'          => 'radio',
							'choices'       => array( 'image' => 'Athlete (image card)', 'quote' => 'Member quote' ),
							'default_value' => 'image',
							'layout'        => 'horizontal',
						),
						array(
							'key'           => 'field_sp_size',
							'label'         => 'Card Size',
							'name'          => 'layout_size',
							'type'          => 'select',
							'choices'       => array(
								'default' => 'Default (1 column / 1 row)',
								'large'   => 'Large (1 col / 2 rows)',
								'wide'    => 'Wide (2 cols / 1 row)',
							),
							'default_value' => 'default',
						),
						array( 'key' => 'field_sp_video', 'label' => 'Has Video?', 'name' => 'has_video', 'type' => 'true_false', 'ui' => 1, 'conditional_logic' => array( array( array( 'field' => 'field_sp_type', 'operator' => '==', 'value' => 'image' ) ) ) ),
						array( 'key' => 'field_sp_video_url', 'label' => 'Video URL (.mp4 or YouTube)', 'name' => 'video_url', 'type' => 'url', 'conditional_logic' => array( array( array( 'field' => 'field_sp_type', 'operator' => '==', 'value' => 'image' ), array( 'field' => 'field_sp_video', 'operator' => '==', 'value' => '1' ) ) ) ),

						array( 'key' => 'field_sp_person_img', 'label' => 'Person Image', 'name' => 'person_image', 'type' => 'image', 'return_format' => 'array', 'conditional_logic' => array( array( array( 'field' => 'field_sp_type', 'operator' => '==', 'value' => 'image' ), array( 'field' => 'field_sp_video', 'operator' => '!=', 'value' => '1' ) ) ) ),
						array( 'key' => 'field_sp_person_name', 'label' => 'Person Name', 'name' => 'person_name', 'type' => 'text', 'conditional_logic' => array( array( array( 'field' => 'field_sp_type', 'operator' => '==', 'value' => 'image' ) ) ) ),
						array( 'key' => 'field_sp_person_role', 'label' => 'Person Role', 'name' => 'person_role', 'type' => 'text', 'conditional_logic' => array( array( array( 'field' => 'field_sp_type', 'operator' => '==', 'value' => 'image' ) ) ) ),

						array( 'key' => 'field_sp_quote_text', 'label' => 'Quote', 'name' => 'quote_text', 'type' => 'textarea', 'rows' => 3, 'conditional_logic' => array( array( array( 'field' => 'field_sp_type', 'operator' => '==', 'value' => 'quote' ) ) ) ),
						array( 'key' => 'field_sp_quote_name', 'label' => 'Member Name', 'name' => 'quote_name', 'type' => 'text', 'conditional_logic' => array( array( array( 'field' => 'field_sp_type', 'operator' => '==', 'value' => 'quote' ) ) ) ),
						array( 'key' => 'field_sp_quote_role', 'label' => 'Member Role', 'name' => 'quote_role', 'type' => 'text', 'default_value' => 'WHOOP member', 'conditional_logic' => array( array( array( 'field' => 'field_sp_type', 'operator' => '==', 'value' => 'quote' ) ) ) ),
					),
				),
			),
			'location' => array( array( array( 'param' => 'block', 'operator' => '==', 'value' => 'whoop/social-proof' ) ) ),
		)
	);

	/* ============================================================
	 * PRODUCT DETAILS PAGE
	 * ============================================================ */
	acf_add_local_field_group(
		array(
			'key'      => 'group_whoop_product_details_page',
			'title'    => 'Product Details Page',
			'fields'   => array(
				array(
					'key'     => 'field_product_details_hero_tab',
					'label'   => 'Hero',
					'name'    => '',
					'type'    => 'tab',
					'placement' => 'top',
				),
				array( 'key' => 'field_pd_hero_headline', 'label' => 'Hero Headline', 'name' => 'pd_hero_headline', 'type' => 'textarea', 'rows' => 3 ),
				array( 'key' => 'field_pd_hero_subline', 'label' => 'Hero Subline', 'name' => 'pd_hero_subline', 'type' => 'textarea', 'rows' => 4 ),
				array( 'key' => 'field_pd_hero_image', 'label' => 'Hero Image', 'name' => 'pd_hero_image', 'type' => 'image', 'return_format' => 'array', 'preview_size' => 'large' ),
				array( 'key' => 'field_pd_hero_cta1_text', 'label' => 'Primary CTA Text', 'name' => 'pd_hero_cta_primary_text', 'type' => 'text' ),
				array( 'key' => 'field_pd_hero_cta1_url', 'label' => 'Primary CTA URL', 'name' => 'pd_hero_cta_primary_url', 'type' => 'url' ),
				array( 'key' => 'field_pd_hero_cta2_text', 'label' => 'Secondary CTA Text', 'name' => 'pd_hero_cta_secondary_text', 'type' => 'text' ),
				array( 'key' => 'field_pd_hero_cta2_url', 'label' => 'Secondary CTA URL', 'name' => 'pd_hero_cta_secondary_url', 'type' => 'url' ),

				array(
					'key'     => 'field_product_details_intro_tab',
					'label'   => 'Intro',
					'name'    => '',
					'type'    => 'tab',
					'placement' => 'top',
				),
				array( 'key' => 'field_pd_intro_eyebrow', 'label' => 'Intro Eyebrow', 'name' => 'pd_intro_eyebrow', 'type' => 'text' ),
				array( 'key' => 'field_pd_intro_headline', 'label' => 'Intro Headline', 'name' => 'pd_intro_headline', 'type' => 'textarea', 'rows' => 3 ),
				array( 'key' => 'field_pd_intro_text', 'label' => 'Intro Text', 'name' => 'pd_intro_text', 'type' => 'textarea', 'rows' => 5 ),
				array( 'key' => 'field_pd_intro_image', 'label' => 'Intro Image', 'name' => 'pd_intro_image', 'type' => 'image', 'return_format' => 'array', 'preview_size' => 'large' ),
				array(
					'key'          => 'field_pd_intro_cards',
					'label'        => 'Intro Cards',
					'name'         => 'pd_intro_cards',
					'type'         => 'repeater',
					'layout'       => 'block',
					'button_label' => 'Add Intro Card',
					'sub_fields'   => array(
						array( 'key' => 'field_pd_intro_card_title', 'label' => 'Title', 'name' => 'title', 'type' => 'text' ),
						array( 'key' => 'field_pd_intro_card_text', 'label' => 'Text', 'name' => 'text', 'type' => 'textarea', 'rows' => 3 ),
					),
				),

				array(
					'key'     => 'field_product_details_offer_tab',
					'label'   => 'Included / Offer',
					'name'    => '',
					'type'    => 'tab',
					'placement' => 'top',
				),
				array( 'key' => 'field_pd_offer_eyebrow', 'label' => 'Offer Eyebrow', 'name' => 'pd_offer_eyebrow', 'type' => 'text' ),
				array( 'key' => 'field_pd_offer_headline', 'label' => 'Offer Headline', 'name' => 'pd_offer_headline', 'type' => 'textarea', 'rows' => 3 ),
				array( 'key' => 'field_pd_offer_text', 'label' => 'Offer Text', 'name' => 'pd_offer_text', 'type' => 'textarea', 'rows' => 4 ),
				array(
					'key'          => 'field_pd_offer_items',
					'label'        => 'Offer Items',
					'name'         => 'pd_offer_items',
					'type'         => 'repeater',
					'layout'       => 'block',
					'button_label' => 'Add Offer Item',
					'sub_fields'   => array(
						array( 'key' => 'field_pd_offer_item_label', 'label' => 'Label', 'name' => 'label', 'type' => 'text', 'instructions' => 'Short kicker, optional.' ),
						array( 'key' => 'field_pd_offer_item_title', 'label' => 'Title', 'name' => 'title', 'type' => 'text' ),
						array( 'key' => 'field_pd_offer_item_text', 'label' => 'Text', 'name' => 'text', 'type' => 'textarea', 'rows' => 3 ),
					),
				),

				array(
					'key'     => 'field_product_details_features_tab',
					'label'   => 'Feature Sections',
					'name'    => '',
					'type'    => 'tab',
					'placement' => 'top',
				),
				array(
					'key'          => 'field_pd_feature_sections',
					'label'        => 'Feature Sections',
					'name'         => 'pd_feature_sections',
					'type'         => 'repeater',
					'layout'       => 'block',
					'button_label' => 'Add Feature Section',
					'sub_fields'   => array(
						array( 'key' => 'field_pd_feature_eyebrow', 'label' => 'Eyebrow', 'name' => 'eyebrow', 'type' => 'text' ),
						array( 'key' => 'field_pd_feature_headline', 'label' => 'Headline', 'name' => 'headline', 'type' => 'textarea', 'rows' => 3 ),
						array( 'key' => 'field_pd_feature_text', 'label' => 'Body Text', 'name' => 'text', 'type' => 'textarea', 'rows' => 5 ),
						array( 'key' => 'field_pd_feature_image', 'label' => 'Image', 'name' => 'image', 'type' => 'image', 'return_format' => 'array', 'preview_size' => 'large' ),
						array(
							'key'          => 'field_pd_feature_points',
							'label'        => 'Points',
							'name'         => 'points',
							'type'         => 'repeater',
							'layout'       => 'table',
							'button_label' => 'Add Point',
							'sub_fields'   => array(
								array( 'key' => 'field_pd_feature_point_text', 'label' => 'Text', 'name' => 'text', 'type' => 'text' ),
							),
						),
						array( 'key' => 'field_pd_feature_cta_text', 'label' => 'CTA Text', 'name' => 'cta_text', 'type' => 'text' ),
						array( 'key' => 'field_pd_feature_cta_url', 'label' => 'CTA URL', 'name' => 'cta_url', 'type' => 'url' ),
					),
				),

				array(
					'key'     => 'field_product_details_closing_tab',
					'label'   => 'Closing CTA',
					'name'    => '',
					'type'    => 'tab',
					'placement' => 'top',
				),
				array( 'key' => 'field_pd_closing_headline', 'label' => 'Closing Headline', 'name' => 'pd_closing_headline', 'type' => 'textarea', 'rows' => 3 ),
				array( 'key' => 'field_pd_closing_text', 'label' => 'Closing Text', 'name' => 'pd_closing_text', 'type' => 'textarea', 'rows' => 4 ),
				array( 'key' => 'field_pd_closing_image', 'label' => 'Closing Image', 'name' => 'pd_closing_image', 'type' => 'image', 'return_format' => 'array', 'preview_size' => 'large' ),
				array( 'key' => 'field_pd_closing_cta_text', 'label' => 'Closing CTA Text', 'name' => 'pd_closing_cta_text', 'type' => 'text' ),
				array( 'key' => 'field_pd_closing_cta_url', 'label' => 'Closing CTA URL', 'name' => 'pd_closing_cta_url', 'type' => 'url' ),
			),
			'location' => array(
				array(
					array(
						'param'    => 'page_template',
						'operator' => '==',
						'value'    => 'page-product-details.php',
					),
				),
			),
		)
	);

	/* ============================================================
	 * PRINCIPLES (24/7 accordion)
	 * ============================================================ */
	acf_add_local_field_group(
		array(
			'key'      => 'group_whoop_principles',
			'title'    => 'Principles Accordion',
			'fields'   => array(
				array( 'key' => 'field_pr_headline', 'label' => 'Headline', 'name' => 'headline', 'type' => 'text', 'default_value' => 'Built to be worn 24/7' ),
				array(
					'key'        => 'field_pr_items',
					'label'      => 'Principles',
					'name'       => 'principles',
					'type'       => 'repeater',
					'min'        => 1,
					'layout'     => 'block',
					'button_label' => 'Add Principle',
					'sub_fields' => array(
						array( 'key' => 'field_pr_title', 'label' => 'Title', 'name' => 'title', 'type' => 'text' ),
						array( 'key' => 'field_pr_desc', 'label' => 'Description', 'name' => 'description', 'type' => 'textarea', 'rows' => 3 ),
						array( 'key' => 'field_pr_image', 'label' => 'Image', 'name' => 'image', 'type' => 'image', 'return_format' => 'array' ),
					),
				),
			),
			'location' => array( array( array( 'param' => 'block', 'operator' => '==', 'value' => 'whoop/principles' ) ) ),
		)
	);

	/* ============================================================
	 * SHOWCASE
	 * ============================================================ */
	acf_add_local_field_group(
		array(
			'key'      => 'group_whoop_showcase',
			'title'    => 'Showcase — Ways to Wear',
			'fields'   => array(
				array( 'key' => 'field_sh_headline', 'label' => 'Headline', 'name' => 'headline', 'type' => 'text' ),
				array(
					'key'        => 'field_sh_tabs',
					'label'      => 'Tabs',
					'name'       => 'tabs',
					'type'       => 'repeater',
					'min'        => 1,
					'layout'     => 'block',
					'button_label' => 'Add Tab',
					'sub_fields' => array(
						array( 'key' => 'field_sh_label', 'label' => 'Tab Label', 'name' => 'tab_label', 'type' => 'text' ),
						array( 'key' => 'field_sh_image', 'label' => 'Tab Image', 'name' => 'tab_image', 'type' => 'image', 'return_format' => 'array' ),
						array( 'key' => 'field_sh_title', 'label' => 'Tab Title', 'name' => 'tab_title', 'type' => 'text' ),
						array( 'key' => 'field_sh_desc', 'label' => 'Tab Description', 'name' => 'tab_description', 'type' => 'textarea', 'rows' => 3 ),
					),
				),
			),
			'location' => array( array( array( 'param' => 'block', 'operator' => '==', 'value' => 'whoop/showcase' ) ) ),
		)
	);

	/* ============================================================
	 * EDITORIAL CAROUSEL
	 * ============================================================ */
	acf_add_local_field_group(
		array(
			'key'      => 'group_whoop_editorial_carousel',
			'title'    => 'Editorial Carousel',
			'fields'   => array(
				array( 'key' => 'field_ec_headline', 'label' => 'Headline', 'name' => 'headline', 'type' => 'textarea', 'rows' => 2 ),
				array( 'key' => 'field_ec_subline', 'label' => 'Subline', 'name' => 'subline', 'type' => 'textarea', 'rows' => 4 ),
				array(
					'key'          => 'field_ec_slides',
					'label'        => 'Slides',
					'name'         => 'slides',
					'type'         => 'repeater',
					'min'          => 1,
					'layout'       => 'block',
					'button_label' => 'Add Slide',
					'sub_fields'   => array(
						array( 'key' => 'field_ec_slide_image', 'label' => 'Image', 'name' => 'image', 'type' => 'image', 'return_format' => 'array', 'preview_size' => 'large', 'instructions' => 'Recommended size: 1280x1600.' ),
						array( 'key' => 'field_ec_slide_eyebrow', 'label' => 'Eyebrow', 'name' => 'eyebrow', 'type' => 'text' ),
						array( 'key' => 'field_ec_slide_title', 'label' => 'Title', 'name' => 'title', 'type' => 'text' ),
						array( 'key' => 'field_ec_slide_description', 'label' => 'Description', 'name' => 'description', 'type' => 'textarea', 'rows' => 4 ),
						array(
							'key'          => 'field_ec_slide_points',
							'label'        => 'Bullet Points',
							'name'         => 'points',
							'type'         => 'repeater',
							'layout'       => 'table',
							'button_label' => 'Add Point',
							'sub_fields'   => array(
								array( 'key' => 'field_ec_slide_point_text', 'label' => 'Text', 'name' => 'text', 'type' => 'text' ),
							),
						),
						array( 'key' => 'field_ec_slide_cta_text', 'label' => 'CTA Text', 'name' => 'cta_text', 'type' => 'text' ),
						array( 'key' => 'field_ec_slide_cta_url', 'label' => 'CTA URL', 'name' => 'cta_url', 'type' => 'url' ),
					),
				),
			),
			'location' => array( array( array( 'param' => 'block', 'operator' => '==', 'value' => 'whoop/editorial-carousel' ) ) ),
		)
	);

	/* ============================================================
	 * TECHNOLOGY LIST
	 * ============================================================ */
	acf_add_local_field_group(
		array(
			'key'      => 'group_whoop_technology_list',
			'title'    => 'Technology List',
			'fields'   => array(
				array( 'key' => 'field_tl_headline', 'label' => 'Headline', 'name' => 'headline', 'type' => 'textarea', 'rows' => 3 ),
				array( 'key' => 'field_tl_subline', 'label' => 'Subline', 'name' => 'subline', 'type' => 'textarea', 'rows' => 4 ),
				array(
					'key'          => 'field_tl_items',
					'label'        => 'Technology Items',
					'name'         => 'items',
					'type'         => 'repeater',
					'min'          => 1,
					'layout'       => 'block',
					'button_label' => 'Add Item',
					'sub_fields'   => array(
						array( 'key' => 'field_tl_item_image', 'label' => 'Image', 'name' => 'image', 'type' => 'image', 'return_format' => 'array', 'preview_size' => 'large', 'instructions' => 'Recommended size: 900x1200.' ),
						array( 'key' => 'field_tl_item_title', 'label' => 'Title', 'name' => 'title', 'type' => 'text' ),
						array( 'key' => 'field_tl_item_description', 'label' => 'Description', 'name' => 'description', 'type' => 'textarea', 'rows' => 3 ),
					),
				),
			),
			'location' => array( array( array( 'param' => 'block', 'operator' => '==', 'value' => 'whoop/technology-list' ) ) ),
		)
	);

	/* ============================================================
	 * TRIAL
	 * ============================================================ */
	acf_add_local_field_group(
		array(
			'key'      => 'group_whoop_trial',
			'title'    => 'Trial',
			'fields'   => array(
				array( 'key' => 'field_tr_title', 'label' => 'Title', 'name' => 'title', 'type' => 'text' ),
				array( 'key' => 'field_tr_desc', 'label' => 'Description', 'name' => 'description', 'type' => 'textarea', 'rows' => 4 ),
				array( 'key' => 'field_tr_cta_text', 'label' => 'CTA Text', 'name' => 'cta_text', 'type' => 'text', 'default_value' => 'Try WHOOP for free' ),
				array( 'key' => 'field_tr_cta_url', 'label' => 'CTA URL', 'name' => 'cta_url', 'type' => 'url' ),
				array( 'key' => 'field_tr_visual', 'label' => 'Visual Image', 'name' => 'visual_image', 'type' => 'image', 'return_format' => 'array', 'instructions' => 'Composition image (band + charger + phone).' ),
				array( 'key' => 'field_tr_show_join', 'label' => 'Show JOIN NOW pill below?', 'name' => 'show_join', 'type' => 'true_false', 'ui' => 1, 'default_value' => 1 ),
				array( 'key' => 'field_tr_join_text', 'label' => 'Join Pill Text', 'name' => 'join_text', 'type' => 'text', 'default_value' => 'Join Now' ),
				array( 'key' => 'field_tr_join_url', 'label' => 'Join Pill URL', 'name' => 'join_url', 'type' => 'url' ),
			),
			'location' => array( array( array( 'param' => 'block', 'operator' => '==', 'value' => 'whoop/trial' ) ) ),
		)
	);

	/* ============================================================
	 * ADVANCED LABS
	 * ============================================================ */
	acf_add_local_field_group(
		array(
			'key'      => 'group_whoop_labs',
			'title'    => 'Advanced Labs',
			'fields'   => array(
				array(
					'key'     => 'field_lb_display_mode',
					'label'   => 'Display Mode',
					'name'    => 'display_mode',
					'type'    => 'select',
					'choices' => array( 'default' => 'Default (image + bullets)', 'grid' => 'Services Grid (bento layout)' ),
					'default_value' => 'default',
					'wrapper' => array( 'width' => '50' ),
				),
				array( 'key' => 'field_lb_headline', 'label' => 'Headline', 'name' => 'headline', 'type' => 'text' ),
				array(
					'key'          => 'field_lb_iso_certs',
					'label'        => 'ISO Certificates',
					'name'         => 'iso_certificates',
					'type'         => 'repeater',
					'max'          => 5,
					'layout'       => 'table',
					'button_label' => 'Add Certificate',
					'sub_fields'   => array(
						array( 'key' => 'field_lb_iso_image', 'label' => 'Image', 'name' => 'image', 'type' => 'image', 'return_format' => 'array', 'preview_size' => 'thumbnail' ),
					),
				),
				array(
					'key'        => 'field_lb_bullets',
					'label'      => 'Bullets',
					'name'       => 'bullets',
					'type'       => 'repeater',
					'layout'     => 'table',
					'button_label' => 'Add Bullet',
					'sub_fields' => array(
						array( 'key' => 'field_lb_bullet_text', 'label' => 'Text', 'name' => 'text', 'type' => 'text' ),
					),
				),
				array( 'key' => 'field_lb_cta_text', 'label' => 'CTA Text', 'name' => 'cta_text', 'type' => 'text', 'default_value' => 'Get started with Advanced Labs' ),
				array( 'key' => 'field_lb_cta_url', 'label' => 'CTA URL', 'name' => 'cta_url', 'type' => 'url' ),
				array( 'key' => 'field_lb_image', 'label' => 'Image', 'name' => 'image', 'type' => 'image', 'return_format' => 'array' ),
				array(
					'key'        => 'field_lb_badges',
					'label'      => 'Floating Glass Badges',
					'name'       => 'badges',
					'type'       => 'repeater',
					'max'        => 3,
					'layout'     => 'block',
					'button_label' => 'Add Badge',
					'sub_fields' => array(
						array( 'key' => 'field_lb_badge_title', 'label' => 'Title', 'name' => 'badge_title', 'type' => 'text' ),
						array( 'key' => 'field_lb_badge_status', 'label' => 'Status (optional)', 'name' => 'badge_status', 'type' => 'text' ),
						array(
							'key'           => 'field_lb_badge_pos',
							'label'         => 'Position',
							'name'          => 'badge_position',
							'type'          => 'select',
							'choices'       => array(
								'top-left'     => 'Top Left',
								'mid-left'     => 'Middle Left',
								'bottom-right' => 'Bottom Right',
							),
							'default_value' => 'top-left',
						),
					),
				),
				array( 'key' => 'field_lb_grid_image', 'label' => 'Grid Image', 'name' => 'grid_image', 'type' => 'image', 'return_format' => 'array', 'instructions' => 'Tall image on the left side (grid mode only).', 'conditional_logic' => array( array( array( 'field' => 'field_lb_display_mode', 'operator' => '==', 'value' => 'grid' ) ) ) ),
				array(
					'key'          => 'field_lb_grid_cards',
					'label'        => 'Grid Cards',
					'name'         => 'grid_cards',
					'type'         => 'repeater',
					'min'          => 1,
					'max'          => 6,
					'layout'       => 'block',
					'button_label' => 'Add Card',
					'instructions' => 'Service cards for grid mode.',
					'conditional_logic' => array( array( array( 'field' => 'field_lb_display_mode', 'operator' => '==', 'value' => 'grid' ) ) ),
					'sub_fields'   => array(
						array( 'key' => 'field_lb_gc_label', 'label' => 'Label / Icon Text', 'name' => 'label', 'type' => 'text' ),
						array( 'key' => 'field_lb_gc_title', 'label' => 'Title', 'name' => 'title', 'type' => 'text' ),
						array( 'key' => 'field_lb_gc_description', 'label' => 'Description', 'name' => 'description', 'type' => 'textarea', 'rows' => 3 ),
						array( 'key' => 'field_lb_gc_image', 'label' => 'Card Image', 'name' => 'card_image', 'type' => 'image', 'return_format' => 'array', 'preview_size' => 'medium', 'instructions' => 'Optional image for this card.' ),
					),
				),
				array( 'key' => 'field_lb_show_join', 'label' => 'Show JOIN NOW pill below?', 'name' => 'show_join', 'type' => 'true_false', 'ui' => 1, 'default_value' => 1 ),
				array( 'key' => 'field_lb_join_text', 'label' => 'Join Pill Text', 'name' => 'join_text', 'type' => 'text', 'default_value' => 'Join Now' ),
				array( 'key' => 'field_lb_join_url', 'label' => 'Join Pill URL', 'name' => 'join_url', 'type' => 'url' ),
			),
			'location' => array( array( array( 'param' => 'block', 'operator' => '==', 'value' => 'whoop/advanced-labs' ) ) ),
		)
	);

	/* ============================================================
	 * SAMPLE BENEFITS
	 * ============================================================ */
	acf_add_local_field_group(
		array(
			'key'      => 'group_whoop_sample_benefits',
			'title'    => 'Sample Benefits',
			'fields'   => array(
				array( 'key' => 'field_sb_headline', 'label' => 'Headline', 'name' => 'headline', 'type' => 'text' ),
				array( 'key' => 'field_sb_subline', 'label' => 'Subline', 'name' => 'subline', 'type' => 'textarea', 'rows' => 2 ),
				array( 'key' => 'field_sb_image', 'label' => 'Image', 'name' => 'image', 'type' => 'image', 'return_format' => 'array' ),
				array(
					'key'          => 'field_sb_items',
					'label'        => 'Benefit Cards',
					'name'         => 'items',
					'type'         => 'repeater',
					'min'          => 1,
					'max'          => 4,
					'layout'       => 'block',
					'button_label' => 'Add Benefit',
					'sub_fields'   => array(
						array( 'key' => 'field_sb_item_title', 'label' => 'Title', 'name' => 'title', 'type' => 'text' ),
						array( 'key' => 'field_sb_item_description', 'label' => 'Description', 'name' => 'description', 'type' => 'textarea', 'rows' => 3 ),
					),
				),
			),
			'location' => array( array( array( 'param' => 'block', 'operator' => '==', 'value' => 'whoop/sample-benefits' ) ) ),
		)
	);

	/* ============================================================
	 * CONTACT + FAQ CTA
	 * ============================================================ */
	acf_add_local_field_group(
		array(
			'key'      => 'group_whoop_contact_faq',
			'title'    => 'Contact + FAQ CTA',
			'fields'   => array(
				array( 'key' => 'field_cf_left_title', 'label' => 'Left Column Title', 'name' => 'left_title', 'type' => 'text' ),
				array( 'key' => 'field_cf_left_subtitle', 'label' => 'Left Column Subtitle', 'name' => 'left_subtitle', 'type' => 'textarea', 'rows' => 4 ),
				array( 'key' => 'field_cf_left_cta_text', 'label' => 'FAQ CTA Text', 'name' => 'left_cta_text', 'type' => 'text' ),
				array( 'key' => 'field_cf_left_cta_url', 'label' => 'FAQ CTA URL', 'name' => 'left_cta_url', 'type' => 'url' ),
				array( 'key' => 'field_cf_form_title', 'label' => 'Form Title', 'name' => 'form_title', 'type' => 'text' ),
				array( 'key' => 'field_cf_form_subtitle', 'label' => 'Form Subtitle', 'name' => 'form_subtitle', 'type' => 'textarea', 'rows' => 4 ),
				array( 'key' => 'field_cf_name_label', 'label' => 'Name Field Label', 'name' => 'name_label', 'type' => 'text' ),
				array( 'key' => 'field_cf_name_placeholder', 'label' => 'Name Field Placeholder', 'name' => 'name_placeholder', 'type' => 'text' ),
				array( 'key' => 'field_cf_phone_label', 'label' => 'Phone Field Label', 'name' => 'phone_label', 'type' => 'text' ),
				array( 'key' => 'field_cf_phone_placeholder', 'label' => 'Phone Field Placeholder', 'name' => 'phone_placeholder', 'type' => 'text' ),
				array( 'key' => 'field_cf_consent_prefix', 'label' => 'Consent Text Before Link', 'name' => 'consent_prefix', 'type' => 'text' ),
				array( 'key' => 'field_cf_consent_link_text', 'label' => 'Consent Link Text', 'name' => 'consent_link_text', 'type' => 'text' ),
				array( 'key' => 'field_cf_consent_link_url', 'label' => 'Consent Link URL', 'name' => 'consent_link_url', 'type' => 'url' ),
				array( 'key' => 'field_cf_consent_suffix', 'label' => 'Consent Text After Link', 'name' => 'consent_suffix', 'type' => 'text' ),
				array( 'key' => 'field_cf_submit_text', 'label' => 'Submit Button Text', 'name' => 'submit_text', 'type' => 'text' ),
			),
			'location' => array( array( array( 'param' => 'block', 'operator' => '==', 'value' => 'whoop/contact-faq' ) ) ),
		)
	);

	/* ============================================================
	 * FAQS
	 * ============================================================ */
	acf_add_local_field_group(
		array(
			'key'      => 'group_whoop_faqs',
			'title'    => 'FAQs',
			'fields'   => array(
				array( 'key' => 'field_faqs_hero_image', 'label' => 'Hero Background Image', 'name' => 'hero_image', 'type' => 'image', 'return_format' => 'array' ),
				array( 'key' => 'field_faqs_headline', 'label' => 'Headline', 'name' => 'headline', 'type' => 'textarea', 'rows' => 3 ),
				array( 'key' => 'field_faqs_subline', 'label' => 'Subline', 'name' => 'subline', 'type' => 'textarea', 'rows' => 4 ),
				array( 'key' => 'field_faqs_intro_copy', 'label' => 'Intro Copy', 'name' => 'intro_copy', 'type' => 'textarea', 'rows' => 4 ),
				array(
					'key'          => 'field_faqs_items',
					'label'        => 'FAQ Items',
					'name'         => 'items',
					'type'         => 'repeater',
					'min'          => 1,
					'layout'       => 'block',
					'button_label' => 'Add FAQ Item',
					'sub_fields'   => array(
						array( 'key' => 'field_faqs_question', 'label' => 'Question', 'name' => 'question', 'type' => 'text' ),
						array( 'key' => 'field_faqs_answer', 'label' => 'Answer', 'name' => 'answer', 'type' => 'textarea', 'rows' => 5 ),
					),
				),
			),
			'location' => array( array( array( 'param' => 'block', 'operator' => '==', 'value' => 'whoop/faqs' ) ) ),
		)
	);

	/* ============================================================
	 * ABOUT HERO
	 * ============================================================ */
	acf_add_local_field_group(
		array(
			'key'      => 'group_whoop_about_hero',
			'title'    => 'About Hero',
			'fields'   => array(
				array( 'key' => 'field_about_hero_image', 'label' => 'Hero Background Image', 'name' => 'hero_image', 'type' => 'image', 'return_format' => 'array' ),
				array( 'key' => 'field_about_headline', 'label' => 'Hero Headline', 'name' => 'headline', 'type' => 'textarea', 'rows' => 3 ),
				array( 'key' => 'field_about_subline', 'label' => 'Hero Subline', 'name' => 'subline', 'type' => 'textarea', 'rows' => 4 ),
				array( 'key' => 'field_about_content_image', 'label' => 'About Image', 'name' => 'about_image', 'type' => 'image', 'return_format' => 'array' ),
				array( 'key' => 'field_about_title', 'label' => 'About Title', 'name' => 'about_title', 'type' => 'text' ),
				array( 'key' => 'field_about_text', 'label' => 'About Text', 'name' => 'about_text', 'type' => 'textarea', 'rows' => 10 ),
				array( 'key' => 'field_about_cta_text', 'label' => 'CTA Text', 'name' => 'cta_text', 'type' => 'text' ),
				array( 'key' => 'field_about_cta_url', 'label' => 'CTA URL', 'name' => 'cta_url', 'type' => 'url' ),
			),
			'location' => array( array( array( 'param' => 'block', 'operator' => '==', 'value' => 'whoop/about-hero' ) ) ),
		)
	);

	/* ============================================================
	 * STORY PAGE
	 * ============================================================ */
	acf_add_local_field_group(
		array(
			'key'      => 'group_whoop_story_page',
			'title'    => 'Story Page',
			'fields'   => array(
				array( 'key' => 'field_story_page_hero_image', 'label' => 'Hero Background Image', 'name' => 'hero_image', 'type' => 'image', 'return_format' => 'array' ),
				array( 'key' => 'field_story_page_headline', 'label' => 'Hero Headline', 'name' => 'headline', 'type' => 'textarea', 'rows' => 3 ),
				array( 'key' => 'field_story_page_subline', 'label' => 'Hero Subline', 'name' => 'subline', 'type' => 'textarea', 'rows' => 4 ),
				array( 'key' => 'field_story_page_hero_cta_text', 'label' => 'Hero CTA Text', 'name' => 'hero_cta_text', 'type' => 'text', 'wrapper' => array( 'width' => '50' ) ),
				array( 'key' => 'field_story_page_hero_cta_url', 'label' => 'Hero CTA URL', 'name' => 'hero_cta_url', 'type' => 'url', 'wrapper' => array( 'width' => '50' ) ),
				array(
					'key'          => 'field_story_page_stats',
					'label'        => 'Stats Bar',
					'name'         => 'stats',
					'type'         => 'repeater',
					'min'          => 0,
					'max'          => 4,
					'layout'       => 'table',
					'button_label' => 'İstatistik Ekle',
					'instructions' => 'Hero altında görünen istatistik kutuları (ör. 440+, 3 Gün, %99)',
					'sub_fields'   => array(
						array( 'key' => 'field_story_stat_value', 'label' => 'Value', 'name' => 'value', 'type' => 'text', 'instructions' => 'E.g. "440+"' ),
						array( 'key' => 'field_story_stat_label', 'label' => 'Label', 'name' => 'label', 'type' => 'text', 'instructions' => 'E.g. "Besin Maddesi"' ),
					),
				),
				array(
					'key'          => 'field_story_page_sections',
					'label'        => 'Content Sections',
					'name'         => 'sections',
					'type'         => 'repeater',
					'min'          => 1,
					'layout'       => 'block',
					'button_label' => 'Bölüm Ekle',
					'sub_fields'   => array(
						array( 'key' => 'field_story_page_section_image', 'label' => 'Image', 'name' => 'image', 'type' => 'image', 'return_format' => 'array' ),
						array( 'key' => 'field_story_page_section_title', 'label' => 'Title', 'name' => 'title', 'type' => 'text' ),
						array( 'key' => 'field_story_page_section_text', 'label' => 'Text', 'name' => 'text', 'type' => 'wysiwyg', 'tabs' => 'visual', 'media_upload' => 0, 'toolbar' => 'basic' ),
						array(
							'key'          => 'field_story_page_section_bullets',
							'label'        => 'Bullet Points',
							'name'         => 'bullets',
							'type'         => 'repeater',
							'min'          => 0,
							'max'          => 8,
							'layout'       => 'table',
							'button_label' => 'Madde Ekle',
							'sub_fields'   => array(
								array( 'key' => 'field_story_bullet_text', 'label' => 'Text', 'name' => 'text', 'type' => 'text' ),
							),
						),
						array(
							'key'     => 'field_story_page_section_bg',
							'label'   => 'Background Style',
							'name'    => 'bg_style',
							'type'    => 'select',
							'choices' => array( 'white' => 'White', 'light' => 'Light Gray', 'dark' => 'Dark' ),
							'default_value' => 'white',
							'wrapper' => array( 'width' => '33' ),
						),
						array( 'key' => 'field_story_page_section_cta_text', 'label' => 'CTA Text', 'name' => 'cta_text', 'type' => 'text', 'wrapper' => array( 'width' => '33' ) ),
						array( 'key' => 'field_story_page_section_cta_url', 'label' => 'CTA URL', 'name' => 'cta_url', 'type' => 'url', 'wrapper' => array( 'width' => '33' ) ),
					),
				),
			),
			'location' => array( array( array( 'param' => 'block', 'operator' => '==', 'value' => 'whoop/story-page' ) ) ),
		)
	);

	/* ============================================================
	 * LEGAL PAGE
	 * ============================================================ */
	acf_add_local_field_group(
		array(
			'key'      => 'group_whoop_legal_page',
			'title'    => 'Legal Page',
			'fields'   => array(
				array( 'key' => 'field_legal_hero_image', 'label' => 'Hero Image', 'name' => 'hero_image', 'type' => 'image', 'return_format' => 'array', 'preview_size' => 'large' ),
				array( 'key' => 'field_legal_headline', 'label' => 'Headline', 'name' => 'headline', 'type' => 'textarea', 'rows' => 3 ),
				array( 'key' => 'field_legal_subline', 'label' => 'Subline', 'name' => 'subline', 'type' => 'textarea', 'rows' => 3 ),
				array( 'key' => 'field_legal_content', 'label' => 'Content', 'name' => 'content', 'type' => 'wysiwyg', 'tabs' => 'all', 'toolbar' => 'full', 'media_upload' => 0, 'delay' => 0 ),
			),
			'location' => array( array( array( 'param' => 'block', 'operator' => '==', 'value' => 'whoop/legal-page' ) ) ),
		)
	);

	/* ============================================================
	 * PRODUCT STEPS
	 * ============================================================ */
	acf_add_local_field_group(
		array(
			'key'      => 'group_whoop_product_steps',
			'title'    => 'Product Steps',
			'fields'   => array(
				array( 'key' => 'field_product_steps_headline', 'label' => 'Headline', 'name' => 'headline', 'type' => 'text' ),
				array( 'key' => 'field_product_steps_subline', 'label' => 'Subline', 'name' => 'subline', 'type' => 'textarea', 'rows' => 3 ),
				array(
					'key'          => 'field_product_steps_items',
					'label'        => 'Steps',
					'name'         => 'steps',
					'type'         => 'repeater',
					'min'          => 1,
					'layout'       => 'block',
					'button_label' => 'Add Step',
					'sub_fields'   => array(
						array( 'key' => 'field_product_steps_label', 'label' => 'Step Label', 'name' => 'label', 'type' => 'text' ),
						array( 'key' => 'field_product_steps_title', 'label' => 'Step Title', 'name' => 'title', 'type' => 'text' ),
						array( 'key' => 'field_product_steps_text', 'label' => 'Step Text', 'name' => 'text', 'type' => 'textarea', 'rows' => 4 ),
					),
				),
			),
			'location' => array( array( array( 'param' => 'block', 'operator' => '==', 'value' => 'whoop/product-steps' ) ) ),
		)
	);

	/* ============================================================
	 * PRODUCT NOTE
	 * ============================================================ */
	acf_add_local_field_group(
		array(
			'key'      => 'group_whoop_product_note',
			'title'    => 'Product Note',
			'fields'   => array(
				array( 'key' => 'field_product_note_text', 'label' => 'Note Text', 'name' => 'text', 'type' => 'textarea', 'rows' => 3 ),
			),
			'location' => array( array( array( 'param' => 'block', 'operator' => '==', 'value' => 'whoop/product-note' ) ) ),
		)
	);

	/* ============================================================
	 * WOOCOMMERCE PRODUCT DETAIL SECTIONS
	 * ============================================================ */
	acf_add_local_field_group(
		array(
			'key'      => 'group_whoop_wc_product_sections',
			'title'    => 'WooCommerce — Product Detail Sections',
			'fields'   => array(
				array( 'key' => 'field_wc_product_hero_visual', 'label' => 'Hero Visual Override', 'name' => 'whoop_product_hero_visual', 'type' => 'image', 'return_format' => 'array', 'preview_size' => 'large' ),
				array(
					'key'          => 'field_wc_product_hero_certificates',
					'label'        => 'Hero ISO Certificates',
					'name'         => 'whoop_product_hero_certificates',
					'type'         => 'repeater',
					'layout'       => 'table',
					'button_label' => 'Add Certificate',
					'sub_fields'   => array(
						array( 'key' => 'field_wc_product_hero_certificate_image', 'label' => 'Image', 'name' => 'image', 'type' => 'image', 'return_format' => 'array', 'preview_size' => 'medium' ),
					),
				),
				array(
					'key'          => 'field_wc_product_hero_features',
					'label'        => 'Hero Feature List',
					'name'         => 'whoop_product_hero_features',
					'type'         => 'repeater',
					'layout'       => 'table',
					'button_label' => 'Add Feature',
					'sub_fields'   => array(
						array( 'key' => 'field_wc_product_hero_feature_text', 'label' => 'Text', 'name' => 'text', 'type' => 'text' ),
					),
				),
				array( 'key' => 'field_wc_product_hero_secondary_cta_text', 'label' => 'Hero Secondary CTA Text', 'name' => 'whoop_product_hero_secondary_cta_text', 'type' => 'text' ),
				array( 'key' => 'field_wc_product_hero_secondary_cta_url', 'label' => 'Hero Secondary CTA URL', 'name' => 'whoop_product_hero_secondary_cta_url', 'type' => 'url' ),
				array( 'key' => 'field_wc_product_hero_trust_text', 'label' => 'Hero Trust Strip Text', 'name' => 'whoop_product_hero_trust_text', 'type' => 'text' ),
				array( 'key' => 'field_wc_product_bundle_heading', 'label' => 'Bundle Offers Heading', 'name' => 'whoop_product_bundle_heading', 'type' => 'text', 'instructions' => 'Optional title shown above the bundle pricing cards.' ),
				array(
					'key'          => 'field_wc_product_bundle_offers',
					'label'        => 'Bundle Offers',
					'name'         => 'whoop_product_bundle_offers',
					'type'         => 'repeater',
					'min'          => 0,
					'layout'       => 'block',
					'button_label' => 'Add Bundle Offer',
					'sub_fields'   => array(
						array( 'key' => 'field_wc_product_bundle_image', 'label' => 'Offer Image', 'name' => 'image', 'type' => 'image', 'return_format' => 'array', 'preview_size' => 'medium' ),
						array( 'key' => 'field_wc_product_bundle_quantity_label', 'label' => 'Quantity Label', 'name' => 'quantity_label', 'type' => 'text', 'instructions' => 'Example: 3x or 5x' ),
						array( 'key' => 'field_wc_product_bundle_quantity_value', 'label' => 'Quantity Value', 'name' => 'quantity_value', 'type' => 'number', 'instructions' => 'Tıklandığında sepete eklenecek adet sayısı. Örn: 2, 3, 5', 'default_value' => 1, 'min' => 1, 'max' => 99 ),
						array( 'key' => 'field_wc_product_bundle_title', 'label' => 'Offer Title', 'name' => 'title', 'type' => 'text', 'instructions' => 'Example: 3x Premium DNA Test' ),
						array( 'key' => 'field_wc_product_bundle_badge_text', 'label' => 'Discount Badge Text', 'name' => 'badge_text', 'type' => 'text', 'instructions' => 'Example: 30% Off' ),
						array( 'key' => 'field_wc_product_bundle_price_text', 'label' => 'Primary Price Text', 'name' => 'price_text', 'type' => 'text', 'instructions' => 'Example: €419' ),
						array( 'key' => 'field_wc_product_bundle_compare_price_text', 'label' => 'Compare Price Text', 'name' => 'compare_price_text', 'type' => 'text', 'instructions' => 'Example: €599' ),
						array( 'key' => 'field_wc_product_bundle_unit_text', 'label' => 'Unit Text', 'name' => 'unit_text', 'type' => 'text', 'instructions' => 'Example: per kit' ),
					),
				),
				array( 'key' => 'field_wc_product_steps_headline', 'label' => 'Steps Headline', 'name' => 'whoop_product_steps_headline', 'type' => 'text' ),
				array( 'key' => 'field_wc_product_steps_subline', 'label' => 'Steps Subline', 'name' => 'whoop_product_steps_subline', 'type' => 'textarea', 'rows' => 3 ),
				array(
					'key'          => 'field_wc_product_steps_items',
					'label'        => 'Steps',
					'name'         => 'whoop_product_steps_items',
					'type'         => 'repeater',
					'min'          => 0,
					'layout'       => 'block',
					'button_label' => 'Add Step',
					'sub_fields'   => array(
						array( 'key' => 'field_wc_product_step_label', 'label' => 'Step Label', 'name' => 'label', 'type' => 'text' ),
						array( 'key' => 'field_wc_product_step_title', 'label' => 'Step Title', 'name' => 'title', 'type' => 'text' ),
						array( 'key' => 'field_wc_product_step_text', 'label' => 'Step Text', 'name' => 'text', 'type' => 'textarea', 'rows' => 4 ),
					),
				),
				array( 'key' => 'field_wc_product_note_text', 'label' => 'Supporting Note', 'name' => 'whoop_product_note_text', 'type' => 'textarea', 'rows' => 3 ),
			),
			'location' => array(
				array(
					array(
						'param'    => 'post_type',
						'operator' => '==',
						'value'    => 'product',
					),
				),
			),
		)
	);
	/* ============================================================
	 * PRODUCT SHOWCASE
	 * ============================================================ */
	acf_add_local_field_group(
		array(
			'key'      => 'group_whoop_product_showcase',
			'title'    => 'Product Showcase',
			'fields'   => array(
				array( 'key' => 'field_ps_headline', 'label' => 'Headline', 'name' => 'headline', 'type' => 'text' ),
				array( 'key' => 'field_ps_subline', 'label' => 'Subline', 'name' => 'subline', 'type' => 'textarea', 'rows' => 2 ),
				array(
					'key'        => 'field_ps_products',
					'label'      => 'Products',
					'name'       => 'products',
					'type'       => 'repeater',
					'layout'     => 'block',
					'min'        => 1,
					'max'        => 6,
					'button_label' => 'Ürün Ekle',
					'sub_fields' => array(
						array( 'key' => 'field_ps_badge_text', 'label' => 'Badge Text', 'name' => 'badge_text', 'type' => 'text', 'instructions' => 'E.g. "En Kapsamlı"', 'wrapper' => array( 'width' => '50' ) ),
						array( 'key' => 'field_ps_badge_color', 'label' => 'Badge Color', 'name' => 'badge_color', 'type' => 'color_picker', 'default_value' => '#ff4d4d', 'wrapper' => array( 'width' => '50' ) ),
						array( 'key' => 'field_ps_product_logo', 'label' => 'Product Logo', 'name' => 'product_logo', 'type' => 'image', 'return_format' => 'array', 'preview_size' => 'medium', 'instructions' => 'Product line logo (e.g. Elite, Platinum)' ),
						array( 'key' => 'field_ps_subtitle', 'label' => 'Subtitle', 'name' => 'subtitle', 'type' => 'text', 'instructions' => 'E.g. "440 Yiyecek ve İçecek Maddesi"' ),
						array( 'key' => 'field_ps_image', 'label' => 'Product Image', 'name' => 'image', 'type' => 'image', 'return_format' => 'array', 'preview_size' => 'medium' ),
						array( 'key' => 'field_ps_rating', 'label' => 'Rating', 'name' => 'rating', 'type' => 'number', 'min' => 0, 'max' => 5, 'step' => 0.1, 'wrapper' => array( 'width' => '50' ) ),
						array( 'key' => 'field_ps_rating_count', 'label' => 'Rating Count', 'name' => 'rating_count', 'type' => 'text', 'instructions' => 'E.g. "162 değerlendirme"', 'wrapper' => array( 'width' => '50' ) ),
						array( 'key' => 'field_ps_title', 'label' => 'Title', 'name' => 'title', 'type' => 'text' ),
						array( 'key' => 'field_ps_old_price', 'label' => 'Old Price', 'name' => 'old_price', 'type' => 'text', 'instructions' => 'E.g. "4.500 ₺"', 'wrapper' => array( 'width' => '50' ) ),
						array( 'key' => 'field_ps_new_price', 'label' => 'New Price', 'name' => 'new_price', 'type' => 'text', 'instructions' => 'E.g. "3.750 ₺"', 'wrapper' => array( 'width' => '50' ) ),
						array(
							'key'        => 'field_ps_features',
							'label'      => 'Features',
							'name'       => 'features',
							'type'       => 'repeater',
							'layout'     => 'table',
							'min'        => 0,
							'max'        => 12,
							'button_label' => 'Özellik Ekle',
							'sub_fields' => array(
								array( 'key' => 'field_ps_feat_text', 'label' => 'Text', 'name' => 'text', 'type' => 'text' ),
								array( 'key' => 'field_ps_feat_hl', 'label' => 'Highlight', 'name' => 'is_highlight', 'type' => 'true_false', 'ui' => 1 ),
							),
						),
						array(
							'key'        => 'field_ps_certs',
							'label'      => 'Certificates',
							'name'       => 'certificates',
							'type'       => 'repeater',
							'layout'     => 'table',
							'min'        => 0,
							'max'        => 6,
							'button_label' => 'Sertifika Ekle',
							'sub_fields' => array(
								array( 'key' => 'field_ps_cert_img', 'label' => 'Image', 'name' => 'image', 'type' => 'image', 'return_format' => 'array', 'preview_size' => 'thumbnail' ),
							),
						),
						array( 'key' => 'field_ps_cta_text', 'label' => 'CTA Text', 'name' => 'cta_text', 'type' => 'text', 'default_value' => 'Satın Al', 'wrapper' => array( 'width' => '50' ) ),
						array( 'key' => 'field_ps_cta_url', 'label' => 'CTA URL', 'name' => 'cta_url', 'type' => 'url', 'wrapper' => array( 'width' => '50' ) ),
						array( 'key' => 'field_ps_cta2_text', 'label' => 'Secondary CTA Text', 'name' => 'cta_secondary_text', 'type' => 'text', 'default_value' => 'Detaylı Bilgi', 'wrapper' => array( 'width' => '50' ) ),
						array( 'key' => 'field_ps_cta2_url', 'label' => 'Secondary CTA URL', 'name' => 'cta_secondary_url', 'type' => 'url', 'wrapper' => array( 'width' => '50' ) ),
					),
				),
			),
			'location' => array(
				array(
					array(
						'param'    => 'block',
						'operator' => '==',
						'value'    => 'whoop/product-showcase',
					),
				),
			),
		)
	);
	/* ============================================================
	 * UNIVERSAL SECTION SPACING — applies to all whoop/* blocks
	 * ============================================================ */
	acf_add_local_field_group(
		array(
			'key'      => 'group_whoop_section_spacing',
			'title'    => 'Section Spacing',
			'fields'   => array(
				array( 'key' => 'field_section_spacing_top', 'label' => 'Spacing Top (px)', 'name' => 'section_spacing_top', 'type' => 'number', 'instructions' => 'Üst boşluk (px). Boş bırakılırsa varsayılan kullanılır.', 'default_value' => '', 'min' => 0, 'max' => 400, 'step' => 1, 'wrapper' => array( 'width' => '50' ) ),
				array( 'key' => 'field_section_spacing_bottom', 'label' => 'Spacing Bottom (px)', 'name' => 'section_spacing_bottom', 'type' => 'number', 'instructions' => 'Alt boşluk (px). Boş bırakılırsa varsayılan kullanılır.', 'default_value' => '', 'min' => 0, 'max' => 400, 'step' => 1, 'wrapper' => array( 'width' => '50' ) ),
			),
			'location' => array(
				array( array( 'param' => 'block', 'operator' => '==', 'value' => 'whoop/memberships' ) ),
				array( array( 'param' => 'block', 'operator' => '==', 'value' => 'whoop/hero' ) ),
				array( array( 'param' => 'block', 'operator' => '==', 'value' => 'whoop/features-slider' ) ),
				array( array( 'param' => 'block', 'operator' => '==', 'value' => 'whoop/social-proof' ) ),
				array( array( 'param' => 'block', 'operator' => '==', 'value' => 'whoop/advanced-labs' ) ),
				array( array( 'param' => 'block', 'operator' => '==', 'value' => 'whoop/principles' ) ),
				array( array( 'param' => 'block', 'operator' => '==', 'value' => 'whoop/editorial-carousel' ) ),
				array( array( 'param' => 'block', 'operator' => '==', 'value' => 'whoop/contact-faq' ) ),
				array( array( 'param' => 'block', 'operator' => '==', 'value' => 'whoop/sample-benefits' ) ),
				array( array( 'param' => 'block', 'operator' => '==', 'value' => 'whoop/showcase' ) ),
				array( array( 'param' => 'block', 'operator' => '==', 'value' => 'whoop/technology-list' ) ),
				array( array( 'param' => 'block', 'operator' => '==', 'value' => 'whoop/trial' ) ),
				array( array( 'param' => 'block', 'operator' => '==', 'value' => 'whoop/daily' ) ),
				array( array( 'param' => 'block', 'operator' => '==', 'value' => 'whoop/gift' ) ),
				array( array( 'param' => 'block', 'operator' => '==', 'value' => 'whoop/product-steps' ) ),
				array( array( 'param' => 'block', 'operator' => '==', 'value' => 'whoop/product-note' ) ),
				array( array( 'param' => 'block', 'operator' => '==', 'value' => 'whoop/faqs' ) ),
				array( array( 'param' => 'block', 'operator' => '==', 'value' => 'whoop/category-showcase' ) ),
			),
			'menu_order' => 100,
		)
	);
}
add_action( 'acf/init', 'whoop_register_acf_field_groups' );

/* ============================================================
 * Customizer settings — header/footer global text fields
 * ============================================================ */
function whoop_sanitize_unfiltered_html( $value ) {
	if ( current_user_can( 'unfiltered_html' ) ) {
		return (string) $value;
	}

	return wp_kses_post( (string) $value );
}

function whoop_customize_register( $wp_customize ) {
	$wp_customize->add_section(
		'whoop_globals',
		array(
			'title'    => __( 'WHOOP — Global Text', 'whoop-clone' ),
			'priority' => 30,
		)
	);

	$controls = array(
		'whoop_promo_text'      => array( 'label' => 'Promo Bar Text', 'default' => 'Discover exclusive membership benefits for Chase Sapphire® cardholders.' ),
		'whoop_promo_link_text' => array( 'label' => 'Promo Link Text', 'default' => 'Explore Now' ),
		'whoop_promo_link_url'  => array( 'label' => 'Promo Link URL', 'default' => '#', 'type' => 'url' ),
		'whoop_gift_text'       => array( 'label' => 'Header Gift Button Text', 'default' => 'Gift WHOOP' ),
		'whoop_gift_url'        => array( 'label' => 'Header Gift Button URL', 'default' => '#', 'type' => 'url' ),
		'whoop_join_text'       => array( 'label' => 'Header Join Button Text', 'default' => 'SATIN AL' ),
		'whoop_join_url'        => array( 'label' => 'Header Join Button URL', 'default' => '#', 'type' => 'url' ),
		'whoop_mobile_menu_title' => array( 'label' => 'Mobile Menu Title', 'default' => 'Menu' ),
		'whoop_footer_tagline'  => array( 'label' => 'Footer Tagline', 'default' => 'Unlock better performance and long-term health.' ),
		'whoop_footer_show_newsletter' => array( 'label' => 'Show Footer Newsletter Area', 'default' => 1, 'type' => 'checkbox', 'sanitize' => 'absint' ),
		'whoop_footer_show_company' => array( 'label' => 'Show Footer Company Column', 'default' => 1, 'type' => 'checkbox', 'sanitize' => 'absint' ),
		'whoop_footer_show_legal' => array( 'label' => 'Show Footer Legal Column', 'default' => 1, 'type' => 'checkbox', 'sanitize' => 'absint' ),
		'whoop_footer_newsletter_title' => array( 'label' => 'Footer Newsletter Title', 'default' => 'Stay connected' ),
		'whoop_footer_email_placeholder' => array( 'label' => 'Footer Email Placeholder', 'default' => 'Your email address' ),
		'whoop_footer_subscribe_text' => array( 'label' => 'Footer Subscribe Button Text', 'default' => 'Subscribe' ),
		'whoop_footer_policy_text' => array( 'label' => 'Footer Policy Text', 'default' => 'By signing up, you agree to our data protection policy.' ),
		'whoop_footer_copyright_text' => array( 'label' => 'Footer Copyright Text', 'default' => 'All rights reserved.' ),
		'whoop_footer_company_title' => array( 'label' => 'Footer Company Title', 'default' => 'Company' ),
		'whoop_footer_legal_title' => array( 'label' => 'Footer Legal Title', 'default' => 'Legal' ),
		'whoop_footer_contact_title' => array( 'label' => 'Footer Contact Title', 'default' => 'İletişim' ),
		'whoop_footer_contact_service_label' => array( 'label' => 'Footer Customer Service Label', 'default' => 'Müşteri Hizmetleri' ),
		'whoop_footer_contact_service_value' => array( 'label' => 'Footer Customer Service Value', 'default' => '0216 709 75 01' ),
		'whoop_footer_contact_email_label' => array( 'label' => 'Footer Email Label', 'default' => 'E-posta' ),
		'whoop_footer_contact_email_value' => array( 'label' => 'Footer Email Value', 'default' => 'iletisim@biitest-tr.com' ),
		'whoop_footer_contact_offices_title' => array( 'label' => 'Footer Offices Title', 'default' => 'Ofisler' ),
		'whoop_footer_office_tr_flag' => array( 'label' => 'Footer Turkey Flag', 'default' => '🇹🇷' ),
		'whoop_footer_office_tr_title' => array( 'label' => 'Footer Turkey Title', 'default' => 'Türkiye' ),
		'whoop_footer_office_tr_address' => array( 'label' => 'Footer Turkey Address', 'default' => 'Ritim İstanbul, Maltepe / İstanbul' ),
		'whoop_footer_office_uk_flag' => array( 'label' => 'Footer UK Flag', 'default' => '🇬🇧' ),
		'whoop_footer_office_uk_title' => array( 'label' => 'Footer UK Title', 'default' => 'İngiltere' ),
		'whoop_footer_office_uk_address' => array( 'label' => 'Footer UK Address', 'default' => 'Innovation Centre, University of Northampton' ),
		'whoop_footer_office_cy_flag' => array( 'label' => 'Footer KKTC Flag', 'default' => '🇨🇾' ),
		'whoop_footer_office_cy_title' => array( 'label' => 'Footer KKTC Title', 'default' => 'KKTC' ),
		'whoop_footer_office_cy_address' => array( 'label' => 'Footer KKTC Address', 'default' => 'Serbest Liman, Gazimağusa' ),
		'whoop_footer_etbis_title' => array( 'label' => 'Footer ETBIS Title', 'default' => 'ETBİS QR Kodu' ),
		'whoop_footer_etbis_script' => array( 'label' => 'Footer ETBIS Script', 'default' => '', 'type' => 'textarea', 'sanitize' => 'whoop_sanitize_unfiltered_html' ),
		'whoop_footer_disclaimer_title' => array( 'label' => 'Footer Disclaimer Title', 'default' => 'Yasal Uyarı / Legal Disclaimer' ),
		'whoop_footer_disclaimer_text' => array( 'label' => 'Footer Disclaimer Text', 'default' => "Yasal Uyarı — Besin intoleransı testleri tamamlayıcı ve alternatif tıp kategorisine girer, teşhis ve tedavi amacı ile kullanılamaz. Sağlanan sonuçlar ve ilgili bilgiler tıbbi bir teşhis koymaz ve profesyonel tıbbi tavsiye, teşhis veya tedavinin yerine geçmesi amaçlanmamıştır. Tıbbi bir sorununuz varsa ilgili birim ve doktoru ile irtibata geçmenizi tavsiye ederiz.\n\nLegal Disclaimer — Food intolerance tests fall under the category of complementary and alternative medicine and cannot be used for diagnosis and treatment purposes. The results and related information provided do not constitute a medical diagnosis and are not intended to substitute for professional medical advice, diagnosis, or treatment. We recommend contacting the relevant unit and doctor if you have a medical problem.", 'type' => 'textarea', 'sanitize' => 'sanitize_textarea_field' ),
		'whoop_footer_cookie_text' => array( 'label' => 'Footer Cookie Notice Link Text', 'default' => 'Çerez Aydınlatma Metni' ),
		'whoop_footer_cookie_url' => array( 'label' => 'Footer Cookie Notice Link URL', 'default' => '#', 'type' => 'url' ),
		'whoop_footer_kvkk_text' => array( 'label' => 'Footer KVKK Link Text', 'default' => 'Kişisel Verilerin Korunması - KVKK' ),
		'whoop_footer_kvkk_url' => array( 'label' => 'Footer KVKK Link URL', 'default' => '#', 'type' => 'url' ),
		'whoop_footer_refund_text' => array( 'label' => 'Footer Refund Policy Link Text', 'default' => 'Geri Ödeme ve İade Politikası' ),
		'whoop_footer_refund_url' => array( 'label' => 'Footer Refund Policy Link URL', 'default' => '#', 'type' => 'url' ),
		'whoop_feature_modal_tiers_label' => array( 'label' => 'Feature Modal Tiers Label', 'default' => 'Available on' ),
		'whoop_feature_modal_spotlight_label' => array( 'label' => 'Feature Modal Spotlight Label', 'default' => 'Member Spotlight' ),
	);

	foreach ( $controls as $id => $cfg ) {
		$wp_customize->add_setting(
			$id,
			array(
				'default'           => $cfg['default'],
				'sanitize_callback' => isset( $cfg['sanitize'] ) ? $cfg['sanitize'] : ( isset( $cfg['type'] ) && 'url' === $cfg['type'] ? 'esc_url_raw' : 'sanitize_text_field' ),
				'transport'         => 'refresh',
			)
		);
		$wp_customize->add_control(
			$id,
			array(
				'label'   => $cfg['label'],
				'section' => 'whoop_globals',
				'type'    => isset( $cfg['type'] ) ? $cfg['type'] : 'text',
			)
		);
	}

	$wp_customize->add_setting(
		'whoop_footer_logo',
		array(
			'default'           => 0,
			'sanitize_callback' => 'absint',
			'transport'         => 'refresh',
		)
	);

	$wp_customize->add_control(
		new WP_Customize_Media_Control(
			$wp_customize,
			'whoop_footer_logo',
			array(
				'label'       => __( 'Footer Logo', 'whoop-clone' ),
				'section'     => 'whoop_globals',
				'mime_type'   => 'image',
				'description' => __( 'Optional footer-specific logo. Falls back to the site logo when empty.', 'whoop-clone' ),
			)
		)
	);
}
add_action( 'customize_register', 'whoop_customize_register' );
