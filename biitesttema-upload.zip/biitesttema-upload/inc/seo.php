<?php
/**
 * Lightweight SEO helpers when no major SEO plugin is active.
 *
 * @package whoop-clone
 */

defined( 'ABSPATH' ) || exit;

/**
 * Detect common SEO plugins to avoid duplicate JSON-LD.
 *
 * @return bool
 */
function whoop_seo_plugin_handles_schema() {
	if ( apply_filters( 'whoop_disable_theme_json_ld', false ) ) {
		return true;
	}
	return defined( 'WPSEO_VERSION' )
		|| defined( 'RANK_MATH_VERSION' )
		|| defined( 'AIOSEO_VERSION' )
		|| class_exists( 'TSF_Extension_Manager', false )
		|| function_exists( 'tsf' );
}

/**
 * Output WebSite + Organization JSON-LD on front-end.
 */
function whoop_output_theme_json_ld() {
	if ( ! is_front_page() && ! is_home() ) {
		return;
	}
	if ( whoop_seo_plugin_handles_schema() ) {
		return;
	}

	$site_url = home_url( '/' );
	$name     = get_bloginfo( 'name' );
	if ( '' === $name ) {
		return;
	}

	$graph = array(
		'@context' => 'https://schema.org',
		'@graph'   => array(
			array(
				'@type'       => 'WebSite',
				'@id'         => $site_url . '#website',
				'url'         => $site_url,
				'name'        => $name,
				'description' => get_bloginfo( 'description' ),
				'publisher'   => array( '@id' => $site_url . '#org' ),
			),
			array(
				'@type' => 'Organization',
				'@id'   => $site_url . '#org',
				'name'  => $name,
				'url'   => $site_url,
			),
		),
	);

	$logo_id = (int) get_theme_mod( 'custom_logo' );
	if ( $logo_id ) {
		$logo_url = wp_get_attachment_image_url( $logo_id, 'full' );
		if ( $logo_url ) {
			$graph['@graph'][1]['logo'] = array(
				'@type' => 'ImageObject',
				'url'   => $logo_url,
			);
		}
	}

	echo '<script type="application/ld+json" id="whoop-theme-jsonld">';
	echo wp_json_encode( $graph, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP );
	echo '</script>' . "\n";
}
add_action( 'wp_head', 'whoop_output_theme_json_ld', 5 );
