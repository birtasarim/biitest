<?php
/**
 * WooCommerce Customizer settings (editable storefront copy).
 *
 * @package whoop-clone
 */

defined( 'ABSPATH' ) || exit;

/**
 * Register WooCommerce Customizer section and controls.
 *
 * @param WP_Customize_Manager $wp_customize Customizer instance.
 */
function whoop_woocommerce_customize_register( $wp_customize ) {
	$wp_customize->add_section(
		'whoop_woocommerce',
		array(
			'title'    => __( 'WHOOP — WooCommerce', 'whoop-clone' ),
			'priority' => 35,
		)
	);

	$controls = array(
		'whoop_shop_subtitle'              => array(
			'label'       => __( 'Shop archive subtitle', 'whoop-clone' ),
			'default'     => '',
			'type'        => 'textarea',
			'sanitize'    => 'sanitize_textarea_field',
		),
		'whoop_trust_1_text'               => array(
			'label'   => __( 'Trust badge 1 text', 'whoop-clone' ),
			'default' => __( 'Secure checkout', 'whoop-clone' ),
		),
		'whoop_trust_1_icon'               => array(
			'label'   => __( 'Trust badge 1 icon (lock|truck|refresh|shield)', 'whoop-clone' ),
			'default' => 'lock',
		),
		'whoop_trust_2_text'               => array(
			'label'   => __( 'Trust badge 2 text', 'whoop-clone' ),
			'default' => __( 'Fast shipping', 'whoop-clone' ),
		),
		'whoop_trust_2_icon'               => array(
			'label'   => __( 'Trust badge 2 icon', 'whoop-clone' ),
			'default' => 'truck',
		),
		'whoop_trust_3_text'               => array(
			'label'   => __( 'Trust badge 3 text', 'whoop-clone' ),
			'default' => __( 'Easy returns', 'whoop-clone' ),
		),
		'whoop_trust_3_icon'               => array(
			'label'   => __( 'Trust badge 3 icon', 'whoop-clone' ),
			'default' => 'refresh',
		),
		'whoop_free_shipping_threshold'    => array(
			'label'       => __( 'Free shipping threshold (store currency)', 'whoop-clone' ),
			'default'     => '500',
			'type'        => 'number',
			'sanitize'    => 'whoop_sanitize_positive_float',
		),
		'whoop_free_shipping_complete'     => array(
			'label'   => __( 'Free shipping — qualified message', 'whoop-clone' ),
			'default' => __( 'You qualify for free shipping!', 'whoop-clone' ),
		),
		'whoop_free_shipping_remaining'    => array(
			'label'       => __( 'Free shipping — remaining message (%s = price)', 'whoop-clone' ),
			'default'     => __( 'Add %s more for free shipping', 'whoop-clone' ),
		),
		'whoop_cart_sticky_total_label'    => array(
			'label'   => __( 'Cart sticky bar — total label', 'whoop-clone' ),
			'default' => __( 'Toplam', 'whoop-clone' ),
		),
		'whoop_cart_sticky_cta_text'       => array(
			'label'   => __( 'Cart sticky bar — button text', 'whoop-clone' ),
			'default' => __( 'Proceed to checkout', 'whoop-clone' ),
		),
		'whoop_product_step_prefix'        => array(
			'label'       => __( 'Product step default label (%02d = number)', 'whoop-clone' ),
			'default'     => '',
			'description' => __( 'Leave empty to use “Step 01”, “Step 02”, etc.', 'whoop-clone' ),
		),
		'whoop_thankyou_title'             => array(
			'label'   => __( 'Thank you page — headline', 'whoop-clone' ),
			'default' => __( 'Thank you for your order', 'whoop-clone' ),
		),
		'whoop_thankyou_cta_text'          => array(
			'label'   => __( 'Thank you page — continue shopping text', 'whoop-clone' ),
			'default' => __( 'Continue shopping', 'whoop-clone' ),
		),
		'whoop_thankyou_cta_url'           => array(
			'label'   => __( 'Thank you page — continue shopping URL', 'whoop-clone' ),
			'default' => '',
			'type'    => 'url',
		),
		'whoop_email_footer_text'          => array(
			'label'   => __( 'Email footer text', 'whoop-clone' ),
			'default' => '',
			'type'    => 'textarea',
			'sanitize' => 'sanitize_textarea_field',
		),
	);

	foreach ( $controls as $id => $cfg ) {
		$sanitize = isset( $cfg['sanitize'] ) ? $cfg['sanitize'] : 'sanitize_text_field';
		$wp_customize->add_setting(
			$id,
			array(
				'default'           => $cfg['default'],
				'sanitize_callback' => $sanitize,
				'transport'         => 'refresh',
			)
		);

		$control_args = array(
			'label'   => $cfg['label'],
			'section' => 'whoop_woocommerce',
			'type'    => isset( $cfg['type'] ) ? $cfg['type'] : 'text',
		);

		if ( ! empty( $cfg['description'] ) ) {
			$control_args['description'] = $cfg['description'];
		}

		$wp_customize->add_control( $id, $control_args );
	}
}
add_action( 'customize_register', 'whoop_woocommerce_customize_register', 20 );

/**
 * Sanitize positive float for shipping threshold.
 *
 * @param mixed $value Raw value.
 * @return float
 */
function whoop_sanitize_positive_float( $value ) {
	return max( 0, (float) $value );
}

/**
 * Theme mod with empty-string fallback to default.
 *
 * @param string $key     Setting key.
 * @param string $default Default value.
 * @return string
 */
function whoop_wc_theme_mod( $key, $default = '' ) {
	$value = get_theme_mod( $key, $default );
	if ( is_string( $value ) && '' === trim( $value ) && '' !== $default ) {
		return $default;
	}
	return is_string( $value ) ? $value : (string) $value;
}
