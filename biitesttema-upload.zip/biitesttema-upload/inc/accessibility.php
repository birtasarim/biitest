<?php
/**
 * Accessibility: extra styles, mobile nav focus, enhancements enqueue.
 *
 * @package whoop-clone
 */

defined( 'ABSPATH' ) || exit;

/**
 * Enqueue theme enhancement layer after core theme CSS.
 */
function whoop_enqueue_theme_enhancements() {
	$path = WHOOP_THEME_DIR . '/assets/css/theme-enhancements.css';
	if ( ! file_exists( $path ) ) {
		return;
	}

	$deps = array();
	global $wp_styles;
	if ( $wp_styles instanceof WP_Styles ) {
		foreach ( array_keys( $wp_styles->registered ) as $handle ) {
			if ( 0 === strpos( $handle, 'whoop-style-' ) ) {
				$deps[] = $handle;
				break;
			}
		}
	}

	wp_enqueue_style(
		'whoop-theme-enhancements',
		WHOOP_THEME_URI . '/assets/css/theme-enhancements.css',
		$deps,
		WHOOP_THEME_VERSION
	);
}
add_action( 'wp_enqueue_scripts', 'whoop_enqueue_theme_enhancements', 100 );

/**
 * Load enhancements in block editor (typography / focus parity).
 */
function whoop_enqueue_editor_enhancements() {
	$path = WHOOP_THEME_DIR . '/assets/css/theme-enhancements.css';
	if ( ! file_exists( $path ) ) {
		return;
	}
	wp_enqueue_style(
		'whoop-theme-enhancements-editor',
		WHOOP_THEME_URI . '/assets/css/theme-enhancements.css',
		array(),
		WHOOP_THEME_VERSION
	);
}
add_action( 'enqueue_block_editor_assets', 'whoop_enqueue_editor_enhancements', 99 );

/**
 * Mobile menu: move focus into panel when open, trap Tab, restore on close.
 */
function whoop_mobile_nav_focus_script() {
	?>
	<script>
	(function () {
		var header = document.getElementById('siteHeader');
		var toggle = document.getElementById('menuToggle');
		var panel = document.getElementById('mobileNavPanel');
		if (!header || !toggle || !panel) return;

		var lastFocus = toggle;
		var focusableSel = 'a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])';

		function getFocusables() {
			return Array.prototype.slice.call(panel.querySelectorAll(focusableSel)).filter(function (el) {
				return el.offsetParent !== null || panel.contains(el);
			});
		}

		function onOpen() {
			var list = getFocusables();
			if (list.length) list[0].focus();
		}

		function onClose() {
			if (lastFocus && typeof lastFocus.focus === 'function' && document.body.contains(lastFocus)) {
				lastFocus.focus();
			}
		}

		var obs = new MutationObserver(function () {
			var open = header.classList.contains('is-menu-open');
			if (open) onOpen();
			else onClose();
		});
		obs.observe(header, { attributes: true, attributeFilter: ['class'] });

		panel.addEventListener('keydown', function (e) {
			if (!header.classList.contains('is-menu-open') || e.key !== 'Tab') return;
			var list = getFocusables();
			if (list.length < 2) return;
			var first = list[0];
			var last = list[list.length - 1];
			if (e.shiftKey && document.activeElement === first) {
				e.preventDefault();
				last.focus();
			} else if (!e.shiftKey && document.activeElement === last) {
				e.preventDefault();
				first.focus();
			}
		});
	})();
	</script>
	<?php
}
add_action( 'wp_footer', 'whoop_mobile_nav_focus_script', 50 );
