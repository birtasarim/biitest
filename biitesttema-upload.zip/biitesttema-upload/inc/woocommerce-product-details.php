<?php
/**
 * WooCommerce product detail section rendering.
 *
 * @package whoop-clone
 */

defined( 'ABSPATH' ) || exit;

/**
 * Render product process steps attached to a WooCommerce product.
 *
 * @param int $product_id Product post ID.
 * @return string
 */
function whoop_render_product_steps_markup( $product_id ) {
	if ( ! function_exists( 'get_field' ) ) {
		return '';
	}

	$headline = get_field( 'whoop_product_steps_headline', $product_id ) ?: '';
	$subline  = get_field( 'whoop_product_steps_subline', $product_id ) ?: '';
	$steps    = get_field( 'whoop_product_steps_items', $product_id );

	if ( ! is_array( $steps ) ) {
		$steps = array();
	}

	$steps = array_values(
		array_filter(
			$steps,
			static function ( $step ) {
				return is_array( $step ) && ( ! empty( $step['label'] ) || ! empty( $step['title'] ) || ! empty( $step['text'] ) );
			}
		)
	);

	if ( ! $headline && ! $subline && empty( $steps ) ) {
		return '';
	}

	ob_start();
	?>
	<section class="product-steps">
		<div class="container">
			<?php if ( $headline || $subline ) : ?>
				<div class="product-steps-head">
					<?php if ( $headline ) : ?>
						<h2><?php echo esc_html( $headline ); ?></h2>
					<?php endif; ?>
					<?php if ( $subline ) : ?>
						<p><?php echo esc_html( $subline ); ?></p>
					<?php endif; ?>
				</div>
			<?php endif; ?>

			<?php if ( ! empty( $steps ) ) : ?>
				<div class="product-steps-grid">
					<?php foreach ( $steps as $index => $step ) : ?>
						<?php
						$label   = $step['label'] ?? '';
						$title   = $step['title'] ?? '';
						$text    = $step['text'] ?? '';
						$prefix  = get_theme_mod( 'whoop_product_step_prefix', '' );
						$default = is_string( $prefix ) && '' !== trim( $prefix )
							? sprintf( $prefix, $index + 1 )
							: sprintf( __( 'Step %02d', 'whoop-clone' ), $index + 1 );
						?>
						<article class="product-steps-card">
							<div class="product-steps-card-bar" aria-hidden="true"></div>
							<div class="product-steps-label">
								<?php echo esc_html( $label ? $label : $default ); ?>
							</div>
							<div class="product-steps-copy">
								<?php if ( $title ) : ?>
									<h3><?php echo esc_html( $title ); ?></h3>
								<?php endif; ?>
								<?php if ( $text ) : ?>
									<p><?php echo esc_html( $text ); ?></p>
								<?php endif; ?>
							</div>
						</article>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
		</div>
	</section>
	<?php

	return (string) ob_get_clean();
}

/**
 * Render product note attached to a WooCommerce product.
 *
 * @param int $product_id Product post ID.
 * @return string
 */
function whoop_render_product_note_markup( $product_id ) {
	if ( ! function_exists( 'get_field' ) ) {
		return '';
	}

	$text = get_field( 'whoop_product_note_text', $product_id ) ?: '';
	if ( '' === trim( $text ) ) {
		return '';
	}

	ob_start();
	?>
	<section class="product-note">
		<div class="container">
			<div class="product-note-row">
				<div class="product-note-icon" aria-hidden="true">
					<svg viewBox="0 0 20 20" width="12" height="12" fill="none">
						<path d="M4.5 10.5l3.2 3.2 7.8-8.2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
					</svg>
				</div>
				<p><?php echo esc_html( $text ); ?></p>
			</div>
		</div>
	</section>
	<?php

	return (string) ob_get_clean();
}

/**
 * Append themed product-detail sections after the product description content.
 *
 * @param string $content Product content.
 * @return string
 */
function whoop_append_product_detail_sections( $content ) {
	if ( is_admin() || ! is_singular( 'product' ) || ! in_the_loop() || ! is_main_query() ) {
		return $content;
	}

	$product_id = get_the_ID();
	if ( ! $product_id ) {
		return $content;
	}

	$sections  = whoop_render_product_steps_markup( $product_id );
	$sections .= whoop_render_product_note_markup( $product_id );

	if ( '' === $sections ) {
		return $content;
	}

	return $content . $sections;
}
add_filter( 'the_content', 'whoop_append_product_detail_sections', 20 );
