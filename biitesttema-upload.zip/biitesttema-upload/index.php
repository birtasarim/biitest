<?php
/**
 * Fallback index template — required for every theme.
 * Delegates to archive layout.
 *
 * @package whoop-clone
 */

defined( 'ABSPATH' ) || exit;

include locate_template( 'archive.php' );
