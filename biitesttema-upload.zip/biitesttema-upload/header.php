<?php
/**
 * Site header — promo bar + sticky nav.
 *
 * @package whoop-clone
 */

defined( 'ABSPATH' ) || exit;
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
	<meta name="theme-color" content="#000000">
	<?php wp_head(); ?>
</head>
<?php
?>
<body <?php body_class( 'whoop-lenis-native' ); ?>>
<?php wp_body_open(); ?>

<a class="whoop-skip-link" href="#site-main"><?php esc_html_e( 'Skip to content', 'whoop-clone' ); ?></a>

<?php
$promo_text      = get_theme_mod( 'whoop_promo_text', __( 'Discover exclusive membership benefits for Chase Sapphire® cardholders.', 'whoop-clone' ) );
$promo_link_text = get_theme_mod( 'whoop_promo_link_text', __( 'Explore Now', 'whoop-clone' ) );
$promo_link_url  = get_theme_mod( 'whoop_promo_link_url', '#' );
$gift_url        = get_theme_mod( 'whoop_gift_url', '#gift' );
$join_url        = get_theme_mod( 'whoop_join_url', '#join' );
$gift_text       = get_theme_mod( 'whoop_gift_text', __( 'Gift WHOOP', 'whoop-clone' ) );
$join_text       = get_theme_mod( 'whoop_join_text', __( 'SATIN AL', 'whoop-clone' ) );

$wc_active   = function_exists( 'whoop_is_woocommerce_active' ) && whoop_is_woocommerce_active();
$header_cart_count = 0;
if ( $wc_active && function_exists( 'WC' ) ) {
	$whoop_wc_cart = WC()->cart;
	if ( $whoop_wc_cart ) {
		$header_cart_count = (int) $whoop_wc_cart->get_cart_contents_count();
	}
}
$header_cart_url = $gift_url;
$header_buy_url  = $join_url;
if ( $wc_active ) {
	$header_cart_url = $header_cart_count > 0 ? wc_get_cart_url() : wc_get_page_permalink( 'shop' );
	$header_buy_url  = $header_cart_count > 0 ? wc_get_checkout_url() : wc_get_page_permalink( 'shop' );
}
$header_cart_badge = '';
if ( $header_cart_count > 0 ) {
	$header_cart_badge = $header_cart_count > 99 ? '99+' : (string) $header_cart_count;
}
if ( $wc_active ) {
	$header_cart_aria = $header_cart_count > 0
		/* translators: %d: number of items in cart */
		? sprintf( __( 'Shopping cart, %d items', 'whoop-clone' ), $header_cart_count )
		: __( 'Shopping cart', 'whoop-clone' );
} else {
	$header_cart_aria = $gift_text;
}
?>

<header class="header" id="siteHeader">
	<?php if ( ! empty( $promo_text ) ) : ?>
		<div class="promo">
			<div class="container">
				<span><?php echo esc_html( $promo_text ); ?></span>
				<?php if ( $promo_link_text && $promo_link_url ) : ?>
					<a href="<?php echo esc_url( $promo_link_url ); ?>"><?php echo esc_html( $promo_link_text ); ?></a>
				<?php endif; ?>
			</div>
		</div>
	<?php endif; ?>

	<nav class="nav" aria-label="<?php esc_attr_e( 'Primary', 'whoop-clone' ); ?>">
		<div class="container nav-inner">
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="logo" aria-label="<?php bloginfo( 'name' ); ?>">
				<?php
				if ( has_custom_logo() ) {
					the_custom_logo();
				} else {
					echo '<span class="dot"></span>';
					bloginfo( 'name' );
				}
				?>
			</a>

			<button class="menu-toggle" id="menuToggle" aria-expanded="false" aria-controls="mobileNavPanel" aria-label="<?php esc_attr_e( 'Open menu', 'whoop-clone' ); ?>">
				<span></span>
				<span></span>
				<span></span>
			</button>

			<?php
			if ( has_nav_menu( 'primary' ) ) {
				wp_nav_menu(
					array(
						'theme_location' => 'primary',
						'container'      => false,
						'menu_class'     => 'nav-links',
						'depth'          => 2,
						'fallback_cb'    => false,
						'walker'         => new Whoop_Primary_Nav_Walker(),
					)
				);
			} else {
				whoop_primary_menu_fallback();
			}
			?>

			<div class="nav-cta">
				<a href="<?php echo esc_url( $header_cart_url ); ?>" class="nav-cart whoop-header-cart" aria-label="<?php echo esc_attr( $header_cart_aria ); ?>">
					<span class="whoop-cart-icon-wrap">
						<svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
							<path d="M3 5h2l2.2 9.2a1 1 0 0 0 1 .8h7.9a1 1 0 0 0 1-.8L21 8H7" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
							<circle cx="10" cy="19" r="1.5" fill="currentColor"/>
							<circle cx="18" cy="19" r="1.5" fill="currentColor"/>
						</svg>
						<?php if ( $wc_active ) : ?>
							<span class="whoop-cart-count-badge" aria-hidden="true"><?php echo esc_html( $header_cart_badge ); ?></span>
						<?php endif; ?>
					</span>
				</a>
				<a href="<?php echo esc_url( $header_buy_url ); ?>" class="btn btn-primary"><?php echo esc_html( $join_text ); ?></a>
			</div>
		</div>
	</nav>

	<div class="mobile-nav-overlay" id="mobileNavOverlay" hidden></div>
	<aside class="mobile-nav-panel" id="mobileNavPanel" aria-hidden="true">
		<div class="mobile-nav-panel-inner">
			<div class="mobile-nav-links-wrap">
				<?php
				if ( has_nav_menu( 'primary' ) ) {
					wp_nav_menu(
						array(
							'theme_location' => 'primary',
							'container'      => false,
							'menu_class'     => 'mobile-nav-links',
							'depth'          => 2,
							'fallback_cb'    => false,
							'walker'         => new Whoop_Primary_Nav_Walker(),
						)
					);
				} else {
					whoop_primary_menu_fallback( 'mobile-nav-links' );
				}
				?>
			</div>

			<div class="mobile-nav-actions">
				<a href="<?php echo esc_url( $header_buy_url ); ?>" class="btn btn-primary"><?php echo esc_html( $join_text ); ?></a>
				<a href="<?php echo esc_url( $header_cart_url ); ?>" class="mobile-cart-btn whoop-header-cart" aria-label="<?php echo esc_attr( $header_cart_aria ); ?>">
					<span class="whoop-cart-icon-wrap">
						<svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
							<path d="M3 5h2l2.2 9.2a1 1 0 0 0 1 .8h7.9a1 1 0 0 0 1-.8L21 8H7" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
							<circle cx="10" cy="19" r="1.5" fill="currentColor"/>
							<circle cx="18" cy="19" r="1.5" fill="currentColor"/>
						</svg>
						<?php if ( $wc_active ) : ?>
							<span class="whoop-cart-count-badge" aria-hidden="true"><?php echo esc_html( $header_cart_badge ); ?></span>
						<?php endif; ?>
					</span>
				</a>
			</div>
		</div>
	</aside>
</header>

<main id="site-main" class="site-main" tabindex="-1">
