# Geliştirici Notları

Lokal geliştirme akışı, dosya organizasyonu, build pipeline.

## Hızlı başlangıç

```bash
cd wp-content/themes/whoop-theme
npm install
touch .dev          # WP'ye "Vite dev server kullan" sinyalini ver
npm run dev         # http://localhost:5173 ayağa kalkar
```

WP sayfasını yenile — CSS/JS değiştirince otomatik HMR ile güncellenir.

## Build ve deploy

```bash
rm .dev             # üretim moduna geç
npm run build       # assets/dist/ + manifest.json
```

WP `assets/dist/.vite/manifest.json`'ı okur, hashed CSS/JS dosyalarını enqueue eder.

## Klasör organizasyonu

```
src/
├── styles/
│   ├── main.scss              ← entry, sadece @use ifadeleri
│   ├── _tokens.scss           ← bütün renk/spacing/font/radius değerleri
│   ├── _mixins.scss           ← responsive(), focus-ring(), container() vs.
│   ├── _reset.scss            ← reset + base typography
│   ├── _utilities.scss        ← .container, .eyebrow, .btn, .reveal
│   ├── components/
│   │   ├── _header.scss
│   │   ├── _footer.scss
│   │   └── _modals.scss       ← feature/person/testimonial modallar
│   ├── blocks/                ← her ACF block için ayrı dosya
│   │   ├── _hero.scss
│   │   ├── _daily.scss
│   │   ├── _features.scss
│   │   ├── _memberships.scss
│   │   ├── _gift.scss
│   │   ├── _social-proof.scss
│   │   ├── _principles.scss
│   │   ├── _showcase.scss
│   │   ├── _trial.scss
│   │   └── _advanced-labs.scss
│   ├── overrides/
│   │   └── _legacy.scss       ← geçiş sürecinden kalan light-theme override'ları
│   └── utils/
│       └── _section-rise.scss ← hero parallax helper
│
└── js/
    ├── main.js                ← entry, modülleri import eder
    ├── lib/
    │   ├── lenis.js           ← Lenis smooth scroll setup
    │   ├── reveal.js          ← .reveal IntersectionObserver
    │   ├── header.js          ← scroll-up/down hide, nav-link width
    │   └── hero-parallax.js   ← hero overlay + section-rise
    └── modules/
        ├── slider.js
        ├── showcase-tabs.js
        ├── feature-modal.js
        ├── person-modal.js
        ├── testimonial-modal.js
        └── principles-accordion.js
```

## SCSS yazım kuralları

### Token kullanımı

```scss
@use '../tokens' as *;
@use '../mixins' as *;

.my-card {
  background: $color-bg-elev-1;        // SCSS variable — build-time
  padding: $space-6 $space-8;
  border-radius: $radius-lg;

  // CSS custom property — runtime'da JS de okuyabilir
  color: var(--text);

  @include responsive(md) {
    padding: $space-12;
  }

  @include focus-ring;
}
```

**SCSS değişkeni vs CSS custom property:**

- **SCSS değişkeni (`$color-primary`)**: build sırasında değer yerine geçer; SCSS'te matematik yapabilirsin (`$space-4 * 2`), `lighten()`/`darken()` mümkün
- **CSS custom property (`var(--primary)`)**: runtime'da yaşar; JS değiştirebilir, dark mode toggle, theme switching için
- **Önerilen**: token tanımlarken **ikisini birden** export et (`_tokens.scss` zaten yapıyor). Component'lerde tercih `var(--name)` — değiştirilebilirlik sağlar

### Mixin kullanımı

```scss
@include responsive(md)         // >= 880px
@include responsive-down(md)    // < 880px
@include focus-ring             // accessibility outline
@include visually-hidden        // a11y screen-reader-only
@include container              // .container helper
@include truncate(2)            // 2 line clamp
@include hide-scrollbar
@include overlay-gradient       // bottom-up gradient
@include reduced-motion { ... } // wraps @media (prefers-reduced-motion)
```

### Yeni block stili eklemek

1. `src/styles/blocks/_my-block.scss` oluştur
2. `@use '../tokens' as *; @use '../mixins' as *;` ile başla
3. `src/styles/main.scss` içine `@use 'blocks/my-block';` ekle
4. `npm run dev` çalışıyorsa otomatik derlenir

## JS yazım kuralları

### Yeni modül eklemek

```javascript
// src/js/modules/my-feature.js
import { getLenis } from '../lib/lenis.js';

export function initMyFeature() {
  const root = document.querySelector('.my-feature');
  if (!root) return;
  // ... event listeners, observers
}
```

```javascript
// src/js/main.js
import { initMyFeature } from './modules/my-feature.js';

function boot() {
  // ... existing inits
  initMyFeature();
}
```

### Lenis ile etkileşim

Modal/popover açıyorsan `getLenis()?.stop()` ve `getLenis()?.start()` ile ana scroll'u durdurmalısın — yoksa modal açıkken arkada kayıyor olur.

## Lint ve format

```bash
npm run lint           # SCSS + JS hep birden
npm run lint:scss      # sadece SCSS
npm run lint:js        # sadece JS
npm run format         # Prettier — src/ içindeki her şeyi formatlar
```

Hata almazsan PR/commit edebilirsin. Hatalar genelde:

- **SCSS**: bilinmeyen variable, eksik `@use`
- **JS**: kullanılmayan import, console.log

## PHP konvansiyonları

- Tüm fonksiyonlar `whoop_` ile başlar (namespace pollution'dan kaçın)
- ACF field tanımları **PHP'de** tut (`inc/acf-fields.php`) — ACF UI'dan değil
- Block render template'leri `template-parts/blocks/<name>/<name>.php`
- Her ACF field'a okuma sırasında `?:` veya `?? ''` ile fallback ver
- Image'lar için `whoop_image_src($field, 'whoop-card')` helper'ını kullan

## Deploy checklist

- [ ] `.dev` dosyası yok (üretim modu)
- [ ] `WHOOP_VITE_DEV` define'i `wp-config.php`'de yok veya `false`
- [ ] `npm run build` son commit'ten sonra çalıştırılmış
- [ ] `assets/dist/` git'e commit edilmiş VEYA deploy script'inde build adımı var
- [ ] `WHOOP_THEME_VERSION` (functions.php) yeni release için bumped
- [ ] ACF Pro plugin etkin
- [ ] WooCommerce kullanıyorsan etkin

## Olası sorunlar

### `npm run dev` 5173'te ayakta ama tarayıcı hala eski CSS gösteriyor
- WP dev modunda mı? Tarayıcı network tab'inde `localhost:5173`'ten yükleme görüyor musun?
- `.dev` flag dosyası var mı veya `WHOOP_VITE_DEV` true mu?

### Build sonrası "No compiled assets found"
- `assets/dist/.vite/manifest.json` var mı?
- `npm run build` hatasız tamamlandı mı? Console'a bak

### CSS değişikliği görünmüyor
- Browser cache: Ctrl+Shift+R (hard reload)
- WP cache plugin'ı varsa cache temizle
- `WHOOP_THEME_VERSION`'ı bump et

### `npm install` hatası
- Node.js sürümü? `node -v` → 18+ olmalı
- `npm cache clean --force` deneyebilirsin

## Komutlar özeti

| Komut | Ne yapar |
|-------|----------|
| `npm install` | Bağımlılıkları kur |
| `npm run dev` | Hot reload dev server (port 5173) |
| `npm run build` | Production build → assets/dist/ |
| `npm run watch` | Dev server'sız sürekli build |
| `npm run lint` | Lint everything |
| `npm run format` | Prettier format |
