<?php
/**
 * My Account page — premium shell.
 *
 * @package whoop-clone
 * @see     https://woocommerce.com/document/template-structure/
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="whoop-account-shell">
	<?php do_action( 'woocommerce_account_navigation' ); ?>
	<div class="whoop-account-content">
		<?php do_action( 'woocommerce_account_content' ); ?>
	</div>
</div>
