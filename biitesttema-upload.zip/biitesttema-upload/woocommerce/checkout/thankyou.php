<?php
/**
 * Thank you page — premium hero + order details.
 *
 * @package whoop-clone
 * @see     https://woocommerce.com/document/template-structure/
 * @version 8.1.0
 */

defined( 'ABSPATH' ) || exit;
?>

<div class="woocommerce-order whoop-thankyou">

	<?php if ( $order ) : ?>

		<?php do_action( 'woocommerce_before_thankyou', $order->get_id() ); ?>

		<?php if ( $order->has_status( 'failed' ) ) : ?>

			<div class="whoop-thankyou-hero">
				<p class="woocommerce-notice woocommerce-notice--error woocommerce-thankyou-order-failed">
					<?php esc_html_e( 'Unfortunately your order cannot be processed as the originating bank/merchant has declined your transaction. Please attempt your purchase again.', 'woocommerce' ); ?>
				</p>
				<p class="woocommerce-notice woocommerce-notice--error woocommerce-thankyou-order-failed-actions">
					<a href="<?php echo esc_url( $order->get_checkout_payment_url() ); ?>" class="button pay whoop-thankyou-cta"><?php esc_html_e( 'Pay', 'woocommerce' ); ?></a>
					<?php if ( is_user_logged_in() ) : ?>
						<a href="<?php echo esc_url( wc_get_page_permalink( 'myaccount' ) ); ?>" class="button pay whoop-thankyou-cta"><?php esc_html_e( 'My account', 'woocommerce' ); ?></a>
					<?php endif; ?>
				</p>
			</div>

		<?php else : ?>

			<?php
			$whoop_thankyou_title = whoop_wc_theme_mod( 'whoop_thankyou_title', __( 'Thank you for your order', 'whoop-clone' ) );
			$whoop_cta_text       = whoop_wc_theme_mod( 'whoop_thankyou_cta_text', __( 'Continue shopping', 'whoop-clone' ) );
			$whoop_cta_url        = get_theme_mod( 'whoop_thankyou_cta_url', '' );
			if ( ! is_string( $whoop_cta_url ) || '' === trim( $whoop_cta_url ) ) {
				$whoop_cta_url = wc_get_page_permalink( 'shop' );
			}
			?>
			<div class="whoop-thankyou-hero">
				<?php if ( $whoop_thankyou_title ) : ?>
					<h1><?php echo esc_html( $whoop_thankyou_title ); ?></h1>
				<?php else : ?>
					<?php wc_get_template( 'checkout/order-received.php', array( 'order' => $order ) ); ?>
				<?php endif; ?>
				<?php if ( $whoop_cta_text && $whoop_cta_url ) : ?>
					<a class="whoop-thankyou-cta" href="<?php echo esc_url( $whoop_cta_url ); ?>"><?php echo esc_html( $whoop_cta_text ); ?></a>
				<?php endif; ?>
			</div>

			<ul class="woocommerce-order-overview woocommerce-thankyou-order-details order_details">

				<li class="woocommerce-order-overview__order order">
					<?php esc_html_e( 'Order number:', 'woocommerce' ); ?>
					<strong><?php echo esc_html( $order->get_order_number() ); ?></strong>
				</li>

				<li class="woocommerce-order-overview__date date">
					<?php esc_html_e( 'Date:', 'woocommerce' ); ?>
					<strong><?php echo esc_html( wc_format_datetime( $order->get_date_created() ) ); ?></strong>
				</li>

				<?php if ( is_user_logged_in() && $order->get_user_id() === get_current_user_id() && $order->get_billing_email() ) : ?>
					<li class="woocommerce-order-overview__email email">
						<?php esc_html_e( 'Email:', 'woocommerce' ); ?>
						<strong><?php echo esc_html( $order->get_billing_email() ); ?></strong>
					</li>
				<?php endif; ?>

				<li class="woocommerce-order-overview__total total">
					<?php esc_html_e( 'Total:', 'woocommerce' ); ?>
					<strong><?php echo wp_kses_post( $order->get_formatted_order_total() ); ?></strong>
				</li>

				<?php if ( $order->get_payment_method_title() ) : ?>
					<li class="woocommerce-order-overview__payment-method method">
						<?php esc_html_e( 'Payment method:', 'woocommerce' ); ?>
						<strong><?php echo wp_kses_post( $order->get_payment_method_title() ); ?></strong>
					</li>
				<?php endif; ?>

			</ul>

		<?php endif; ?>

		<?php do_action( 'woocommerce_thankyou_' . $order->get_payment_method(), $order->get_id() ); ?>
		<?php do_action( 'woocommerce_thankyou', $order->get_id() ); ?>

	<?php else : ?>

		<div class="whoop-thankyou-hero">
			<?php wc_get_template( 'checkout/order-received.php', array( 'order' => false ) ); ?>
		</div>

	<?php endif; ?>

</div>
