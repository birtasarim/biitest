<?php
/**
 * Single product content — premium hero grid + details (tabs, ACF sections via the_content).
 *
 * @package whoop-clone
 * @see     https://woocommerce.com/document/template-structure/
 */

defined( 'ABSPATH' ) || exit;

global $product;

if ( ! $product ) {
	return;
}

$hero_visual        = function_exists( 'get_field' ) ? get_field( 'whoop_product_hero_visual', $product->get_id() ) : null;
$hero_certificates  = function_exists( 'get_field' ) ? get_field( 'whoop_product_hero_certificates', $product->get_id() ) : array();
$hero_features      = function_exists( 'get_field' ) ? get_field( 'whoop_product_hero_features', $product->get_id() ) : array();
$hero_secondary_cta = function_exists( 'get_field' ) ? ( get_field( 'whoop_product_hero_secondary_cta_text', $product->get_id() ) ?: '' ) : '';
$hero_secondary_url = function_exists( 'get_field' ) ? ( get_field( 'whoop_product_hero_secondary_cta_url', $product->get_id() ) ?: '' ) : '';
$hero_trust_text    = function_exists( 'get_field' ) ? ( get_field( 'whoop_product_hero_trust_text', $product->get_id() ) ?: '' ) : '';
$bundle_heading     = function_exists( 'get_field' ) ? ( get_field( 'whoop_product_bundle_heading', $product->get_id() ) ?: '' ) : '';
$bundle_offers      = function_exists( 'get_field' ) ? get_field( 'whoop_product_bundle_offers', $product->get_id() ) : array();

if ( ! is_array( $hero_certificates ) ) {
	$hero_certificates = array();
}

if ( ! is_array( $hero_features ) ) {
	$hero_features = array();
}

if ( ! is_array( $bundle_offers ) ) {
	$bundle_offers = array();
}

$bundle_offers = array_values(
	array_filter(
		$bundle_offers,
		static function ( $offer ) {
			if ( ! is_array( $offer ) ) {
				return false;
			}

			return '' !== trim(
				(string) ( $offer['quantity_label'] ?? '' ) .
				(string) ( $offer['title'] ?? '' ) .
				(string) ( $offer['badge_text'] ?? '' ) .
				(string) ( $offer['price_text'] ?? '' ) .
				(string) ( $offer['compare_price_text'] ?? '' ) .
				(string) ( $offer['unit_text'] ?? '' )
			);
		}
	)
);

/**
 * Hook: woocommerce_before_single_product.
 */
do_action( 'woocommerce_before_single_product' );

if ( post_password_required() ) {
	echo get_the_password_form(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	return;
}
?>
<div id="product-<?php the_ID(); ?>" <?php wc_product_class( 'whoop-product-shell', $product ); ?>>

	<div class="whoop-product-hero">
		<article class="whoop-product-panel tier-panel tier is-active">
			<div class="tier-shell whoop-product-panel-shell">
				<div class="tier-media whoop-product-panel-media">
					<?php if ( $hero_visual ) : ?>
						<div class="whoop-product-panel-visual whoop-product-panel-visual--custom">
							<img src="<?php echo esc_url( whoop_image_src( $hero_visual, 'whoop-card' ) ); ?>" alt="<?php echo esc_attr( whoop_image_alt( $hero_visual, $product->get_name() ) ); ?>" />
						</div>
					<?php else : ?>
						<?php
						/**
						 * Hook: woocommerce_before_single_product_summary.
						 *
						 * @hooked woocommerce_show_product_sale_flash - 10
						 * @hooked woocommerce_show_product_images - 20
						 */
						do_action( 'woocommerce_before_single_product_summary' );
						?>
					<?php endif; ?>
				</div>

				<div class="summary entry-summary whoop-product-summary-card tier-body whoop-product-panel-body">
					<?php if ( ! empty( $hero_certificates ) ) : ?>
						<div class="tier-certs tier-certs-desktop whoop-product-panel-certs" aria-label="<?php esc_attr_e( 'ISO certificates', 'whoop-clone' ); ?>">
							<?php foreach ( $hero_certificates as $certificate ) : ?>
								<?php if ( empty( $certificate['image'] ) ) : ?>
									<?php continue; ?>
								<?php endif; ?>
								<div class="tier-cert">
									<img src="<?php echo esc_url( whoop_image_src( $certificate['image'], 'medium' ) ); ?>" alt="<?php echo esc_attr( whoop_image_alt( $certificate['image'], '' ) ); ?>" />
								</div>
							<?php endforeach; ?>
						</div>
					<?php endif; ?>

					<?php woocommerce_template_single_title(); ?>
					<?php if ( ! empty( $hero_features ) ) : ?>
						<ul class="tier-features whoop-product-panel-features">
							<?php foreach ( $hero_features as $feature ) : ?>
								<?php $feature_text = isset( $feature['text'] ) ? (string) $feature['text'] : ''; ?>
								<?php if ( '' === trim( $feature_text ) ) : ?>
									<?php continue; ?>
								<?php endif; ?>
								<li>
									<svg viewBox="0 0 16 16" width="16" height="16" fill="none" stroke="currentColor">
										<path d="M5 8l2 2 4-4" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
									</svg>
									<?php echo esc_html( $feature_text ); ?>
								</li>
							<?php endforeach; ?>
						</ul>
					<?php endif; ?>
					<?php woocommerce_template_single_price(); ?>
					<?php woocommerce_template_single_excerpt(); ?>
					<div class="whoop-product-panel-actions">
						<?php woocommerce_template_single_add_to_cart(); ?>
						<?php if ( $hero_secondary_cta && $hero_secondary_url ) : ?>
							<a href="<?php echo esc_url( $hero_secondary_url ); ?>" class="btn-outline whoop-product-panel-secondary-cta"><?php echo esc_html( $hero_secondary_cta ); ?></a>
						<?php endif; ?>
					</div>
					<?php if ( $bundle_heading || ! empty( $bundle_offers ) ) : ?>
						<section class="whoop-product-bundle-offers" aria-label="<?php esc_attr_e( 'Bundle pricing offers', 'whoop-clone' ); ?>">
							<?php if ( $bundle_heading ) : ?>
								<h3 class="whoop-product-bundle-offers__heading"><?php echo esc_html( $bundle_heading ); ?></h3>
							<?php endif; ?>
							<?php if ( ! empty( $bundle_offers ) ) : ?>
								<div class="whoop-product-bundle-offers__grid">
									<?php foreach ( $bundle_offers as $offer ) : ?>
										<?php
										$offer_image         = $offer['image'] ?? null;
										$offer_quantity      = isset( $offer['quantity_label'] ) ? (string) $offer['quantity_label'] : '';
										$offer_qty_value     = isset( $offer['quantity_value'] ) ? intval( $offer['quantity_value'] ) : 0;
										$offer_title         = isset( $offer['title'] ) ? (string) $offer['title'] : '';
										$offer_badge         = isset( $offer['badge_text'] ) ? (string) $offer['badge_text'] : '';
										$offer_price         = isset( $offer['price_text'] ) ? (string) $offer['price_text'] : '';
										$offer_compare_price = isset( $offer['compare_price_text'] ) ? (string) $offer['compare_price_text'] : '';
										$offer_unit          = isset( $offer['unit_text'] ) ? (string) $offer['unit_text'] : '';
										?>
										<article class="whoop-product-bundle-offer"<?php echo $offer_qty_value > 0 ? ' data-qty="' . esc_attr( $offer_qty_value ) . '"' : ''; ?>>
											<?php if ( $offer_image || $offer_quantity ) : ?>
												<div class="whoop-product-bundle-offer__visual">
													<?php if ( $offer_quantity ) : ?>
														<div class="whoop-product-bundle-offer__quantity"><?php echo esc_html( $offer_quantity ); ?></div>
													<?php endif; ?>
													<?php if ( $offer_image ) : ?>
														<img src="<?php echo esc_url( whoop_image_src( $offer_image, 'medium' ) ); ?>" alt="<?php echo esc_attr( whoop_image_alt( $offer_image, $offer_title ) ); ?>" />
													<?php endif; ?>
												</div>
											<?php endif; ?>
											<div class="whoop-product-bundle-offer__body">
												<?php if ( $offer_title ) : ?>
													<h4 class="whoop-product-bundle-offer__title"><?php echo esc_html( $offer_title ); ?></h4>
												<?php endif; ?>
												<?php if ( $offer_badge ) : ?>
													<div class="whoop-product-bundle-offer__badge"><?php echo esc_html( $offer_badge ); ?></div>
												<?php endif; ?>
												<?php if ( $offer_price || $offer_compare_price || $offer_unit ) : ?>
													<div class="whoop-product-bundle-offer__prices">
														<?php if ( $offer_price ) : ?>
															<span class="whoop-product-bundle-offer__price"><?php echo esc_html( $offer_price ); ?></span>
														<?php endif; ?>
														<?php if ( $offer_compare_price ) : ?>
															<span class="whoop-product-bundle-offer__compare-price"><?php echo esc_html( $offer_compare_price ); ?></span>
														<?php endif; ?>
														<?php if ( $offer_unit ) : ?>
															<span class="whoop-product-bundle-offer__unit"><?php echo esc_html( $offer_unit ); ?></span>
														<?php endif; ?>
													</div>
												<?php endif; ?>
											</div>
										</article>
									<?php endforeach; ?>
								</div>
							<?php endif; ?>
						</section>
					<?php endif; ?>
					<?php if ( ! empty( $bundle_offers ) ) : ?>
					<script>
					(function(){
						var cards = document.querySelectorAll('.whoop-product-bundle-offer[data-qty]');
						if (!cards.length) return;
						var qtyInput = document.querySelector('form.cart .quantity input[type="number"], form.cart input[name="quantity"]');
						if (!qtyInput) return;
						function syncSelected(){
							var cur = parseInt(qtyInput.value, 10) || 1;
							cards.forEach(function(c){
								c.classList.toggle('is-selected', parseInt(c.dataset.qty, 10) === cur);
							});
						}
						cards.forEach(function(card){
							card.addEventListener('click', function(){
								var qty = parseInt(card.dataset.qty, 10);
								if (!qty || qty < 1) return;
								qtyInput.value = qty;
								qtyInput.dispatchEvent(new Event('change', {bubbles: true}));
								qtyInput.dispatchEvent(new Event('input', {bubbles: true}));
								syncSelected();
							});
						});
						qtyInput.addEventListener('change', syncSelected);
						syncSelected();
					})();
					</script>
					<?php endif; ?>
					<?php if ( $hero_trust_text ) : ?>
						<div class="tier-trust-strip whoop-product-panel-trust-strip">
							<span class="tier-trust-icon" aria-hidden="true">
								<svg viewBox="0 0 20 20" width="16" height="16" fill="none">
									<path d="M2 5.5h11.5v7H2zM13.5 7h2.4L18 9.4v3.1h-4.5zM5 14.5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm11 0a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
								</svg>
							</span>
							<span><?php echo esc_html( $hero_trust_text ); ?></span>
						</div>
					<?php endif; ?>
					<?php woocommerce_template_single_meta(); ?>
				</div>
			</div>
		</article>
	</div>

	<div class="whoop-product-details">
		<?php
		/**
		 * Hook: woocommerce_after_single_product_summary.
		 *
		 * @hooked woocommerce_output_product_data_tabs - 10
		 * @hooked woocommerce_upsell_display - 15
		 * @hooked woocommerce_output_related_products - 20
		 */
		do_action( 'woocommerce_after_single_product_summary' );
		?>
	</div>

</div>

<?php
/**
 * Hook: woocommerce_after_single_product.
 */
do_action( 'woocommerce_after_single_product' );
