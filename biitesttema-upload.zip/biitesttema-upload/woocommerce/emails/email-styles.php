<?php
/**
 * Email styles — BiiTest brand colors.
 *
 * @package whoop-clone
 * @see     https://woocommerce.com/document/template-structure/
 * @version 10.0.0
 */

defined( 'ABSPATH' ) || exit;

$whoop_primary = '#2FA3F2';
$whoop_accent  = '#B810AE';
$whoop_text    = '#0f172a';
$whoop_muted   = '#64748b';
$whoop_bg      = '#f7f9fc';
$whoop_border  = '#e2e8f0';

?>
#wrapper {
	background-color: <?php echo esc_attr( $whoop_bg ); ?>;
	margin: 0;
	padding: 70px 0;
	width: 100%;
}

#template_container {
	box-shadow: 0 12px 40px rgba(15, 23, 42, 0.08);
	border-radius: 20px;
	overflow: hidden;
}

#template_header {
	background: linear-gradient(135deg, <?php echo esc_attr( $whoop_primary ); ?> 0%, <?php echo esc_attr( $whoop_accent ); ?> 100%);
	border-radius: 20px 20px 0 0;
	color: #ffffff;
}

#template_header h1,
#template_header h1 a {
	color: #ffffff;
	font-family: Helvetica, Arial, sans-serif;
	font-size: 24px;
	font-weight: 800;
	line-height: 1.2;
	margin: 0;
	text-shadow: none;
}

#body_content {
	background-color: #ffffff;
}

#body_content_inner {
	color: <?php echo esc_attr( $whoop_text ); ?>;
	font-family: Helvetica, Arial, sans-serif;
	font-size: 15px;
	line-height: 1.6;
}

td {
	font-family: Helvetica, Arial, sans-serif;
}

h2 {
	color: <?php echo esc_attr( $whoop_text ); ?>;
	display: block;
	font-family: Helvetica, Arial, sans-serif;
	font-size: 18px;
	font-weight: 800;
	line-height: 1.3;
	margin: 0 0 12px;
}

h3 {
	color: <?php echo esc_attr( $whoop_text ); ?>;
	display: block;
	font-family: Helvetica, Arial, sans-serif;
	font-size: 16px;
	font-weight: 700;
	line-height: 1.4;
	margin: 16px 0 8px;
}

a {
	color: <?php echo esc_attr( $whoop_primary ); ?>;
	font-weight: 600;
	text-decoration: underline;
}

img {
	border: none;
	display: inline-block;
	font-size: 14px;
	font-weight: bold;
	height: auto;
	outline: none;
	text-decoration: none;
	text-transform: capitalize;
	vertical-align: middle;
	max-width: 100%;
}

#template_footer td {
	padding: 0;
	border-radius: 0 0 20px 20px;
}

#template_footer #credit {
	border-top: 1px solid <?php echo esc_attr( $whoop_border ); ?>;
	color: <?php echo esc_attr( $whoop_muted ); ?>;
	font-family: Helvetica, Arial, sans-serif;
	font-size: 12px;
	line-height: 1.5;
	padding: 24px 28px;
	text-align: center;
}

td.order-table-heading,
td.order-table-total,
td.order-table-product-name {
	color: <?php echo esc_attr( $whoop_text ); ?>;
}

td.order-table-total {
	font-weight: 800;
}

.woocommerce-Price-amount {
	color: <?php echo esc_attr( $whoop_text ); ?>;
	font-weight: 700;
}

@media screen and (max-width: 600px) {
	#template_container {
		width: 100% !important;
	}

	#body_content {
		padding: 20px 16px !important;
	}
}
