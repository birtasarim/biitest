<?php
/**
 * Email footer — Customizer footer text.
 *
 * @package whoop-clone
 * @see     https://woocommerce.com/document/template-structure/
 * @version 10.0.0
 */

defined( 'ABSPATH' ) || exit;

$whoop_email_footer = get_theme_mod( 'whoop_email_footer_text', '' );
?>
											</div>
										</td>
									</tr>
								</table>
							</td>
						</tr>
						<tr>
							<td align="center" valign="top" style="padding:20px 24px 32px;">
								<?php if ( is_string( $whoop_email_footer ) && '' !== trim( $whoop_email_footer ) ) : ?>
									<p style="margin:0 0 12px;font-family:Helvetica,Arial,sans-serif;font-size:12px;line-height:1.5;color:#64748b;">
										<?php echo esc_html( $whoop_email_footer ); ?>
									</p>
								<?php endif; ?>
								<p style="margin:0;font-family:Helvetica,Arial,sans-serif;font-size:12px;line-height:1.5;color:#94a3b8;">
									<?php echo esc_html( get_bloginfo( 'name' ) ); ?> — <?php echo esc_html( home_url( '/' ) ); ?>
								</p>
							</td>
						</tr>
					</table>
				</td>
			</tr>
		</table>
	</body>
</html>
