<?php
/**
 * Email header — branded.
 *
 * @package whoop-clone
 * @see     https://woocommerce.com/document/template-structure/
 * @version 10.0.0
 */

defined( 'ABSPATH' ) || exit;

$whoop_logo_id = (int) get_theme_mod( 'custom_logo' );
$whoop_logo    = $whoop_logo_id ? wp_get_attachment_image_url( $whoop_logo_id, 'medium' ) : '';
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=<?php bloginfo( 'charset' ); ?>" />
		<meta content="width=device-width, initial-scale=1.0" name="viewport" />
		<title><?php echo esc_html( get_bloginfo( 'name', 'display' ) ); ?></title>
	</head>
	<body <?php echo is_rtl() ? 'rightmargin' : 'leftmargin'; ?>="0" marginwidth="0" topmargin="0" marginheight="0" offset="0">
		<table border="0" cellpadding="0" cellspacing="0" width="100%" id="outer_wrapper" style="background-color:#f3f6fb;">
			<tr>
				<td align="center">
					<table border="0" cellpadding="0" cellspacing="0" width="600" id="template_container" style="max-width:600px;width:100%;">
						<tr>
							<td align="center" valign="top" style="padding:32px 24px 16px;">
								<?php if ( $whoop_logo ) : ?>
									<img src="<?php echo esc_url( $whoop_logo ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" style="max-height:48px;width:auto;display:block;margin:0 auto 16px;" />
								<?php else : ?>
									<p style="margin:0 0 16px;font-family:Helvetica,Arial,sans-serif;font-size:22px;font-weight:800;color:#000;">
										<?php echo esc_html( get_bloginfo( 'name' ) ); ?>
									</p>
								<?php endif; ?>
								<?php if ( ! empty( $email_heading ) ) : ?>
									<h1 style="margin:0;font-family:Helvetica,Arial,sans-serif;font-size:24px;font-weight:800;line-height:1.2;color:#000;">
										<?php echo esc_html( $email_heading ); ?>
									</h1>
								<?php endif; ?>
							</td>
						</tr>
						<tr>
							<td align="center" valign="top">
								<table border="0" cellpadding="0" cellspacing="0" width="100%" id="template_body" style="background:#fff;border-radius:20px;overflow:hidden;box-shadow:0 12px 40px rgba(15,23,42,0.08);">
									<tr>
										<td valign="top" id="body_content" style="padding:32px 28px;">
											<div id="body_content_inner">
